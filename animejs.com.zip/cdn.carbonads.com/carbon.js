function _bsaViewableFaker() {
    if (typeof FakeIntersectionObserver === "function") {
        return FakeIntersectionObserver
    }
    return class FakeIntersectionObserver {
        constructor(callback) {
            this._callback = callback
        }
        observe(target) {
            this._callback([{
                target: target,
                isIntersecting: false,
                intersectionRatio: 0
            }], this)
        }
        unobserve(_target) {}
        disconnect() {}
    }
}
var IntersectionObserver = typeof IntersectionObserver === "function" ? IntersectionObserver : _bsaViewableFaker();
window.requestIdleCallback = window.requestIdleCallback || function(cb) {
    var start = Date.now();
    return setTimeout((function() {
        cb({
            didTimeout: false,
            timeRemaining: function() {
                return Math.max(0, 50 - (Date.now() - start))
            }
        })
    }), 1)
};
var _bsaViewable = {
    forceOn: false,
    isset: function(v) {
        return typeof v !== "undefined" && v != null
    },
    _corelib: function() {
        if (window._bsa ? ._client === "monetization.js") {
            return window._bsa
        }
        if (window._carbonads ? ._client === "carbon.js") {
            return window._carbonads
        }
        return null
    },
    triggerView: function(statviewlink) {
        _bsaViewable._corelib()._touchUrl(statviewlink)
    },
    _inIframe: function() {
        try {
            return window.self !== window.top
        } catch (e) {
            return true
        }
    },
    _iabViewablePercentages: {
        242500: .3,
        0: .5
    },
    _iabViewableTime: 1e3,
    _iabViewablePercentage: function(width, height) {
        const area = (width || 0) * (height || 0);
        const thresholds = Object.keys(_bsaViewable._iabViewablePercentages).toSorted().reverse();
        const matchedThreshold = thresholds.find((threshold => area >= threshold));
        return _bsaViewable._iabViewablePercentages[matchedThreshold]
    },
    shouldWrapRoot: function(options) {
        const viewableDeactivated = options.noViewable;
        const windowNotDisplayed = (window.innerHeight || 0) === 0 && (window.innerWidth || 0) === 0;
        const inIframe = _bsaViewable._inIframe();
        return !viewableDeactivated && !windowNotDisplayed && !inIframe
    },
    _ensureEmbodiedElement: function(element) {
        if (element.nodeName !== "SCRIPT") {
            return [element, false]
        }
        const measurementElement = document.createElement("div");
        measurementElement.id = "_bsa_viewable_check_" + Math.floor(Math.random() * 999);
        element.parentNode.insertBefore(measurementElement, element.nextSibling);
        return [measurementElement, measurementElement.id]
    },
    _cleanupCheck: function(cleanupId) {
        return function() {
            if (!cleanupId) {
                return
            }
            document.getElementById(cleanupId).remove()
        }
    },
    _callbackWithCleanup(primaryCallback, cleanupCallback) {
        return function() {
            const response = primaryCallback.apply(this, arguments);
            cleanupCallback();
            return response
        }
    },
    rootObserve: function(element, callback) {
        const ensuredElementInfo = _bsaViewable._ensureEmbodiedElement(element);
        const ensuredElement = ensuredElementInfo[0];
        const cleanupId = ensuredElementInfo[1];
        const observer = _bsaViewable._rootObserver(_bsaViewable._callbackWithCleanup(callback, _bsaViewable._cleanupCheck(cleanupId)));
        observer.observe(ensuredElement)
    },
    _rootObserver: function(callback) {
        const reportingOverlapThreshold = 0;
        const actualOverlapThreshold = .5;
        const options = {
            threshold: reportingOverlapThreshold
        };
        return new IntersectionObserver((function(entries, observer) {
            entries.forEach((function(entry) {
                callback(entry.intersectionRatio >= actualOverlapThreshold)
            }));
            observer.disconnect()
        }), options)
    },
    officiallyViewedCallback: function(statviewlink) {
        window.requestIdleCallback((function() {
            _bsaViewable.triggerView(statviewlink)
        }), {
            timeout: 1e3
        })
    },
    setLinkInfo: function(statviewlink, key, value) {
        _bsaViewable._linkInfo = _bsaViewable._linkInfo || {};
        _bsaViewable._linkInfo[statviewlink] = _bsaViewable._linkInfo[statviewlink] || {};
        _bsaViewable._linkInfo[statviewlink][key] = value
    },
    getLinkInfo: function(statviewlink, key) {
        if (_bsaViewable._linkInfo && _bsaViewable._linkInfo[statviewlink]) {
            return _bsaViewable._linkInfo[statviewlink][key]
        }
        return null
    },
    observerCallback: function(entries, observer) {
        entries.forEach((function(entry) {
            const imageTags = entry.target.querySelectorAll("img[data-statview]");
            imageTags.forEach((function(imageTag) {
                const statviewlink = _bsaViewable.isset(imageTag) && imageTag.getAttribute("data-statview");
                if (statviewlink && statviewlink !== "") {
                    if (entry.isIntersecting && _bsaViewable._iabViewablePercentage(imageTag.getAttribute("width"), imageTag.getAttribute("height")) <= entry.intersectionRatio && !_bsaViewable.getLinkInfo(statviewlink, "intersectStart")) {
                        _bsaViewable.setLinkInfo(statviewlink, "intersectStart", Date.now());
                        _bsaViewable.setLinkInfo(statviewlink, "timeoutId", window.setTimeout((function() {
                            _bsaViewable.observer().unobserve(entry.target);
                            _bsaViewable.officiallyViewedCallback(statviewlink);
                            _bsaViewable.setLinkInfo(statviewlink, "viewedAt", Date.now())
                        }), _bsaViewable._iabViewableTime))
                    } else if (!entry.isIntersecting && _bsaViewable.getLinkInfo(statviewlink, "intersectStart") || entry.isIntersecting && _bsaViewable._iabViewablePercentage(imageTag.getAttribute("width"), imageTag.getAttribute("height")) > entry.intersectionRatio && _bsaViewable.getLinkInfo(statviewlink, "intersectStart")) {
                        window.clearTimeout(_bsaViewable.getLinkInfo(statviewlink, "timeoutId"));
                        _bsaViewable.setLinkInfo(statviewlink, "intersectStart", null);
                        _bsaViewable.setLinkInfo(statviewlink, "timeoutId", null)
                    }
                }
            }))
        }))
    },
    observer: function() {
        if (!_bsaViewable.isset(_bsaViewable._observer)) {
            const overlapThreshold = Object.values(_bsaViewable._iabViewablePercentages);
            const options = {
                threshold: overlapThreshold
            };
            _bsaViewable._observer = new IntersectionObserver(_bsaViewable.observerCallback, options)
        }
        return _bsaViewable._observer
    },
    observe: function(target) {
        if (_bsaViewable.shouldObserve(target)) {
            _bsaViewable.observer().observe(target)
        }
    },
    shouldObserve: function(target) {
        const imageTags = target.querySelectorAll("img[data-statview]");
        return Array.from(imageTags).some((function(imageTag) {
            return _bsaViewable.isset(imageTag) && imageTag.getAttribute("data-statview").length > 0
        }))
    },
    maybeViewableAttr: function(ad, statviewlink) {
        if (ad.should_record_viewable === "1" || _bsaViewable.forceOn) {
            return ` data-statview="${statviewlink}" `
        }
        return ' data-no-statview="no" '
    }
};
var _carbonads = {
    SRV_OVERRIDE: _carbonads ? .SRV_OVERRIDE,
    _client: "carbon.js",
    _version: "20260527",
    _clientConfig: function() {
        const configParts = {
            protocol: this.getUrlVar("protocol"),
            cd: this.getUrlVar("cd"),
            serveUrl: this.getUrlVar("serve"),
            serve: this.getServe(this.getUrlVar("serve"), this.getUrlVar("placement")),
            format: this.getUrlVar("format")
        };
        const configString = Object.keys(configParts).reduce((function(strParts, key) {
            const configValue = configParts[key];
            if (configValue) {
                return strParts.concat([`${key}:${encodeURIComponent(configValue)}`])
            }
            return strParts
        }), []).join(";");
        return "(" + configString + ")"
    },
    _headers: function() {
        return {
            "x-origin": window.location.toString(),
            "x-client": this._client + "/" + this._version + " " + this._clientConfig()
        }
    },
    _loadJson: function(url, callback) {
        const req = fetch(url, {
            headers: this._headers()
        });
        req.then((function(response) {
            return response.json()
        })).then((function(json) {
            return callback(json)
        })).catch((function(err) {
            console.log("Carbon ad connectivity issue!", url, "due to", err)
        }))
    },
    _touchUrl: function(url) {
        const req = fetch(url, {
            headers: this._headers(),
            mode: "no-cors"
        });
        req.then((function(response) {
            return response
        })).catch((function(err) {
            console.log("Carbon ad connectivity issue!", url, "due to", err)
        }))
    },
    init: function(where, force_serve) {
        _carbon_where = null;
        if (where) {
            _carbon_where = where
        }
        var placement = this.getUrlVar("placement"),
            baseurl = this.srv(),
            protocol = this.getUrlVar("protocol") ? this.getUrlVar("protocol") + ":" : "https:",
            serve = this.getServe(force_serve ? force_serve : this.getUrlVar("serve"), placement),
            format = this.getUrlVar("format");
        var forceUrlPreview = this.getUrlVar("_bsa_url_preview", window.location.href);
        if (forceUrlPreview) {
            var previewData = JSON.parse(decodeURIComponent(forceUrlPreview));
            setTimeout((function() {
                _carbonads_go({
                    ads: [Object.assign({}, previewData, {
                        zonekey: serve,
                        format: format,
                        statlink: previewData.link.replace(/^(http:|https:)/gm, "")
                    }), {}]
                })
            }), 0)
        } else {
            const element = _carbon_where || document.querySelector("#_carbonads_js");
            _bsaViewable.rootObserve(element, (function(viewable) {
                const baseUrl = `${protocol}//${baseurl}/ads/${serve}.json?segment=placement:${placement}`;
                const jsonSrc = _carbonads._buildSrvUrl(baseUrl, viewable);
                _carbonads._loadJson(jsonSrc, _carbonads_go)
            }))
        }
    },
    _buildSrvUrl: function(base, viewable) {
        var forcebanner = this.getUrlVar("bsaforcebanner", window.location.href),
            ignore = this.getUrlVar("bsaignore", window.location.href),
            forwardedip = this.getUrlVar("bsaforwardedip", window.location.href),
            ignoretargeting = this.getUrlVar("bsaignoretargeting", window.location.href);
        if (forcebanner) {
            base += "&forcebanner=" + forcebanner
        }
        if (ignore) {
            base += "&ignore=" + ignore
        }
        if (ignoretargeting) {
            base += "&ignoretargeting=" + ignore
        }
        if (forwardedip) {
            base += "&forwardedip=" + forwardedip
        }
        if (viewable) {
            base += "&v=" + viewable
        }
        var ck = "";
        try {
            ck = decodeURIComponent(document.cookie)
        } catch (e) {}
        var day = ck.indexOf("_bsap_daycap="),
            life = ck.indexOf("_bsap_lifecap=");
        day = day >= 0 ? ck.substring(day + 12 + 1).split(";")[0].split(",") : [];
        life = life >= 0 ? ck.substring(life + 13 + 1).split(";")[0].split(",") : [];
        if (day.length || life.length) {
            var freqcap = [];
            for (var i = 0; i < day.length; i++) {
                var adspot = day[i];
                for (var found = -1, find = 0; find < freqcap.length && found == -1; find++)
                    if (freqcap[find][0] == adspot) found = find;
                if (found == -1) freqcap.push([adspot, 1, 0]);
                else freqcap[found][1]++
            }
            for (var i = 0; i < life.length; i++) {
                var adspot = day[i];
                for (var found = -1, find = 0; find < freqcap.length && found == -1; find++)
                    if (freqcap[find][0] == adspot) found = find;
                if (found == -1) freqcap.push([adspot, 0, 1]);
                else freqcap[found][2]++
            }
            for (var i = 0; i < freqcap.length; i++) freqcap[i] = freqcap[i][0] + ":" + freqcap[i][1] + "," + freqcap[i][2];
            if (freqcap.length) base += "&freqcap=" + encodeURIComponent(freqcap.join(";"))
        }
        return base
    },
    getServe: function(serve, placement) {
        var r = new Array;
        r["getbootstrapcom"] = "CKYIKKJL";
        r["fontawesome"] = "CKYIV5QM";
        r["stocksnapio"] = "CKYIV23Y";
        r["mongoosejscom"] = "CKYIL27I";
        r["semanticuicom"] = "CKYIKK7M";
        r["joomlaorg"] = "CKYI553E";
        r["kkorgcooltools"] = "CKYICKJN";
        r["tobiasahlincom"] = "CKYIEKQN";
        r["mindsparklemagcom"] = "CKYIV2JM";
        r["simpledesktopscom"] = "CKYIV53I";
        r["colormindio"] = "CKYIV27W";
        r["adonisjscom"] = "CKYIL23I";
        r["passportjsorg"] = "CKYI523M";
        r["pugjsorg"] = "CKYILKQ7";
        r["gormio"] = "CK7DTKJY";
        r["murzebe"] = "CKYIK27U";
        r["learnshayhowecom"] = "CKYILKJL";
        r["rvmio"] = "CKYI55QN";
        r["silviomoretogithubiobootstrapsel"] = "CKYIKK7I";
        r["cssreferenceio"] = "CKYIK2JU";
        r["searchcodecom"] = "CKYIEKQE";
        r["mjtsaicom"] = "CKYIC53E";
        r["bradfrostwebcom"] = "CKYIV5QE";
        r["thecodebarbariancom"] = "CKYI5K3Y";
        r["csswizardrycom"] = "CKYIK5QI";
        r["callmenickcom"] = "CKYI52J7";
        r["saedsayadcom"] = "CKYIL5QI";
        r["alertifyjs"] = "CKYI55QJ";
        r["sourcemakingcom"] = "CK7DTKJJ";
        r["colorzillacom"] = "CKYIK53N";
        r["bloggetbootstrapcom"] = "CKYIKKJJ";
        r["cubicbeziercom"] = "CKYIPKJ7";
        r["syntaxdbcom"] = "CKYILK3I";
        r["listjscom"] = "CKYIKK7W";
        r["learninglaravel"] = "CKYI527J";
        r["blivesta"] = "CKYI5K7I";
        r["ohshitgitcom"] = "CK7DTKQE";
        r["frontendfrontcom"] = "CKYIEKJU";
        r["pxlnv"] = "CKYICKJW";
        r["tutorialzinecom"] = "CKYIK5QM";
        r["flexboxgridcom"] = "CKYILK3N";
        r["milligramgithubio"] = "CKYIE23J";
        r["htmlreferenceio"] = "CKYI553U";
        r["astronautwebco"] = "CKYIK23W";
        r["botmanio"] = "CKYI52QL";
        r["deanattalicom"] = "CKYIL5Q7";
        r["numeraljscom"] = "CKYIKK7Y";
        r["glotio"] = "CKYIE2JM";
        r["davepaquettecom"] = "CK7DTKJN";
        r["graineditcom"] = "CKYIPK3M";
        r["materialthemecom"] = "CK7DT23I";
        r["osvaldasinfo"] = "CKYI5K77";
        r["bootflat"] = "CKYI5KJY";
        r["dpilv"] = "CKYIPK7N";
        r["jaysalvatcom"] = "CKYI5K7M";
        r["logospirecom"] = "CKYIP23J";
        r["wwwsiiimplecom"] = "CKYIPK3J";
        r["basscsscom"] = "CKYIPKQN";
        r["aisleonenet"] = "CKYIV53W";
        r["coolphptoolscom"] = "CKYIE27Y";
        r["perfectionkillscom"] = "CKYIKK3L";
        r["degoesnet"] = "CKYIC53J";
        r["jxnblkcom"] = "CKYIPKQM";
        r["githubcombevacqua"] = "CKYI5KJW";
        r["1000hzgithubio"] = "CKYIE5QM";
        r["colintohcom"] = "CKYIEKQY";
        r["cssguidelines"] = "CKYIK53L";
        r["simonholywellcom"] = "CKYIK23E";
        r["gedblogcom"] = "CKYIV5QL";
        r["clusterizejsorg"] = "CKYIE53N";
        r["resourcecardscom"] = "CKYIP2QI";
        r["polrprojectorg"] = "CK7DTK7W";
        r["fittextjscom"] = "CKYIK27M";
        r["css3testcom"] = "CKYIEK7U";
        r["thenewsprint"] = "CKYICKJJ";
        r["scoopthemes"] = "CKYIK2JE";
        r["bitshadowgithubio"] = "CKYILK7E";
        r["inspirationmobiletumblrcom"] = "CKYIPKJJ";
        r["responsivebp"] = "CKYIK2QM";
        r["davidwalshname"] = "CKYI5KQL";
        r["codedailyio"] = "CKYIEK7J";
        r["krasimirtsonevcom"] = "CKYIE2QI";
        r["saeedalipoorgithubioicono"] = "CKYIK53W";
        r["blogtdwrightcouk"] = "CK7DT2QL";
        r["aspectratio"] = "CK7DTKQI";
        r["chriswhartonme"] = "CKYILKJM";
        if (this.isset(r[placement]) && (serve == "CVYD42T" || serve == "CVYD42E" || serve == "C6AILKT")) return r[placement];
        else if (serve == "CVYD42T" || serve == "CVYD42E" || serve == "C6AILKT") return "CKYICKQI";
        else return serve
    },
    getUrlVar: function(name, target) {
        target = typeof target !== "undefined" ? target : document.getElementById("_carbonads_js").src, name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(target);
        if (results == null) return "";
        else return results[1]
    },
    ensureHttpsLink: function(link) {
        return link.startsWith("//") ? `https:${link}` : link
    },
    isset: function(v) {
        return typeof v !== "undefined" && v != null
    },
    nonempty: function(v) {
        return this.isset(v) && v != ""
    },
    refresh: function() {
        _carbonads.gotback = false;
        const el = document.getElementById("carbonads");
        this.remove(document.getElementById("_carbonads_projs"));
        this.cleanupObservers();
        this.remove(el);
        this.init()
    },
    reload: function(where, force_serve) {
        _carbonads.gotback = false;
        this.remove(document.getElementById("_carbonads_projs"));
        this.cleanupObservers();
        this.init(where, force_serve)
    },
    remove: function(el) {
        if (typeof el !== "undefined" && el != null) el.parentNode.removeChild(el)
    },
    srv: function() {
        if (_carbonads.SRV_OVERRIDE) {
            return _carbonads.SRV_OVERRIDE
        }
        const baseurl = this.getUrlVar("cd") ? this.getUrlVar("cd") : "srv.carbonads.net";
        return baseurl
    },
    htmlEncode: function(v) {
        return v.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\//g, "&#x2F;")
    },
    hexToRgba: function(hex, alpha = 1) {
        const [r, g, b] = [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)];
        return `rgba(${r}, ${g}, ${b}, ${alpha})`
    },
    prepareAdUrl: function({
        statlink: statlink,
        fallbackLink: fallbackLink
    }, placement) {
        const baseLink = _carbonads.ensureHttpsLink(statlink || fallbackLink).replace(/srv.buysellads.com/g, _carbonads.srv());
        return _carbonads.applyTimestampToUrl(baseLink)
    },
    prepareAdProps: function(ad) {
        const placement = _carbonads.getUrlVar("placement");
        const requiredCarbonCoverKeys = ["backgroundColor", "callToAction", "company", "companyTagline", "logo", "largeImage"];
        const isCarbonCoverSupported = requiredCarbonCoverKeys.every((key => key in ad));
        const availableFormat = isCarbonCoverSupported ? ["cover", "responsive"] : ["responsive"];
        const customCss = _carbonads.isset(ad.custom_css) ? ad.custom_css : "";
        const statview = _bsaViewable.maybeViewableAttr(ad, _carbonads.isset(ad.statview) ? ad.statview + "?segment=placement:" + placement : "");
        const image = ad.image;
        const description = ad.description || ad.title;
        const creativeIdClass = "creativeId-" + ad.creativeid;
        const fulllink = _carbonads.prepareAdUrl(ad, placement);
        const largeImage = ad.largeImage;
        const logo = ad.logo;
        const smallImage = ad.smallImage;
        return {
            availableFormat: availableFormat,
            backgroundColor: ad.backgroundColor,
            callToAction: ad.callToAction,
            company: ad.company,
            companyTagline: ad.companyTagline,
            creativeIdClass: creativeIdClass,
            customCss: customCss,
            description: description,
            fulllink: fulllink,
            image: ad.image,
            smallImage: ad.smallImage,
            largeImage: ad.largeImage,
            logo: ad.logo,
            placement: placement,
            statview: statview,
            textColor: ad.textColor
        }
    },
    appendPixelToElement: function(pixel, el) {
        if (typeof pixel != "undefined") {
            const pixelContainer = document.createElement("div");
            pixelContainer.className = "carbon-pixels";
            pixelContainer.style.display = "none";
            const pixels = pixel.split("||");
            for (let j = 0; j < pixels.length; j++) {
                const pix = document.createElement("img");
                pix.src = _carbonads.applyTimestampToUrl(pixels[j]);
                pix.border = "0";
                pix.height = "1";
                pix.width = "1";
                pix.style.display = "none";
                pix.alt = "ads via Carbon";
                pixelContainer.appendChild(pix)
            }
            el.appendChild(pixelContainer)
        }
    },
    getFormatElement: function(format, adProperties) {
        var hasRichFields = adProperties.availableFormat.includes("cover");
        var hasLargeImage = _carbonads.nonempty(adProperties.largeImage);
        switch (format) {
            case "cover":
                return hasRichFields ? _carbonads.formats.cover(adProperties) : _carbonads.formats.responsive(adProperties);
            case "responsive":
                return hasRichFields ? _carbonads.formats.responsiveRich(adProperties) : _carbonads.formats.responsive(adProperties);
            default:
                return hasLargeImage ? _carbonads.formats.classicLarge(adProperties) : _carbonads.formats.classic(adProperties)
        }
    },
    applyTimestampToUrl: function(url) {
        const time = Math.round(Date.now() / 1e4) | 0;
        return url.replace("[timestamp]", time)
    },
    loadOptimize: function(fallbackOptimizePlacementId, fallbackOptimizeScriptSrvPath) {
        const fallbackOptimizeEl = document.createElement("div");
        fallbackOptimizeEl.id = fallbackOptimizePlacementId;
        document.querySelector("#_carbonads_js").insertAdjacentElement("afterend", fallbackOptimizeEl);
        const optimizeScriptSrvFullPath = `https://cdn4.buysellads.net${fallbackOptimizeScriptSrvPath}?` + (new Date - new Date % 6e5);
        const existingOptimizeScript = document.querySelector(`script[src="${optimizeScriptSrvFullPath}"]`);
        if (existingOptimizeScript) {
            existingOptimizeScript.onload = function() {
                window.optimize.queue.push((() => {
                    window.optimize.push(fallbackOptimizePlacementId)
                }))
            }
        } else {
            const fallbackOptimizeScript = document.createElement("script");
            fallbackOptimizeScript.type = "text/javascript";
            fallbackOptimizeScript.id = "_optimize_js";
            fallbackOptimizeScript.async = true;
            fallbackOptimizeScript.src = optimizeScriptSrvFullPath;
            (document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]).appendChild(fallbackOptimizeScript)
        }
    },
    observeWidth: function(el, className, breakpoint) {
        const observer = new ResizeObserver((function(entries) {
            const isNarrow = entries[0].contentRect.width < breakpoint;
            el.classList.toggle(className, isNarrow)
        }));
        observer.observe(el);
        if (!_carbonads._resizeObservers) {
            _carbonads._resizeObservers = new Set
        }
        _carbonads._resizeObservers.add(observer)
    },
    getFormatBreakpoint: function(format, isRich) {
        if (format === "cover") {
            return {
                className: "carbon-cover--stacked",
                width: 360
            }
        } else if (format === "responsive") {
            return {
                className: "carbon-responsive--narrow",
                width: isRich ? 316 : 200
            }
        }
        return null
    },
    cleanupObservers: function() {
        if (_carbonads._resizeObservers) {
            _carbonads._resizeObservers.forEach((function(observer) {
                observer.disconnect()
            }));
            _carbonads._resizeObservers.clear()
        }
    },
    renderPoweredByLink: function(placement, className) {
        const linkClassName = className || "carbon-poweredby";
        return `<a href="http://carbonads.net/?utm_source=${_carbonads.htmlEncode(placement)}&utm_medium=ad_via_link&utm_campaign=in_unit&utm_term=carbon" class="${linkClassName}" target="_blank" rel="noopener sponsored">ads via Carbon</a>`
    },
    formats: {
        classic: function({
            backgroundColor: backgroundColor,
            customCss: customCss,
            description: description,
            fulllink: fulllink,
            logo: logo,
            smallImage: smallImage,
            placement: placement,
            statview: statview
        }) {
            const imageSrc = _carbonads.isset(smallImage) ? smallImage : logo;
            const imageAttributes = _carbonads.isset(backgroundColor) && _carbonads.isset(logo) ? `style="background:${backgroundColor};width:100px;padding: 30px 15px;box-sizing: content-box;"` : 'height="100" width="130"';
            const el = document.createElement("span");
            el.innerHTML = `\n${customCss?"<style>"+customCss+"</style>":""}\n<span class="carbon-wrap">\n\t<a href="${fulllink}" class="carbon-img" target="_blank" rel="noopener sponsored">\n\t\t<img src="${imageSrc}" alt="ads via Carbon" border="0" ${imageAttributes} ${statview} />\n\t</a>\n\t<a href="${fulllink}" class="carbon-text" target="_blank" rel="noopener sponsored">\n\t\t${_carbonads.htmlEncode(description)}\n\t</a>\n</span>\n${_carbonads.renderPoweredByLink(placement)}\n`;
            return el
        },
        classicLarge: function({
            customCss: customCss,
            description: description,
            fulllink: fulllink,
            largeImage: largeImage,
            placement: placement,
            statview: statview
        }) {
            const el = document.createElement("span");
            el.innerHTML = `\n${customCss?"<style>"+customCss+"</style>":""}\n<span class="carbon-wrap carbon-wrap-large">\n\t<a href="${fulllink}" class="carbon-img carbon-img-large" target="_blank" rel="noopener sponsored">\n\t\t<img src="${largeImage}" alt="ads via Carbon" border="0" width="100" height="100" ${statview} />\n\t</a>\n\t<a href="${fulllink}" class="carbon-text" target="_blank" rel="noopener sponsored">\n\t\t${_carbonads.htmlEncode(description)}\n\t</a>\n</span>\n${_carbonads.renderPoweredByLink(placement)}\n`;
            return el
        },
        _responsiveCss: `#carbon-responsive *{line-height:unset;margin:unset;padding:unset}#carbon-responsive{--carbon-padding:1em;--carbon-max-char:20ch;--carbon-bg-primary:#fafafa;--carbon-bg-secondary:#ebebeb;--carbon-text-color:#333;display:flex;flex-direction:column;flex-wrap:wrap;font-family:system-ui,sans-serif;font-size:14px;gap:1ex;line-height:1.5;max-inline-size:400px;min-inline-size:130px}#carbon-responsive .carbon-responsive-wrap{background-color:var(--carbon-bg-primary);border:1px solid var(--carbon-bg-secondary);display:flex;flex-wrap:wrap;gap:var(--carbon-padding);padding:var(--carbon-padding)}#carbon-responsive .carbon-responsive-wrap-bg{border:none;overflow:hidden;position:relative}#carbon-responsive .carbon-responsive-wrap-bg:after,#carbon-responsive .carbon-responsive-wrap-bg:before{content:"";inset:0;position:absolute}#carbon-responsive .carbon-responsive-wrap-bg:before{background-position:50%;background-repeat:no-repeat;background-size:cover;z-index:0}#carbon-responsive .carbon-responsive-wrap-bg:after{backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);z-index:1}#carbon-responsive .carbon-responsive-wrap-bg>*{z-index:2}#carbon-responsive .carbon-responsive-wrap-bg,#carbon-responsive .carbon-responsive-wrap-bg a,#carbon-responsive .carbon-responsive-wrap-bg a:hover{color:#fff}#carbon-responsive a{text-decoration:none}#carbon-responsive a,#carbon-responsive a:hover{color:var(--carbon-text-color)}#carbon-responsive .carbon-img{flex:0 0 130px}#carbon-responsive .carbon-img img{display:block}#carbon-responsive .carbon-img-large{flex:0 0 100px}#carbon-responsive .carbon-img-large img{height:100px;-o-object-fit:cover;object-fit:cover;width:100px}#carbon-responsive .carbon-logo{display:block;flex-shrink:0;height:30px;width:auto}#carbon-responsive .carbon-tagline{display:block;font-weight:600;line-height:1.3}#carbon-responsive .carbon-img-large~.carbon-text{font-size:.85em}#carbon-responsive .carbon-text{flex-basis:var(--carbon-max-char);flex-grow:1;line-height:1.4;text-align:left}#carbon-responsive .carbon-responsive-wrap-bg .carbon-text{align-items:flex-start;display:flex;flex-direction:column;gap:2px}#carbon-responsive .carbon-description{color:inherit;display:block}#carbon-responsive .carbon-poweredby{color:inherit;font-size:.85em;opacity:.5;text-align:right}@keyframes carbon-fade-in{0%{opacity:0}to{opacity:1}}#carbon-responsive{animation:carbon-fade-in .4s ease-out both}#carbon-responsive.carbon-responsive--narrow .carbon-img,#carbon-responsive.carbon-responsive--narrow .carbon-img-large{flex:0 0 100%}#carbon-responsive.carbon-responsive--narrow .carbon-img img,#carbon-responsive.carbon-responsive--narrow .carbon-img-large img{height:auto;width:100%}`,
        responsive: function({
            backgroundColor: backgroundColor,
            customCss: customCss,
            description: description,
            fulllink: fulllink,
            smallImage: smallImage,
            logo: logo,
            placement: placement,
            statview: statview
        }) {
            const imageSrc = _carbonads.isset(smallImage) ? smallImage : logo;
            const imageAttributes = _carbonads.isset(backgroundColor) && _carbonads.isset(logo) ? `style="background:${backgroundColor};width:100px;padding: 30px 15px;box-sizing: content-box;"` : 'height="100" width="130"';
            const el = document.createElement("div");
            el.id = "carbon-responsive";
            el.innerHTML = `\n<style>\n${_carbonads.formats._responsiveCss}\n${customCss}\n</style>\n<div class="carbon-responsive-wrap">\n\t<a href="${fulllink}" class="carbon-img" target="_blank" rel="noopener sponsored">\n\t\t<img src="${imageSrc}" alt="ads via Carbon" border="0" ${imageAttributes} ${statview} />\n\t</a>\n\t<a href="${fulllink}" class="carbon-text" target="_blank" rel="noopener sponsored">\n\t\t<span class="carbon-description">${_carbonads.htmlEncode(description)}</span>\n\t</a>\n</div>\n${_carbonads.renderPoweredByLink(placement)}\n`;
            return el
        },
        responsiveRich: function({
            backgroundColor: backgroundColor,
            companyTagline: companyTagline,
            customCss: customCss,
            description: description,
            fulllink: fulllink,
            largeImage: largeImage,
            logo: logo,
            placement: placement,
            statview: statview,
            textColor: textColor
        }) {
            const hasBackground = _carbonads.isset(backgroundColor);
            const wrapperClassName = `carbon-responsive-wrap${hasBackground?" carbon-responsive-wrap-bg":""}`;
            const backgroundCss = hasBackground ? `#carbon-responsive .carbon-responsive-wrap-bg::before { background-image: url("${largeImage}"); }\n#carbon-responsive .carbon-responsive-wrap-bg::after { background-color: ${_carbonads.hexToRgba(backgroundColor,.8)}; }\n${_carbonads.isset(textColor)?`#carbon-responsive .carbon-responsive-wrap-bg, #carbon-responsive .carbon-responsive-wrap-bg a, #carbon-responsive .carbon-responsive-wrap-bg a:hover { color: ${textColor}; }`:""}` : "";
            const logoMarkup = _carbonads.nonempty(logo) ? `<img class="carbon-logo" src="${logo}" alt="" border="0" />` : "";
            const taglineMarkup = _carbonads.isset(companyTagline) ? `<span class="carbon-tagline">${_carbonads.htmlEncode(companyTagline)}</span>` : "";
            const el = document.createElement("div");
            el.id = "carbon-responsive";
            el.innerHTML = `\n<style>\n${_carbonads.formats._responsiveCss}\n${backgroundCss}\n${customCss}\n</style>\n<div class="${wrapperClassName}">\n\t<a href="${fulllink}" class="carbon-img carbon-img-large" target="_blank" rel="noopener sponsored">\n\t\t<img src="${largeImage}" alt="ads via Carbon" border="0" width="100" height="100" ${statview} />\n\t</a>\n\t<a href="${fulllink}" class="carbon-text" target="_blank" rel="noopener sponsored">\n\t\t${logoMarkup}\n\t\t${taglineMarkup}\n\t\t<span class="carbon-description">${_carbonads.htmlEncode(description)}</span>\n\t</a>\n</div>\n${_carbonads.renderPoweredByLink(placement)}\n`;
            return el
        },
        cover: function({
            backgroundColor: backgroundColor,
            callToAction: callToAction,
            company: company,
            companyTagline: companyTagline,
            creativeIdClass: creativeIdClass,
            customCss: customCss,
            description: description,
            fulllink: fulllink,
            largeImage: largeImage,
            logo: logo,
            placement: placement,
            statview: statview
        }) {
            const bgRgba = _carbonads.hexToRgba(backgroundColor, .8);
            const carbonCoverCss = `#carbon-cover *{line-height:normal;margin:initial;padding:initial}#carbon-cover button{background:none;border:none;color:inherit;cursor:pointer;font:inherit;margin:0;outline:none;padding:0}#carbon-cover .carbon-visually-hidden{clip:rect(0 0 0 0);border:0;height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px}#carbon-cover{--carbon-font-family:system-ui;--carbon-font-size:14px;--carbon-shadow:0 0 1px rgba(0,0,0,.085),0 0 2px rgba(0,0,0,.085),0 0 4px rgba(0,0,0,.085),0 0 8px rgba(0,0,0,.085);--carbon-icon-size:0.75em;align-items:flex-start;display:flex;flex-direction:column;font-family:var(--carbon-font-family);font-size:var(--carbon-font-size);max-inline-size:400px;z-index:10}#carbon-cover>a:first-child{align-items:flex-start;border-radius:6px;box-shadow:var(--carbon-shadow);display:flex;flex-direction:row-reverse;flex-wrap:wrap;gap:2ch;justify-content:center;overflow:hidden;padding:5%;position:relative;text-decoration:none;z-index:2}#carbon-cover>a:first-child:after,#carbon-cover>a:first-child:before{content:"";inset:0;position:absolute}#carbon-cover>a:before{background-position:50%;background-repeat:no-repeat;background-size:cover;z-index:0}#carbon-cover>a:after{backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);content:"";z-index:1}#carbon-cover>a>*{z-index:3}#carbon-cover .carbon-main{color:#fff;display:flex;flex-basis:calc(100% - 250px);flex-direction:column;flex-grow:1;row-gap:1ch}#carbon-cover .carbon-logo{display:flex;flex-direction:column;justify-content:flex-start;min-height:72px}#carbon-cover .carbon-logo img{height:auto;max-width:125px}#carbon-cover .carbon-tagline{font-weight:500;line-height:1.3;margin-top:auto;max-inline-size:16ch}#carbon-cover .carbon-text{align-items:flex-start;display:flex;flex-direction:column;height:100px}#carbon-cover .carbon-description{flex-grow:1;font-size:.9em;line-height:1.35;max-inline-size:54ch;overflow:hidden}#carbon-cover .carbon-cta{background:#fff;border-radius:3px;box-shadow:var(--carbon-shadow);color:#111;font-weight:600;padding:1ex 1ch}#carbon-cover .carbon-large-image{border-radius:5px;box-shadow:var(--carbon-shadow);display:block;max-inline-size:250px;width:50%}#carbon-cover a:hover .carbon-large-image{width:20%}#carbon-cover .carbon-footer{align-items:center;color:grey;-moz-column-gap:1ch;column-gap:1ch;display:flex;justify-content:stretch;margin-block-start:.75ex;position:relative;text-decoration:none;width:100%}#carbon-cover .carbon-footer a{color:#b3b3b3;text-decoration:none}#carbon-cover .carbon-footer button{background-color:#f2f2f2;border-radius:3px;display:grid;padding:.5ch;place-content:center}#carbon-cover .carbon-footer button:hover{background-color:#e6e6e6;transition:background-color .2s ease-in-out}#carbon-cover button>svg{height:var(--carbon-icon-size);stroke:#b3b3b3;stroke-width:3;width:var(--carbon-icon-size)}#carbon-cover .carbon-via{font-size:.9em;margin-left:auto}#carbon-cover .carbon-footer a.carbon-no-hover .carbon-share{display:none;position:relative}#carbon-cover .carbon-share-icon:not(.carbon-no-hover):hover+.carbon-share,#carbon-cover .carbon-share:hover{opacity:1;z-index:3}#carbon-cover .carbon-share-icon:not(.carbon-no-hover):hover:before{content:"";display:block;height:5ex;position:absolute;top:-10px;width:14ch;z-index:2}#carbon-cover .carbon-share{background-color:#fff;border:1px solid #ccc;border-radius:5px;bottom:calc(var(--carbon-icon-size) + 14px);box-shadow:var(--carbon-shadow);left:0;opacity:0;padding:.2em;position:absolute;transition:opacity .2s ease-in-out}#carbon-cover .carbon-share ul{color:#212121;font-size:12px;font-weight:500;list-style-type:none;padding:.5em}#carbon-cover .carbon-share ul>*+*{margin-top:10px}#carbon-cover .carbon-description{opacity:0;transition:opacity .1s ease-out}#carbon-cover a:hover .carbon-description{opacity:1;transition:opacity .5s ease-in .25s}#carbon-cover .carbon-large-image{transition:width .25s ease-in-out}#carbon-cover .carbon-main{transition:opacity .01s ease-in-out}@property --reveal-mask{syntax:"<percentage>";initial-value:0%;inherits:false}#carbon-cover .carbon-reveal{animation:var(--reveal-duration,1.5s) var(--reveal-delay,0s) carbon-reveal forwards;-webkit-mask-image:linear-gradient(var(--reveal-angle,135deg),#000 calc(var(--reveal-mask) - 100%),transparent var(--reveal-mask))}@keyframes carbon-reveal{70%,to{--reveal-mask:200%}}#carbon-cover.carbon-cover--stacked>a:first-child{aspect-ratio:unset}#carbon-cover.carbon-cover--stacked .carbon-large-image{max-width:100%;width:unset}#carbon-cover.carbon-cover--stacked a:hover .carbon-large-image{width:unset}#carbon-cover.carbon-cover--stacked .carbon-logo{min-height:unset;row-gap:1ch}#carbon-cover.carbon-cover--stacked .carbon-text{align-items:stretch;height:unset;row-gap:1ch}#carbon-cover.carbon-cover--stacked .carbon-tagline{max-inline-size:unset;min-height:unset}#carbon-cover.carbon-cover--stacked .carbon-description{flex-grow:unset;line-height:1.4;opacity:unset}#carbon-cover.carbon-cover--stacked .carbon-cta{align-self:stretch;text-align:center}`;
            const carbonCoverHtml = `\n\t\t\t<style>\n\t\t\t\t${carbonCoverCss}\n\t\t\t\t.${creativeIdClass} > a:first-child::after {\n\t\t\t\t\tbackground-color: ${bgRgba};\n\t\t\t\t}\n\t\t\t\t.${creativeIdClass} > a:first-child::before {\n\t\t\t\t\tbackground-image: url('${largeImage}')\n\t\t\t\t}\n\t\t\t\t${customCss}\n\t\t\t</style>\n\t\t\t<img class="carbon-large-image" src="${largeImage}" alt="${_carbonads.htmlEncode(company)}" border="0" ${statview} />\n\t\t\t<div class="carbon-main">\n\t\t\t\t<div class="carbon-logo">\n\t\t\t\t\t<img src="${logo}" alt="" border="0" />\n\t\t\t\t\t<div class="carbon-tagline">${_carbonads.htmlEncode(companyTagline)}</div>\n\t\t\t\t</div>\n\t\t\t\t<div class="carbon-text">\n\t\t\t\t\t<div class="carbon-description">${_carbonads.htmlEncode(description)}</div>\n\t\t\t\t\t<div class="carbon-cta">${_carbonads.htmlEncode(callToAction)}</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t`;
            const carbonFooterHtml = `\n\t\t\t<button class="carbon-share-icon">\n\t\t\t\t<span class="carbon-visually-hidden">Share Carbon Ad Icon</span>\n\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8M16 6l-4-4-4 4M12 2v13"/></svg>\n\t\t\t</button>\n\t\t\t<div class="carbon-share">\n\t\t\t\t<ul>\n\t\t\t\t\t<li><a href="#" id="carbonCopyLink">Copy Link</a></li>\n\t\t\t\t\t<li><a href="#" id="carbonEmailLink">Send via email</a></li>\n\t\t\t\t</ul>\n\t\t\t</div>\n\t\t\t<button id="carbon-refresh">\n\t\t\t\t<span class="carbon-visually-hidden">Refresh Carbon Ad</span>\n\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>\n\t\t\t</button>\n\t\t\t${_carbonads.renderPoweredByLink(placement,"carbon-via")}\n\t\t\t`;
            const carbonCoverEl = document.createElement("a");
            carbonCoverEl.href = fulllink;
            carbonCoverEl.rel = "noopener sponsored";
            carbonCoverEl.target = "_blank";
            carbonCoverEl.className = "carbon-reveal";
            carbonCoverEl.innerHTML = carbonCoverHtml;
            const carbonFooterEl = document.createElement("div");
            carbonFooterEl.className = "carbon-footer";
            carbonFooterEl.innerHTML = carbonFooterHtml;
            const el = document.createElement("div");
            el.appendChild(carbonCoverEl);
            el.appendChild(carbonFooterEl);
            el.id = "carbon-cover";
            el.classList.add(creativeIdClass);
            return el
        },
        _addEventListeners: function(ad, format) {
            const {
                company: company,
                companyTagline: companyTagline,
                description: description,
                fulllink: fulllink
            } = ad;
            if (format === "cover") {
                const carbonRefreshButton = document.querySelector("#carbon-refresh");
                if (carbonRefreshButton) {
                    carbonRefreshButton.addEventListener("click", (() => {
                        _carbonads.refresh()
                    }))
                }
                if (navigator.share) {
                    const carbonShareButton = document.querySelector(".carbon-share-icon");
                    if (carbonShareButton) {
                        carbonShareButton.classList.add("carbon-no-hover");
                        carbonShareButton.addEventListener("click", (function() {
                            navigator.share({
                                title: "Carbon Ad for " + company,
                                text: company + "\n" + companyTagline + "\n" + description,
                                url: fulllink
                            }).catch((error => {
                                console.log("Error sharing", error)
                            }))
                        }))
                    }
                } else {
                    const carbonCopyLinkButton = document.getElementById("carbonCopyLink");
                    const carbonEmailLinkButton = document.getElementById("carbonEmailLink");
                    if (carbonCopyLinkButton && carbonEmailLinkButton) {
                        carbonCopyLinkButton.addEventListener("click", (function(e) {
                            e.preventDefault();
                            const textArea = document.createElement("textarea");
                            textArea.value = fulllink;
                            document.body.appendChild(textArea);
                            textArea.select();
                            document.execCommand("Copy");
                            textArea.remove()
                        }));
                        carbonEmailLinkButton.addEventListener("click", (function(e) {
                            e.preventDefault();
                            const subject = "Carbon Ad for " + company;
                            const body = `${company}\n${companyTagline}\n${description}\n${fulllink}`;
                            window.location.href = "mailto:?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body)
                        }))
                    }
                }
            }
        }
    }
};

function _carbonads_go(b) {
    if (!b) return;
    const format = _carbonads.getUrlVar("format");
    const placement = _carbonads.getUrlVar("placement");
    const ad = b["ads"][0];
    if (!_carbonads.nonempty(ad.statlink) && (!(_carbonads.nonempty(ad.fallbackImage) && _carbonads.nonempty(ad.fallbackLink) && _carbonads.nonempty(ad.fallbackTitle)) || !_carbonads.nonempty(ad.fallbackZoneKey)) && !(_carbonads.nonempty(ad.fallbackImage) && _carbonads.nonempty(ad.fallbackLink) && _carbonads.nonempty(ad.fallbackTitle))) {
        if (_carbonads.isset(ad.fallbackOptimizePlacementId)) {
            _carbonads.loadOptimize(ad.fallbackOptimizePlacementId, ad.fallbackOptimizeScriptSrvPath);
            return
        }
        var fallbackKey = _carbonads.nonempty(ad.fallbackZoneKey) ? ad.fallbackZoneKey : "CK7DT53I";
        if (_carbonads.gotback === fallbackKey) {
            return
        }
        _carbonads.gotback = fallbackKey;
        var fallbackSrc = _carbonads._buildSrvUrl("https://" + _carbonads.srv() + "/ads/" + fallbackKey + ".json?segment=placement:" + placement);
        if (ad.fallbackTitle !== "hide") {
            if (_carbonads.isset(ad.custom_css)) {
                const customCssEl = document.createElement("style");
                customCssEl.innerHTML = ad.custom_css;
                document.querySelector("#_carbonads_js").appendChild(customCssEl)
            }
            _carbonads._loadJson(fallbackSrc, _carbonads_go)
        }
        return
    }
    const fallbackAd = {
        backgroundColor: ad.fallbackBackgroundColor,
        callToAction: ad.fallbackCallToAction,
        company: ad.fallbackCompany,
        companyTagline: ad.fallbackCompanyTagline,
        fallbackLink: ad.fallbackLink,
        smallImage: ad.fallbackImage,
        largeImage: ad.fallbackLargeImage,
        logo: ad.fallbackLogo,
        title: ad.fallbackTitle
    };
    const adProperties = _carbonads.nonempty(ad.statlink) ? _carbonads.prepareAdProps(ad) : _carbonads.prepareAdProps(fallbackAd);
    var n = document.getElementsByClassName("carbon-wrap");
    var fdiv = document.createElement("div");
    fdiv.id = n.length > 0 ? "carbonads_" + n.length : "carbonads";
    var hasRichFields = adProperties.availableFormat.includes("cover");
    const carbonEl = _carbonads.getFormatElement(format, adProperties);
    fdiv.appendChild(carbonEl);
    _carbonads.appendPixelToElement(ad.pixel, carbonEl);
    _bsaViewable.observe(carbonEl);
    var carbonjs = document.getElementById("_carbonads_js");
    if (carbonjs != null) {
        if (_carbonads.isset(_carbon_where)) {
            _carbon_where.appendChild(fdiv)
        } else {
            carbonjs.parentNode.insertBefore(fdiv, carbonjs.nextSibling)
        }
    }
    var breakpoint = _carbonads.getFormatBreakpoint(format, hasRichFields);
    if (breakpoint) {
        _carbonads.observeWidth(carbonEl, breakpoint.className, breakpoint.width)
    }
    _bsap_serving_callback(ad.bannerid, ad.zonekey, ad.freqcap);
    if (_carbonads.nonempty(ad.fallbackTitle) && !_carbonads.nonempty(ad.statlink)) {
        document.querySelector(".carbon-poweredby") ? .remove();
        document.querySelector(".carbon-via") ? .remove();
        if (ad.fallbackTitle === "hide") _carbonads.remove(document.getElementById("carbonads"))
    }
    _carbonads.formats._addEventListeners(adProperties, format)
}
_carbonads.init();
window["_bsap_serving_callback"] = function(banner, zone, freqcap) {
    var append = function(w, data, days) {
        var c = document.cookie,
            i = c.indexOf(w + "="),
            existing = i >= 0 ? c.substring(i + w.length + 1).split(";")[0] + "%2C" : "",
            d = new Date;
        d.setTime(days * 36e5 + d);
        data = existing + data;
        data = data.substring(0, 2048);
        document.cookie = w + "=" + data + "; expires=" + d.toGMTString() + "; SameSite=Lax; path=/"
    };
    if (freqcap) {
        append("_bsap_daycap", banner, 1);
        append("_bsap_lifecap", banner, 365)
    }
};