import {
    e as Te,
    q as Ce
} from "./chunk-WXAKRBIO.js";
import {
    a as lt,
    c as ut
} from "./chunk-DCANE7XH.js";
var Ye = lt((rn, Xe) => {
    function me(e) {
        return e instanceof Map ? e.clear = e.delete = e.set = function() {
            throw new Error("map is read-only")
        } : e instanceof Set && (e.add = e.clear = e.delete = function() {
            throw new Error("set is read-only")
        }), Object.freeze(e), Object.getOwnPropertyNames(e).forEach(t => {
            let i = e[t],
                a = typeof i;
            (a === "object" || a === "function") && !Object.isFrozen(i) && me(i)
        }), e
    }
    var ie = class {
        constructor(t) {
            t.data === void 0 && (t.data = {}), this.data = t.data, this.isMatchIgnored = !1
        }
        ignoreMatch() {
            this.isMatchIgnored = !0
        }
    };

    function Pe(e) {
        return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;")
    }

    function v(e, ...t) {
        let i = Object.create(null);
        for (let a in e) i[a] = e[a];
        return t.forEach(function(a) {
            for (let _ in a) i[_] = a[_]
        }), i
    }
    var gt = "</span>",
        Ie = e => !!e.scope,
        ft = (e, {
            prefix: t
        }) => {
            if (e.startsWith("language:")) return e.replace("language:", "language-");
            if (e.includes(".")) {
                let i = e.split(".");
                return [`${t}${i.shift()}`, ...i.map((a, _) => `${a}${"_".repeat(_+1)}`)].join(" ")
            }
            return `${t}${e}`
        },
        pe = class {
            constructor(t, i) {
                this.buffer = "", this.classPrefix = i.classPrefix, t.walk(this)
            }
            addText(t) {
                this.buffer += Pe(t)
            }
            openNode(t) {
                if (!Ie(t)) return;
                let i = ft(t.scope, {
                    prefix: this.classPrefix
                });
                this.span(i)
            }
            closeNode(t) {
                Ie(t) && (this.buffer += gt)
            }
            value() {
                return this.buffer
            }
            span(t) {
                this.buffer += `<span class="${t}">`
            }
        },
        Le = (e = {}) => {
            let t = {
                children: []
            };
            return Object.assign(t, e), t
        },
        Ee = class e {
            constructor() {
                this.rootNode = Le(), this.stack = [this.rootNode]
            }
            get top() {
                return this.stack[this.stack.length - 1]
            }
            get root() {
                return this.rootNode
            }
            add(t) {
                this.top.children.push(t)
            }
            openNode(t) {
                let i = Le({
                    scope: t
                });
                this.add(i), this.stack.push(i)
            }
            closeNode() {
                if (this.stack.length > 1) return this.stack.pop()
            }
            closeAllNodes() {
                for (; this.closeNode(););
            }
            toJSON() {
                return JSON.stringify(this.rootNode, null, 4)
            }
            walk(t) {
                return this.constructor._walk(t, this.rootNode)
            }
            static _walk(t, i) {
                return typeof i == "string" ? t.addText(i) : i.children && (t.openNode(i), i.children.forEach(a => this._walk(t, a)), t.closeNode(i)), t
            }
            static _collapse(t) {
                typeof t != "string" && t.children && (t.children.every(i => typeof i == "string") ? t.children = [t.children.join("")] : t.children.forEach(i => {
                    e._collapse(i)
                }))
            }
        },
        be = class extends Ee {
            constructor(t) {
                super(), this.options = t
            }
            addText(t) {
                t !== "" && this.add(t)
            }
            startScope(t) {
                this.openNode(t)
            }
            endScope() {
                this.closeNode()
            }
            __addSublanguage(t, i) {
                let a = t.root;
                i && (a.scope = `language:${i}`), this.add(a)
            }
            toHTML() {
                return new pe(this, this.options).value()
            }
            finalize() {
                return this.closeAllNodes(), !0
            }
        };

    function X(e) {
        return e ? typeof e == "string" ? e : e.source : null
    }

    function $e(e) {
        return U("(?=", e, ")")
    }

    function ht(e) {
        return U("(?:", e, ")*")
    }

    function dt(e) {
        return U("(?:", e, ")?")
    }

    function U(...e) {
        return e.map(i => X(i)).join("")
    }

    function pt(e) {
        let t = e[e.length - 1];
        return typeof t == "object" && t.constructor === Object ? (e.splice(e.length - 1, 1), t) : {}
    }

    function Se(...e) {
        return "(" + (pt(e).capture ? "" : "?:") + e.map(a => X(a)).join("|") + ")"
    }

    function Ue(e) {
        return new RegExp(e.toString() + "|").exec("").length - 1
    }

    function Et(e, t) {
        let i = e && e.exec(t);
        return i && i.index === 0
    }
    var bt = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;

    function Ne(e, {
        joinWith: t
    }) {
        let i = 0;
        return e.map(a => {
            i += 1;
            let _ = i,
                S = X(a),
                c = "";
            for (; S.length > 0;) {
                let r = bt.exec(S);
                if (!r) {
                    c += S;
                    break
                }
                c += S.substring(0, r.index), S = S.substring(r.index + r[0].length), r[0][0] === "\\" && r[1] ? c += "\\" + String(Number(r[1]) + _) : (c += r[0], r[0] === "(" && i++)
            }
            return c
        }).map(a => `(${a})`).join(t)
    }
    var _t = /\b\B/,
        He = "[a-zA-Z]\\w*",
        Ae = "[a-zA-Z_]\\w*",
        Ge = "\\b\\d+(\\.\\d+)?",
        ze = "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)",
        Fe = "\\b(0b[01]+)",
        St = "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~",
        Nt = (e = {}) => {
            let t = /^#![ ]*\//;
            return e.binary && (e.begin = U(t, /.*\b/, e.binary, /\b.*/)), v({
                scope: "meta",
                begin: t,
                end: /$/,
                relevance: 0,
                "on:begin": (i, a) => {
                    i.index !== 0 && a.ignoreMatch()
                }
            }, e)
        },
        Y = {
            begin: "\\\\[\\s\\S]",
            relevance: 0
        },
        At = {
            scope: "string",
            begin: "'",
            end: "'",
            illegal: "\\n",
            contains: [Y]
        },
        Mt = {
            scope: "string",
            begin: '"',
            end: '"',
            illegal: "\\n",
            contains: [Y]
        },
        yt = {
            begin: /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/
        },
        re = function(e, t, i = {}) {
            let a = v({
                scope: "comment",
                begin: e,
                end: t,
                contains: []
            }, i);
            a.contains.push({
                scope: "doctag",
                begin: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)",
                end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/,
                excludeBegin: !0,
                relevance: 0
            });
            let _ = Se("I", "a", "is", "so", "us", "to", "at", "if", "in", "it", "on", /[A-Za-z]+['](d|ve|re|ll|t|s|n)/, /[A-Za-z]+[-][a-z]+/, /[A-Za-z][a-z]{2,}/);
            return a.contains.push({
                begin: U(/[ ]+/, "(", _, /[.]?[:]?([.][ ]|[ ])/, "){3}")
            }), a
        },
        Ot = re("//", "$"),
        wt = re("/\\*", "\\*/"),
        Rt = re("#", "$"),
        xt = {
            scope: "number",
            begin: Ge,
            relevance: 0
        },
        Tt = {
            scope: "number",
            begin: ze,
            relevance: 0
        },
        Ct = {
            scope: "number",
            begin: Fe,
            relevance: 0
        },
        It = {
            scope: "regexp",
            begin: /\/(?=[^/\n]*\/)/,
            end: /\/[gimuy]*/,
            contains: [Y, {
                begin: /\[/,
                end: /\]/,
                relevance: 0,
                contains: [Y]
            }]
        },
        Lt = {
            scope: "title",
            begin: He,
            relevance: 0
        },
        kt = {
            scope: "title",
            begin: Ae,
            relevance: 0
        },
        vt = {
            begin: "\\.\\s*" + Ae,
            relevance: 0
        },
        Bt = function(e) {
            return Object.assign(e, {
                "on:begin": (t, i) => {
                    i.data._beginMatch = t[1]
                },
                "on:end": (t, i) => {
                    i.data._beginMatch !== t[1] && i.ignoreMatch()
                }
            })
        },
        ne = Object.freeze({
            __proto__: null,
            APOS_STRING_MODE: At,
            BACKSLASH_ESCAPE: Y,
            BINARY_NUMBER_MODE: Ct,
            BINARY_NUMBER_RE: Fe,
            COMMENT: re,
            C_BLOCK_COMMENT_MODE: wt,
            C_LINE_COMMENT_MODE: Ot,
            C_NUMBER_MODE: Tt,
            C_NUMBER_RE: ze,
            END_SAME_AS_BEGIN: Bt,
            HASH_COMMENT_MODE: Rt,
            IDENT_RE: He,
            MATCH_NOTHING_RE: _t,
            METHOD_GUARD: vt,
            NUMBER_MODE: xt,
            NUMBER_RE: Ge,
            PHRASAL_WORDS_MODE: yt,
            QUOTE_STRING_MODE: Mt,
            REGEXP_MODE: It,
            RE_STARTERS_RE: St,
            SHEBANG: Nt,
            TITLE_MODE: Lt,
            UNDERSCORE_IDENT_RE: Ae,
            UNDERSCORE_TITLE_MODE: kt
        });

    function Dt(e, t) {
        e.input[e.index - 1] === "." && t.ignoreMatch()
    }

    function mt(e, t) {
        e.className !== void 0 && (e.scope = e.className, delete e.className)
    }

    function Pt(e, t) {
        t && e.beginKeywords && (e.begin = "\\b(" + e.beginKeywords.split(" ").join("|") + ")(?!\\.)(?=\\b|\\s)", e.__beforeBegin = Dt, e.keywords = e.keywords || e.beginKeywords, delete e.beginKeywords, e.relevance === void 0 && (e.relevance = 0))
    }

    function $t(e, t) {
        Array.isArray(e.illegal) && (e.illegal = Se(...e.illegal))
    }

    function Ut(e, t) {
        if (e.match) {
            if (e.begin || e.end) throw new Error("begin & end are not supported with match");
            e.begin = e.match, delete e.match
        }
    }

    function Ht(e, t) {
        e.relevance === void 0 && (e.relevance = 1)
    }
    var Gt = (e, t) => {
            if (!e.beforeMatch) return;
            if (e.starts) throw new Error("beforeMatch cannot be used with starts");
            let i = Object.assign({}, e);
            Object.keys(e).forEach(a => {
                delete e[a]
            }), e.keywords = i.keywords, e.begin = U(i.beforeMatch, $e(i.begin)), e.starts = {
                relevance: 0,
                contains: [Object.assign(i, {
                    endsParent: !0
                })]
            }, e.relevance = 0, delete i.beforeMatch
        },
        zt = ["of", "and", "for", "in", "not", "or", "if", "then", "parent", "list", "value"],
        Ft = "keyword";

    function Ze(e, t, i = Ft) {
        let a = Object.create(null);
        return typeof e == "string" ? _(i, e.split(" ")) : Array.isArray(e) ? _(i, e) : Object.keys(e).forEach(function(S) {
            Object.assign(a, Ze(e[S], t, S))
        }), a;

        function _(S, c) {
            t && (c = c.map(r => r.toLowerCase())), c.forEach(function(r) {
                let u = r.split("|");
                a[u[0]] = [S, Zt(u[0], u[1])]
            })
        }
    }

    function Zt(e, t) {
        return t ? Number(t) : jt(e) ? 0 : 1
    }

    function jt(e) {
        return zt.includes(e.toLowerCase())
    }
    var ke = {},
        $ = e => {
            console.error(e)
        },
        ve = (e, ...t) => {
            console.log(`WARN: ${e}`, ...t)
        },
        F = (e, t) => {
            ke[`${e}/${t}`] || (console.log(`Deprecated as of ${e}. ${t}`), ke[`${e}/${t}`] = !0)
        },
        se = new Error;

    function je(e, t, {
        key: i
    }) {
        let a = 0,
            _ = e[i],
            S = {},
            c = {};
        for (let r = 1; r <= t.length; r++) c[r + a] = _[r], S[r + a] = !0, a += Ue(t[r - 1]);
        e[i] = c, e[i]._emit = S, e[i]._multi = !0
    }

    function Kt(e) {
        if (Array.isArray(e.begin)) {
            if (e.skip || e.excludeBegin || e.returnBegin) throw $("skip, excludeBegin, returnBegin not compatible with beginScope: {}"), se;
            if (typeof e.beginScope != "object" || e.beginScope === null) throw $("beginScope must be object"), se;
            je(e, e.begin, {
                key: "beginScope"
            }), e.begin = Ne(e.begin, {
                joinWith: ""
            })
        }
    }

    function Wt(e) {
        if (Array.isArray(e.end)) {
            if (e.skip || e.excludeEnd || e.returnEnd) throw $("skip, excludeEnd, returnEnd not compatible with endScope: {}"), se;
            if (typeof e.endScope != "object" || e.endScope === null) throw $("endScope must be object"), se;
            je(e, e.end, {
                key: "endScope"
            }), e.end = Ne(e.end, {
                joinWith: ""
            })
        }
    }

    function Xt(e) {
        e.scope && typeof e.scope == "object" && e.scope !== null && (e.beginScope = e.scope, delete e.scope)
    }

    function Yt(e) {
        Xt(e), typeof e.beginScope == "string" && (e.beginScope = {
            _wrap: e.beginScope
        }), typeof e.endScope == "string" && (e.endScope = {
            _wrap: e.endScope
        }), Kt(e), Wt(e)
    }

    function Jt(e) {
        function t(c, r) {
            return new RegExp(X(c), "m" + (e.case_insensitive ? "i" : "") + (e.unicodeRegex ? "u" : "") + (r ? "g" : ""))
        }
        class i {
            constructor() {
                this.matchIndexes = {}, this.regexes = [], this.matchAt = 1, this.position = 0
            }
            addRule(r, u) {
                u.position = this.position++, this.matchIndexes[this.matchAt] = u, this.regexes.push([u, r]), this.matchAt += Ue(r) + 1
            }
            compile() {
                this.regexes.length === 0 && (this.exec = () => null);
                let r = this.regexes.map(u => u[1]);
                this.matcherRe = t(Ne(r, {
                    joinWith: "|"
                }), !0), this.lastIndex = 0
            }
            exec(r) {
                this.matcherRe.lastIndex = this.lastIndex;
                let u = this.matcherRe.exec(r);
                if (!u) return null;
                let N = u.findIndex((k, T) => T > 0 && k !== void 0),
                    A = this.matchIndexes[N];
                return u.splice(0, N), Object.assign(u, A)
            }
        }
        class a {
            constructor() {
                this.rules = [], this.multiRegexes = [], this.count = 0, this.lastIndex = 0, this.regexIndex = 0
            }
            getMatcher(r) {
                if (this.multiRegexes[r]) return this.multiRegexes[r];
                let u = new i;
                return this.rules.slice(r).forEach(([N, A]) => u.addRule(N, A)), u.compile(), this.multiRegexes[r] = u, u
            }
            resumingScanAtSamePosition() {
                return this.regexIndex !== 0
            }
            considerAll() {
                this.regexIndex = 0
            }
            addRule(r, u) {
                this.rules.push([r, u]), u.type === "begin" && this.count++
            }
            exec(r) {
                let u = this.getMatcher(this.regexIndex);
                u.lastIndex = this.lastIndex;
                let N = u.exec(r);
                if (this.resumingScanAtSamePosition() && !(N && N.index === this.lastIndex)) {
                    let A = this.getMatcher(0);
                    A.lastIndex = this.lastIndex + 1, N = A.exec(r)
                }
                return N && (this.regexIndex += N.position + 1, this.regexIndex === this.count && this.considerAll()), N
            }
        }

        function _(c) {
            let r = new a;
            return c.contains.forEach(u => r.addRule(u.begin, {
                rule: u,
                type: "begin"
            })), c.terminatorEnd && r.addRule(c.terminatorEnd, {
                type: "end"
            }), c.illegal && r.addRule(c.illegal, {
                type: "illegal"
            }), r
        }

        function S(c, r) {
            let u = c;
            if (c.isCompiled) return u;
            [mt, Ut, Yt, Gt].forEach(A => A(c, r)), e.compilerExtensions.forEach(A => A(c, r)), c.__beforeBegin = null, [Pt, $t, Ht].forEach(A => A(c, r)), c.isCompiled = !0;
            let N = null;
            return typeof c.keywords == "object" && c.keywords.$pattern && (c.keywords = Object.assign({}, c.keywords), N = c.keywords.$pattern, delete c.keywords.$pattern), N = N || /\w+/, c.keywords && (c.keywords = Ze(c.keywords, e.case_insensitive)), u.keywordPatternRe = t(N, !0), r && (c.begin || (c.begin = /\B|\b/), u.beginRe = t(u.begin), !c.end && !c.endsWithParent && (c.end = /\B|\b/), c.end && (u.endRe = t(u.end)), u.terminatorEnd = X(u.end) || "", c.endsWithParent && r.terminatorEnd && (u.terminatorEnd += (c.end ? "|" : "") + r.terminatorEnd)), c.illegal && (u.illegalRe = t(c.illegal)), c.contains || (c.contains = []), c.contains = [].concat(...c.contains.map(function(A) {
                return qt(A === "self" ? c : A)
            })), c.contains.forEach(function(A) {
                S(A, u)
            }), c.starts && S(c.starts, r), u.matcher = _(u), u
        }
        if (e.compilerExtensions || (e.compilerExtensions = []), e.contains && e.contains.includes("self")) throw new Error("ERR: contains `self` is not supported at the top-level of a language.  See documentation.");
        return e.classNameAliases = v(e.classNameAliases || {}), S(e)
    }

    function Ke(e) {
        return e ? e.endsWithParent || Ke(e.starts) : !1
    }

    function qt(e) {
        return e.variants && !e.cachedVariants && (e.cachedVariants = e.variants.map(function(t) {
            return v(e, {
                variants: null
            }, t)
        })), e.cachedVariants ? e.cachedVariants : Ke(e) ? v(e, {
            starts: e.starts ? v(e.starts) : null
        }) : Object.isFrozen(e) ? v(e) : e
    }
    var Vt = "11.11.1",
        _e = class extends Error {
            constructor(t, i) {
                super(t), this.name = "HTMLInjectionError", this.html = i
            }
        },
        de = Pe,
        Be = v,
        De = Symbol("nomatch"),
        Qt = 7,
        We = function(e) {
            let t = Object.create(null),
                i = Object.create(null),
                a = [],
                _ = !0,
                S = "Could not find the language '{}', did you forget to load/include a language module?",
                c = {
                    disableAutodetect: !0,
                    name: "Plain text",
                    contains: []
                },
                r = {
                    ignoreUnescapedHTML: !1,
                    throwUnescapedHTML: !1,
                    noHighlightRe: /^(no-?highlight)$/i,
                    languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i,
                    classPrefix: "hljs-",
                    cssSelector: "pre code",
                    languages: null,
                    __emitter: be
                };

            function u(n) {
                return r.noHighlightRe.test(n)
            }

            function N(n) {
                let l = n.className + " ";
                l += n.parentNode ? n.parentNode.className : "";
                let g = r.languageDetectRe.exec(l);
                if (g) {
                    let d = x(g[1]);
                    return d || (ve(S.replace("{}", g[1])), ve("Falling back to no-highlight mode for this block.", n)), d ? g[1] : "no-highlight"
                }
                return l.split(/\s+/).find(d => u(d) || x(d))
            }

            function A(n, l, g) {
                let d = "",
                    b = "";
                typeof l == "object" ? (d = n, g = l.ignoreIllegals, b = l.language) : (F("10.7.0", "highlight(lang, code, ...args) has been deprecated."), F("10.7.0", `Please use highlight(code, options) instead.
https://github.com/highlightjs/highlight.js/issues/2277`), b = n, d = l), g === void 0 && (g = !0);
                let y = {
                    code: d,
                    language: b
                };
                z("before:highlight", y);
                let R = y.result ? y.result : k(y.language, y.code, g);
                return R.code = y.code, z("after:highlight", R), R
            }

            function k(n, l, g, d) {
                let b = Object.create(null);

                function y(s, o) {
                    return s.keywords[o]
                }

                function R() {
                    if (!f.keywords) {
                        M.addText(E);
                        return
                    }
                    let s = 0;
                    f.keywordPatternRe.lastIndex = 0;
                    let o = f.keywordPatternRe.exec(E),
                        h = "";
                    for (; o;) {
                        h += E.substring(s, o.index);
                        let p = I.case_insensitive ? o[0].toLowerCase() : o[0],
                            O = y(f, p);
                        if (O) {
                            let [L, at] = O;
                            if (M.addText(h), h = "", b[p] = (b[p] || 0) + 1, b[p] <= Qt && (te += at), L.startsWith("_")) h += o[0];
                            else {
                                let ot = I.classNameAliases[L] || L;
                                C(o[0], ot)
                            }
                        } else h += o[0];
                        s = f.keywordPatternRe.lastIndex, o = f.keywordPatternRe.exec(E)
                    }
                    h += E.substring(s), M.addText(h)
                }

                function m() {
                    if (E === "") return;
                    let s = null;
                    if (typeof f.subLanguage == "string") {
                        if (!t[f.subLanguage]) {
                            M.addText(E);
                            return
                        }
                        s = k(f.subLanguage, E, !0, xe[f.subLanguage]), xe[f.subLanguage] = s._top
                    } else s = H(E, f.subLanguage.length ? f.subLanguage : null);
                    f.relevance > 0 && (te += s.relevance), M.__addSublanguage(s._emitter, s.language)
                }

                function w() {
                    f.subLanguage != null ? m() : R(), E = ""
                }

                function C(s, o) {
                    s !== "" && (M.startScope(o), M.addText(s), M.endScope())
                }

                function ye(s, o) {
                    let h = 1,
                        p = o.length - 1;
                    for (; h <= p;) {
                        if (!s._emit[h]) {
                            h++;
                            continue
                        }
                        let O = I.classNameAliases[s[h]] || s[h],
                            L = o[h];
                        O ? C(L, O) : (E = L, R(), E = ""), h++
                    }
                }

                function Oe(s, o) {
                    return s.scope && typeof s.scope == "string" && M.openNode(I.classNameAliases[s.scope] || s.scope), s.beginScope && (s.beginScope._wrap ? (C(E, I.classNameAliases[s.beginScope._wrap] || s.beginScope._wrap), E = "") : s.beginScope._multi && (ye(s.beginScope, o), E = "")), f = Object.create(s, {
                        parent: {
                            value: f
                        }
                    }), f
                }

                function we(s, o, h) {
                    let p = Et(s.endRe, h);
                    if (p) {
                        if (s["on:end"]) {
                            let O = new ie(s);
                            s["on:end"](o, O), O.isMatchIgnored && (p = !1)
                        }
                        if (p) {
                            for (; s.endsParent && s.parent;) s = s.parent;
                            return s
                        }
                    }
                    if (s.endsWithParent) return we(s.parent, o, h)
                }

                function nt(s) {
                    return f.matcher.regexIndex === 0 ? (E += s[0], 1) : (he = !0, 0)
                }

                function it(s) {
                    let o = s[0],
                        h = s.rule,
                        p = new ie(h),
                        O = [h.__beforeBegin, h["on:begin"]];
                    for (let L of O)
                        if (L && (L(s, p), p.isMatchIgnored)) return nt(o);
                    return h.skip ? E += o : (h.excludeBegin && (E += o), w(), !h.returnBegin && !h.excludeBegin && (E = o)), Oe(h, s), h.returnBegin ? 0 : o.length
                }

                function st(s) {
                    let o = s[0],
                        h = l.substring(s.index),
                        p = we(f, s, h);
                    if (!p) return De;
                    let O = f;
                    f.endScope && f.endScope._wrap ? (w(), C(o, f.endScope._wrap)) : f.endScope && f.endScope._multi ? (w(), ye(f.endScope, s)) : O.skip ? E += o : (O.returnEnd || O.excludeEnd || (E += o), w(), O.excludeEnd && (E = o));
                    do f.scope && M.closeNode(), !f.skip && !f.subLanguage && (te += f.relevance), f = f.parent; while (f !== p.parent);
                    return p.starts && Oe(p.starts, s), O.returnEnd ? 0 : o.length
                }

                function rt() {
                    let s = [];
                    for (let o = f; o !== I; o = o.parent) o.scope && s.unshift(o.scope);
                    s.forEach(o => M.openNode(o))
                }
                let ee = {};

                function Re(s, o) {
                    let h = o && o[0];
                    if (E += s, h == null) return w(), 0;
                    if (ee.type === "begin" && o.type === "end" && ee.index === o.index && h === "") {
                        if (E += l.slice(o.index, o.index + 1), !_) {
                            let p = new Error(`0 width match regex (${n})`);
                            throw p.languageName = n, p.badRule = ee.rule, p
                        }
                        return 1
                    }
                    if (ee = o, o.type === "begin") return it(o);
                    if (o.type === "illegal" && !g) {
                        let p = new Error('Illegal lexeme "' + h + '" for mode "' + (f.scope || "<unnamed>") + '"');
                        throw p.mode = f, p
                    } else if (o.type === "end") {
                        let p = st(o);
                        if (p !== De) return p
                    }
                    if (o.type === "illegal" && h === "") return E += `
`, 1;
                    if (fe > 1e5 && fe > o.index * 3) throw new Error("potential infinite loop, way more iterations than matches");
                    return E += h, h.length
                }
                let I = x(n);
                if (!I) throw $(S.replace("{}", n)), new Error('Unknown language: "' + n + '"');
                let ct = Jt(I),
                    ge = "",
                    f = d || ct,
                    xe = {},
                    M = new r.__emitter(r);
                rt();
                let E = "",
                    te = 0,
                    P = 0,
                    fe = 0,
                    he = !1;
                try {
                    if (I.__emitTokens) I.__emitTokens(l, M);
                    else {
                        for (f.matcher.considerAll();;) {
                            fe++, he ? he = !1 : f.matcher.considerAll(), f.matcher.lastIndex = P;
                            let s = f.matcher.exec(l);
                            if (!s) break;
                            let o = l.substring(P, s.index),
                                h = Re(o, s);
                            P = s.index + h
                        }
                        Re(l.substring(P))
                    }
                    return M.finalize(), ge = M.toHTML(), {
                        language: n,
                        value: ge,
                        relevance: te,
                        illegal: !1,
                        _emitter: M,
                        _top: f
                    }
                } catch (s) {
                    if (s.message && s.message.includes("Illegal")) return {
                        language: n,
                        value: de(l),
                        illegal: !0,
                        relevance: 0,
                        _illegalBy: {
                            message: s.message,
                            index: P,
                            context: l.slice(P - 100, P + 100),
                            mode: s.mode,
                            resultSoFar: ge
                        },
                        _emitter: M
                    };
                    if (_) return {
                        language: n,
                        value: de(l),
                        illegal: !1,
                        relevance: 0,
                        errorRaised: s,
                        _emitter: M,
                        _top: f
                    };
                    throw s
                }
            }

            function T(n) {
                let l = {
                    value: de(n),
                    illegal: !1,
                    relevance: 0,
                    _top: c,
                    _emitter: new r.__emitter(r)
                };
                return l._emitter.addText(n), l
            }

            function H(n, l) {
                l = l || r.languages || Object.keys(t);
                let g = T(n),
                    d = l.filter(x).filter(Q).map(w => k(w, n, !1));
                d.unshift(g);
                let b = d.sort((w, C) => {
                        if (w.relevance !== C.relevance) return C.relevance - w.relevance;
                        if (w.language && C.language) {
                            if (x(w.language).supersetOf === C.language) return 1;
                            if (x(C.language).supersetOf === w.language) return -1
                        }
                        return 0
                    }),
                    [y, R] = b,
                    m = y;
                return m.secondBest = R, m
            }

            function J(n, l, g) {
                let d = l && i[l] || g;
                n.classList.add("hljs"), n.classList.add(`language-${d}`)
            }

            function G(n) {
                let l = null,
                    g = N(n);
                if (u(g)) return;
                if (z("before:highlightElement", {
                        el: n,
                        language: g
                    }), n.dataset.highlighted) {
                    console.log("Element previously highlighted. To highlight again, first unset `dataset.highlighted`.", n);
                    return
                }
                if (n.children.length > 0 && (r.ignoreUnescapedHTML || (console.warn("One of your code blocks includes unescaped HTML. This is a potentially serious security risk."), console.warn("https://github.com/highlightjs/highlight.js/wiki/security"), console.warn("The element with unescaped HTML:"), console.warn(n)), r.throwUnescapedHTML)) throw new _e("One of your code blocks includes unescaped HTML.", n.innerHTML);
                l = n;
                let d = l.textContent,
                    b = g ? A(d, {
                        language: g,
                        ignoreIllegals: !0
                    }) : H(d);
                n.innerHTML = b.value, n.dataset.highlighted = "yes", J(n, g, b.language), n.result = {
                    language: b.language,
                    re: b.relevance,
                    relevance: b.relevance
                }, b.secondBest && (n.secondBest = {
                    language: b.secondBest.language,
                    relevance: b.secondBest.relevance
                }), z("after:highlightElement", {
                    el: n,
                    result: b,
                    text: d
                })
            }

            function q(n) {
                r = Be(r, n)
            }
            let Me = () => {
                B(), F("10.6.0", "initHighlighting() deprecated.  Use highlightAll() now.")
            };

            function j() {
                B(), F("10.6.0", "initHighlightingOnLoad() deprecated.  Use highlightAll() now.")
            }
            let K = !1;

            function B() {
                function n() {
                    B()
                }
                if (document.readyState === "loading") {
                    K || window.addEventListener("DOMContentLoaded", n, !1), K = !0;
                    return
                }
                document.querySelectorAll(r.cssSelector).forEach(G)
            }

            function W(n, l) {
                let g = null;
                try {
                    g = l(e)
                } catch (d) {
                    if ($("Language definition for '{}' could not be registered.".replace("{}", n)), _) $(d);
                    else throw d;
                    g = c
                }
                g.name || (g.name = n), t[n] = g, g.rawDefinition = l.bind(null, e), g.aliases && V(g.aliases, {
                    languageName: n
                })
            }

            function D(n) {
                delete t[n];
                for (let l of Object.keys(i)) i[l] === n && delete i[l]
            }

            function ce() {
                return Object.keys(t)
            }

            function x(n) {
                return n = (n || "").toLowerCase(), t[n] || t[i[n]]
            }

            function V(n, {
                languageName: l
            }) {
                typeof n == "string" && (n = [n]), n.forEach(g => {
                    i[g.toLowerCase()] = l
                })
            }

            function Q(n) {
                let l = x(n);
                return l && !l.disableAutodetect
            }

            function ae(n) {
                n["before:highlightBlock"] && !n["before:highlightElement"] && (n["before:highlightElement"] = l => {
                    n["before:highlightBlock"](Object.assign({
                        block: l.el
                    }, l))
                }), n["after:highlightBlock"] && !n["after:highlightElement"] && (n["after:highlightElement"] = l => {
                    n["after:highlightBlock"](Object.assign({
                        block: l.el
                    }, l))
                })
            }

            function oe(n) {
                ae(n), a.push(n)
            }

            function le(n) {
                let l = a.indexOf(n);
                l !== -1 && a.splice(l, 1)
            }

            function z(n, l) {
                let g = n;
                a.forEach(function(d) {
                    d[g] && d[g](l)
                })
            }

            function ue(n) {
                return F("10.7.0", "highlightBlock will be removed entirely in v12.0"), F("10.7.0", "Please use highlightElement now."), G(n)
            }
            Object.assign(e, {
                highlight: A,
                highlightAuto: H,
                highlightAll: B,
                highlightElement: G,
                highlightBlock: ue,
                configure: q,
                initHighlighting: Me,
                initHighlightingOnLoad: j,
                registerLanguage: W,
                unregisterLanguage: D,
                listLanguages: ce,
                getLanguage: x,
                registerAliases: V,
                autoDetection: Q,
                inherit: Be,
                addPlugin: oe,
                removePlugin: le
            }), e.debugMode = function() {
                _ = !1
            }, e.safeMode = function() {
                _ = !0
            }, e.versionString = Vt, e.regex = {
                concat: U,
                lookahead: $e,
                either: Se,
                optional: dt,
                anyNumberOfTimes: ht
            };
            for (let n in ne) typeof ne[n] == "object" && me(ne[n]);
            return Object.assign(e, ne), e
        },
        Z = We({});
    Z.newInstance = () => We({});
    Xe.exports = Z;
    Z.HighlightJS = Z;
    Z.default = Z
});
var Je = ut(Ye(), 1);
var cn = Je.default;
var qe = "[A-Za-z$_][0-9A-Za-z$_]*",
    en = ["as", "in", "of", "if", "for", "while", "finally", "var", "new", "function", "do", "return", "void", "else", "break", "catch", "instanceof", "with", "throw", "case", "default", "try", "switch", "continue", "typeof", "delete", "let", "yield", "const", "class", "debugger", "async", "await", "static", "import", "from", "export", "extends", "using"],
    tn = ["true", "false", "null", "undefined", "NaN", "Infinity"],
    Ve = ["Object", "Function", "Boolean", "Symbol", "Math", "Date", "Number", "BigInt", "String", "RegExp", "Array", "Float32Array", "Float64Array", "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Int32Array", "Uint16Array", "Uint32Array", "BigInt64Array", "BigUint64Array", "Set", "Map", "WeakSet", "WeakMap", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "JSON", "Promise", "Generator", "GeneratorFunction", "AsyncFunction", "Reflect", "Proxy", "Intl", "WebAssembly"],
    Qe = ["Error", "EvalError", "InternalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError"],
    et = ["setInterval", "setTimeout", "clearInterval", "clearTimeout", "require", "exports", "eval", "isFinite", "isNaN", "parseFloat", "parseInt", "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape"],
    nn = ["arguments", "this", "super", "console", "window", "document", "localStorage", "sessionStorage", "module", "global"],
    sn = [].concat(et, Ve, Qe);

function on(e) {
    let t = e.regex,
        i = (g, {
            after: d
        }) => {
            let b = "</" + g[0].slice(1);
            return g.input.indexOf(b, d) !== -1
        },
        a = qe,
        _ = {
            begin: "<>",
            end: "</>"
        },
        S = /<[A-Za-z0-9\\._:-]+\s*\/>/,
        c = {
            begin: /<[A-Za-z0-9\\._:-]+/,
            end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
            isTrulyOpeningTag: (g, d) => {
                let b = g[0].length + g.index,
                    y = g.input[b];
                if (y === "<" || y === ",") {
                    d.ignoreMatch();
                    return
                }
                y === ">" && (i(g, {
                    after: b
                }) || d.ignoreMatch());
                let R, m = g.input.substring(b);
                if (R = m.match(/^\s*=/)) {
                    d.ignoreMatch();
                    return
                }
                if ((R = m.match(/^\s+extends\s+/)) && R.index === 0) {
                    d.ignoreMatch();
                    return
                }
            }
        },
        r = {
            $pattern: qe,
            keyword: en,
            literal: tn,
            built_in: sn,
            "variable.language": nn
        },
        u = "[0-9](_?[0-9])*",
        N = `\\.(${u})`,
        A = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
        k = {
            className: "number",
            variants: [{
                begin: `(\\b(${A})((${N})|\\.)?|(${N}))[eE][+-]?(${u})\\b`
            }, {
                begin: `\\b(${A})\\b((${N})\\b|\\.)?|(${N})\\b`
            }, {
                begin: "\\b(0|[1-9](_?[0-9])*)n\\b"
            }, {
                begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"
            }, {
                begin: "\\b0[bB][0-1](_?[0-1])*n?\\b"
            }, {
                begin: "\\b0[oO][0-7](_?[0-7])*n?\\b"
            }, {
                begin: "\\b0[0-7]+n?\\b"
            }],
            relevance: 0
        },
        T = {
            className: "subst",
            begin: "\\$\\{",
            end: "\\}",
            keywords: r,
            contains: []
        },
        H = {
            begin: ".?html`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, T],
                subLanguage: "xml"
            }
        },
        J = {
            begin: ".?css`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, T],
                subLanguage: "css"
            }
        },
        G = {
            begin: ".?gql`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, T],
                subLanguage: "graphql"
            }
        },
        q = {
            className: "string",
            begin: "`",
            end: "`",
            contains: [e.BACKSLASH_ESCAPE, T]
        },
        j = {
            className: "comment",
            variants: [e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
                relevance: 0,
                contains: [{
                    begin: "(?=@[A-Za-z]+)",
                    relevance: 0,
                    contains: [{
                        className: "doctag",
                        begin: "@[A-Za-z]+"
                    }, {
                        className: "type",
                        begin: "\\{",
                        end: "\\}",
                        excludeEnd: !0,
                        excludeBegin: !0,
                        relevance: 0
                    }, {
                        className: "variable",
                        begin: a + "(?=\\s*(-)|$)",
                        endsParent: !0,
                        relevance: 0
                    }, {
                        begin: /(?=[^\n])\s/,
                        relevance: 0
                    }]
                }]
            }), e.C_BLOCK_COMMENT_MODE, e.C_LINE_COMMENT_MODE]
        },
        K = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, H, J, G, q, {
            match: /\$\d+/
        }, k];
    T.contains = K.concat({
        begin: /\{/,
        end: /\}/,
        keywords: r,
        contains: ["self"].concat(K)
    });
    let B = [].concat(j, T.contains),
        W = B.concat([{
            begin: /(\s*)\(/,
            end: /\)/,
            keywords: r,
            contains: ["self"].concat(B)
        }]),
        D = {
            className: "params",
            begin: /(\s*)\(/,
            end: /\)/,
            excludeBegin: !0,
            excludeEnd: !0,
            keywords: r,
            contains: W
        },
        ce = {
            variants: [{
                match: [/class/, /\s+/, a, /\s+/, /extends/, /\s+/, t.concat(a, "(", t.concat(/\./, a), ")*")],
                scope: {
                    1: "keyword",
                    3: "title.class",
                    5: "keyword",
                    7: "title.class.inherited"
                }
            }, {
                match: [/class/, /\s+/, a],
                scope: {
                    1: "keyword",
                    3: "title.class"
                }
            }]
        },
        x = {
            relevance: 0,
            match: t.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
            className: "title.class",
            keywords: {
                _: [...Ve, ...Qe]
            }
        },
        V = {
            label: "use_strict",
            className: "meta",
            relevance: 10,
            begin: /^\s*['"]use (strict|asm)['"]/
        },
        Q = {
            variants: [{
                match: [/function/, /\s+/, a, /(?=\s*\()/]
            }, {
                match: [/function/, /\s*(?=\()/]
            }],
            className: {
                1: "keyword",
                3: "title.function"
            },
            label: "func.def",
            contains: [D],
            illegal: /%/
        },
        ae = {
            relevance: 0,
            match: /\b[A-Z][A-Z_0-9]+\b/,
            className: "variable.constant"
        };

    function oe(g) {
        return t.concat("(?!", g.join("|"), ")")
    }
    let le = {
            match: t.concat(/\b/, oe([...et, "super", "import"].map(g => `${g}\\s*\\(`)), a, t.lookahead(/\s*\(/)),
            className: "title.function",
            relevance: 0
        },
        z = {
            begin: t.concat(/\./, t.lookahead(t.concat(a, /(?![0-9A-Za-z$_(])/))),
            end: a,
            excludeBegin: !0,
            keywords: "prototype",
            className: "property",
            relevance: 0
        },
        ue = {
            match: [/get|set/, /\s+/, a, /(?=\()/],
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [{
                begin: /\(\)/
            }, D]
        },
        n = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>",
        l = {
            match: [/const|var|let/, /\s+/, a, /\s*/, /=\s*/, /(async\s*)?/, t.lookahead(n)],
            keywords: "async",
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [D]
        };
    return {
        name: "JavaScript",
        aliases: ["js", "jsx", "mjs", "cjs"],
        keywords: r,
        exports: {
            PARAMS_CONTAINS: W,
            CLASS_REFERENCE: x
        },
        illegal: /#(?![$_A-z])/,
        contains: [e.SHEBANG({
            label: "shebang",
            binary: "node",
            relevance: 5
        }), V, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, H, J, G, q, j, {
            match: /\$\d+/
        }, k, x, {
            scope: "attr",
            match: a + t.lookahead(":"),
            relevance: 0
        }, l, {
            begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
            keywords: "return throw case",
            relevance: 0,
            contains: [j, e.REGEXP_MODE, {
                className: "function",
                begin: n,
                returnBegin: !0,
                end: "\\s*=>",
                contains: [{
                    className: "params",
                    variants: [{
                        begin: e.UNDERSCORE_IDENT_RE,
                        relevance: 0
                    }, {
                        className: null,
                        begin: /\(\s*\)/,
                        skip: !0
                    }, {
                        begin: /(\s*)\(/,
                        end: /\)/,
                        excludeBegin: !0,
                        excludeEnd: !0,
                        keywords: r,
                        contains: W
                    }]
                }]
            }, {
                begin: /,/,
                relevance: 0
            }, {
                match: /\s+/,
                relevance: 0
            }, {
                variants: [{
                    begin: _.begin,
                    end: _.end
                }, {
                    match: S
                }, {
                    begin: c.begin,
                    "on:begin": c.isTrulyOpeningTag,
                    end: c.end
                }],
                subLanguage: "xml",
                contains: [{
                    begin: c.begin,
                    end: c.end,
                    skip: !0,
                    contains: ["self"]
                }]
            }]
        }, Q, {
            beginKeywords: "while if switch catch for"
        }, {
            begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
            returnBegin: !0,
            label: "func.def",
            contains: [D, e.inherit(e.TITLE_MODE, {
                begin: a,
                className: "title.function"
            })]
        }, {
            match: /\.\.\./,
            relevance: 0
        }, z, {
            match: "\\$" + a,
            relevance: 0
        }, {
            match: [/\bconstructor(?=\s*\()/],
            className: {
                1: "title.function"
            },
            contains: [D]
        }, le, ae, ce, ue, {
            match: /\$[(.]/
        }]
    }
}
var tt = class {
    constructor(t) {
        this.$el = document.createElement("button"), this.$el.setAttribute("title", "Copy"), this.$el.classList.add("copy-button"), this.$el.classList.add("ui-input"), this.$el.innerHTML = `<svg class="icon" width="24" height="24" viewBox="0 0 24 24">
  <g fill="none" fill-rule="evenodd">
    <path fill="currentColor" fill-rule="nonzero" d="M17,5.25 C17.9664983,5.25 18.75,6.03350169 18.75,7 L18.75,13 C18.75,13.9664983 17.9664983,14.75 17,14.75 L14.75,14.75 L14.75,17 C14.75,17.9664983 13.9664983,18.75 13,18.75 L7,18.75 C6.03350169,18.75 5.25,17.9664983 5.25,17 L5.25,11 C5.25,10.0335017 6.03350169,9.25 7,9.25 L9.25,9.25 L9.25,7 C9.25,6.03350169 10.0335017,5.25 11,5.25 L17,5.25 Z M9.25,10.75 L7,10.75 C6.86192881,10.75 6.75,10.8619288 6.75,11 L6.75,17 C6.75,17.1380712 6.86192881,17.25 7,17.25 L13,17.25 C13.1380712,17.25 13.25,17.1380712 13.25,17 L13.25,14.75 L11,14.75 C10.0335017,14.75 9.25,13.9664983 9.25,13 L9.25,10.75 Z M17,6.75 L11,6.75 C10.8619288,6.75 10.75,6.86192881 10.75,7 L10.75,13 C10.75,13.1380712 10.8619288,13.25 11,13.25 L17,13.25 C17.1380712,13.25 17.25,13.1380712 17.25,13 L17.25,7 C17.25,6.86192881 17.1380712,6.75 17,6.75 Z"/>
    <polyline stroke="var(--hex-green-1)" stroke-width="1.75" points="5 12 10 17 19 8"/>
  </g>
</svg>`, this.$copyIcon = this.$el.querySelector("path"), this.OKLine = Ce.createDrawable(this.$el.querySelector("polyline")), this.data = t, this.$el.addEventListener("click", this, !1)
    }
    handleClick() {
        navigator.clipboard.writeText(this.data), Te({
            onPause: () => this.$el.blur()
        }).add(this.$copyIcon, {
            scale: 0,
            duration: 350,
            ease: "out(3)"
        }).add(this.OKLine, {
            draw: ["0 0", "0 1"],
            duration: 350,
            ease: "out(4)",
            onComplete: () => this.$el.blur()
        }, "<-=200").add(this.OKLine, {
            draw: "1 1",
            duration: 400,
            ease: "inOut(4)"
        }, "+=400").add(this.$copyIcon, {
            scale: 1,
            duration: 350,
            ease: "out(3)"
        }, "<<+=250")
    }
    handleEvent(t) {
        t.type === "click" && this.handleClick()
    }
};
export {
    cn as a, on as b, tt as c
};