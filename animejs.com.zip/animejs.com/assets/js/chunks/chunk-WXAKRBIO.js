import {
    $ as Le,
    A as Un,
    B as Qi,
    Ba as Jn,
    C as Us,
    D as zs,
    E as zn,
    F as Ye,
    G as yt,
    H as E,
    I as Yn,
    J as Je,
    K as Pt,
    L as ue,
    M as Nt,
    N as wt,
    O as Lt,
    P as vt,
    Q as lt,
    R as S,
    S as fe,
    T as Fe,
    U as Wn,
    V as qn,
    W as jn,
    X as Gn,
    Y as Ae,
    Z as Zn,
    _ as Pe,
    a as be,
    aa as qt,
    b as ee,
    ba as ts,
    c as O,
    ca as es,
    d as bt,
    da as ne,
    e as nt,
    ea as bs,
    f as Ut,
    fa as Kn,
    g as At,
    ga as Re,
    h as Zi,
    ha as Qn,
    i as de,
    ia as Ji,
    j as Ke,
    ja as ss,
    k as Te,
    ka as oe,
    l as Hs,
    la as I,
    m as G,
    ma as A,
    n as ve,
    na as We,
    o as Vt,
    oa as $e,
    p as Ki,
    pa as is,
    q as Kt,
    qa as Ne,
    r as Bn,
    ra as Mt,
    s as vs,
    sa as jt,
    t as Qe,
    ta as ot,
    u as Ee,
    ua as Gt,
    v as Xs,
    va as zt,
    w as Z,
    x as Mn,
    xa as Ys,
    y as Hn,
    ya as Ts,
    z as Xn
} from "./chunk-FX45FQRC.js";
import {
    b as ys
} from "./chunk-DCANE7XH.js";
var xr = {};
ys(xr, {
    $: () => se,
    Animatable: () => Ge,
    AutoLayout: () => Vs,
    Draggable: () => Ps,
    JSAnimation: () => Qt,
    Scope: () => Ls,
    ScrollObserver: () => Ns,
    Spring: () => Me,
    TextSplitter: () => ze,
    Timeline: () => As,
    Timer: () => Ot,
    WAAPIAnimation: () => Ds,
    addChild: () => zt,
    animate: () => Ce,
    clamp: () => Ri,
    cleanInlineStyles: () => Gs,
    createAnimatable: () => vo,
    createDraggable: () => li,
    createDrawable: () => Fi,
    createLayout: () => No,
    createMotionPath: () => Vi,
    createScope: () => ci,
    createSeededRandom: () => De,
    createSpring: () => ni,
    createTimeline: () => Be,
    createTimer: () => Cs,
    cubicBezier: () => ui,
    damp: () => ki,
    degToRad: () => Ai,
    eases: () => re,
    easings: () => pn,
    engine: () => Ft,
    forEachChildren: () => ot,
    get: () => pe,
    globals: () => E,
    irregular: () => mi,
    keepTime: () => Xe,
    lerp: () => Ni,
    linear: () => hs,
    mapRange: () => Ei,
    morphTo: () => Oi,
    onScroll: () => xo,
    padEnd: () => wi,
    padStart: () => _i,
    radToDeg: () => Pi,
    random: () => Ue,
    randomPick: () => Di,
    remove: () => ri,
    removeChild: () => Gt,
    round: () => $i,
    roundPad: () => Si,
    scrambleText: () => zi,
    scrollContainers: () => $s,
    set: () => ce,
    shuffle: () => fs,
    snap: () => Li,
    split: () => Ui,
    splitText: () => Xi,
    spring: () => Ze,
    stagger: () => ms,
    steps: () => fi,
    svg: () => Tn,
    sync: () => cs,
    text: () => Rn,
    utils: () => Bt,
    waapi: () => gi,
    wrap: () => Ci
});
var to = (s, t, e) => {
        let i = s.style.transform;
        if (i) {
            let n = s[Te],
                o = 0,
                r = i.length,
                a;
            for (; o < r;) {
                for (; o < r && i.charCodeAt(o) === 32;) o++;
                if (o >= r) break;
                let c = o;
                for (; o < r && i.charCodeAt(o) !== 40;) o++;
                if (o >= r) break;
                let d = i.substring(c, o),
                    u = 1,
                    f = o + 1,
                    g = -1,
                    y = -1;
                for (o++; o < r && u > 0;) {
                    let m = i.charCodeAt(o);
                    m === 40 ? u++ : m === 41 ? u-- : m === 44 && u === 1 && (g === -1 ? g = o : y === -1 && (y = o)), o++
                }
                let h = o - 1;
                d === "translate" || d === "translate3d" ? (g === -1 ? n.translateX = i.substring(f, h).trim() : (n.translateX = i.substring(f, g).trim(), y === -1 ? n.translateY = i.substring(g + 1, h).trim() : (n.translateY = i.substring(g + 1, y).trim(), n.translateZ = i.substring(y + 1, h).trim())), a = i.substring(f, h)) : d === "scale" || d === "scale3d" ? g === -1 ? n.scale = i.substring(f, h).trim() : (n.scaleX = i.substring(f, g).trim(), y === -1 ? n.scaleY = i.substring(g + 1, h).trim() : (n.scaleY = i.substring(g + 1, y).trim(), n.scaleZ = i.substring(y + 1, h).trim())) : n[d] = i.substring(f, h)
            }
            if (t === "translate3d" && a) return e && (e[t] = a), a;
            let l = n[t];
            if (!S(l)) return e && (e[t] = l), l
        }
        return t === "translate3d" ? "0px, 0px, 0px" : t === "rotate3d" ? "0, 0, 0, 0deg" : Pt(t, "scale") ? "1" : Pt(t, "rotate") || Pt(t, "skew") ? "0deg" : "0px"
    },
    Ws = s => {
        let t = Kt;
        for (let e = 0, i = Ee.length; e < i; e++) {
            let n = Ee[e],
                o = s[n];
            if (o !== void 0) {
                if (n === "translateX") {
                    let r = s.translateY;
                    if (r !== void 0) {
                        let a = s.translateZ;
                        a !== void 0 ? (t += `translate3d(${o},${r},${a}) `, e += 2) : (t += `translate(${o},${r}) `, e += 1);
                        continue
                    }
                }
                if (n === "scaleX" && s.scale === void 0) {
                    let r = s.scaleY;
                    if (r !== void 0) {
                        let a = s.scaleZ;
                        a !== void 0 ? (t += `scale3d(${o},${r},${a}) `, e += 2) : (t += `scale(${o},${r}) `, e += 1);
                        continue
                    }
                }
                t += `${Xs[n]}${o}) `
            }
            n === "rotateZ" && s.rotate3d !== void 0 && (t += `rotate3d(${s.rotate3d}) `)
        }
        return s.matrix !== void 0 && (t += `matrix(${s.matrix}) `), s.matrix3d !== void 0 && (t += `matrix3d(${s.matrix3d}) `), t
    };
var Uo = s => {
        let t = Mn.exec(s) || Hn.exec(s),
            e = S(t[4]) ? 1 : +t[4];
        return [+t[1], +t[2], +t[3], e]
    },
    zo = s => {
        let t = s.length,
            e = t === 4 || t === 5;
        return [+("0x" + s[1] + s[e ? 1 : 2]), +("0x" + s[e ? 2 : 3] + s[e ? 2 : 4]), +("0x" + s[e ? 3 : 5] + s[e ? 3 : 6]), t === 5 || t === 9 ? +(+("0x" + s[e ? 4 : 7] + s[e ? 4 : 8]) / 255).toFixed(3) : 1]
    },
    tn = (s, t, e) => (e < 0 && (e += 1), e > 1 && (e -= 1), e < 1 / 6 ? s + (t - s) * 6 * e : e < 1 / 2 ? t : e < 2 / 3 ? s + (t - s) * (2 / 3 - e) * 6 : s),
    Yo = s => {
        let t = Xn.exec(s) || Un.exec(s),
            e = +t[1] / 360,
            i = +t[2] / 100,
            n = +t[3] / 100,
            o = S(t[4]) ? 1 : +t[4],
            r, a, l;
        if (i === 0) r = a = l = n;
        else {
            let c = n < .5 ? n * (1 + i) : n + i - n * i,
                d = 2 * n - c;
            r = A(tn(d, c, e + 1 / 3) * 255, 0), a = A(tn(d, c, e) * 255, 0), l = A(tn(d, c, e - 1 / 3) * 255, 0)
        }
        return [r, a, l, o]
    },
    eo = s => qn(s) ? Uo(s) : Wn(s) ? zo(s) : jn(s) ? Yo(s) : [0, 0, 0, 1];
var P = (s, t) => S(s) ? t : s,
    so = (s, t) => {
        let e = s.match(zn),
            i = t[de] ? t : document.documentElement,
            n = getComputedStyle(i) ? .getPropertyValue(e[1]);
        return (!n || n.trim() === Kt) && e[2] && (n = e[2].trim()), n || 0
    },
    Rt = (s, t, e, i, n, o) => {
        if (lt(s)) {
            if (!n) {
                let a = s(t, e, i, o);
                return isNaN(+a) ? a || 0 : +a
            }
            let r = () => {
                let a = s(t, e, i, o);
                return isNaN(+a) ? a || 0 : +a
            };
            return n.func = r, r()
        }
        if (vt(s) && Pt(s, Bn)) {
            if (!n) return so(s, t);
            let r = () => so(s, t);
            return n.func = r, r()
        }
        return s
    },
    xs = (s, t) => s[de] ? s[Ke] && Zn(s, t) ? bt.ATTRIBUTE : Ee.includes(t) || Qe.get(t) ? bt.TRANSFORM : Pt(t, "--") ? bt.CSS_VAR : t in s.style ? bt.CSS : t in s ? bt.OBJECT : bt.ATTRIBUTE : bt.OBJECT,
    io = (s, t, e) => {
        let i = s.style[t];
        i && e && (e[t] = i);
        let n = i || getComputedStyle(s[Hs] || s).getPropertyValue(t);
        return n === "auto" ? "0" : n
    },
    xe = (s, t, e, i) => {
        let n = S(e) ? xs(s, t) : e,
            o = Ys(s, t);
        if (o) {
            let r = o.get(s);
            return r && i && (i[t] = r), r ? ? 0
        }
        if (n === bt.OBJECT) {
            let r = s[t];
            return r && i && (i[t] = r), r || 0
        }
        if (n === bt.ATTRIBUTE) {
            let r = s.getAttribute(t);
            return r && i && (i[t] = r), r
        }
        return n === bt.TRANSFORM ? to(s, t, i) : n === bt.CSS_VAR ? io(s, t, i).trimStart() : io(s, t, i)
    },
    Se = (s, t, e) => e === "-" ? s - t : e === "+" ? s + t : s * t,
    qs = () => ({
        t: nt.NUMBER,
        n: 0,
        u: null,
        o: null,
        d: null,
        s: null
    }),
    Yt = (s, t) => {
        if (t.t = nt.NUMBER, t.n = 0, t.u = null, t.o = null, t.d = null, t.s = null, !s) return t;
        let e = +s;
        if (!isNaN(e)) return t.n = e, t;
        let i = s;
        i[1] === "=" && (t.o = i[0], i = i.slice(2));
        let n = i.includes(" ") ? !1 : Us.exec(i);
        if (n) return t.t = nt.UNIT, t.n = +n[1], t.u = n[2], t;
        if (t.o) return t.n = +i, t;
        if (Gn(i)) return t.t = nt.COLOR, t.d = eo(i), t; {
            let o = i.match(Qi);
            return t.t = nt.COMPLEX, t.d = o ? o.map(Number) : [], t.s = i.split(Qi) || [], t
        }
    },
    en = (s, t) => (t.t = s._valueType, t.n = s._toNumber, t.u = s._unit, t.o = null, t.d = Mt(s._toNumbers), t.s = Mt(s._strings), t),
    It = qs(),
    js = (s, t, e) => {
        let i = s._modifier,
            n = s._fromNumbers,
            o = s._toNumbers,
            r = s._strings,
            a = r[0];
        for (let l = 0, c = o.length; l < c; l++) {
            let d = i(A($e(n[l], o[l], t), e)),
                u = r[l + 1];
            a += `${u?d+u:d}`, s._numbers[l] = d
        }
        return a
    };
var Ss = (s, t, e, i, n) => {
        let o = s.parent,
            r = s.duration,
            a = s.completed,
            l = s.iterationDuration,
            c = s.iterationCount,
            d = s._currentIteration,
            u = s._loopDelay,
            f = s._reversed,
            g = s._alternate,
            y = s._hasChildren,
            h = s._delay,
            m = s._currentTime,
            b = h + l,
            T = t - h,
            _ = I(m, -h, r),
            x = I(T, -h, r),
            L = T - m,
            R = x > 0,
            H = x >= r,
            J = r <= G,
            K = n === Ut.FORCE,
            z = 0,
            D = T,
            M = 0;
        if (c > 1) {
            let p = l + (H ? 0 : u),
                C = ~~(x / p);
            s._currentIteration = I(C, 0, c), H && s._currentIteration--, z = s._currentIteration % 2, D = x - C * p || 0
        }
        let q = f ^ (g && z),
            N = s._ease,
            F = H ? q ? 0 : r : q ? l - D : D;
        N && (F = l * N(F / l) || 0);
        let at = (o ? o.backwards : T < m) ? !q : !!q;
        if (s._currentTime = T, s._iterationTime = F, s.backwards = at, R && !s.began ? (s.began = !0, !e && !(o && (at || !o.began)) && s.onBegin(s)) : T <= 0 && (s.began = !1), !e && !y && R && s._currentIteration !== d && s.onLoop(s), K || n === Ut.AUTO && (t >= (o && h > 0 ? 0 : h) && t <= b || t <= h && _ > h || t >= b && _ !== r) || F >= b && _ !== r || F <= h && _ > 0 && !H || t <= _ && _ === r && a || H && !a && J) {
            if (R && (s.computeDeltaTime(_), e || s.onBeforeUpdate(s)), !y) {
                let p = K || (at ? L * -1 : L) >= E.tickThreshold,
                    C = A(s._offset + (o ? o._offset : 0) + h + F, 12),
                    v = s._head,
                    w, V, B, k, Y = 0;
                for (; v;) {
                    let dt = v._composition,
                        X = v._currentTime,
                        et = v._changeDuration,
                        ut = v._absoluteStartTime + v._changeDuration,
                        it = v._nextRep,
                        kt = v._prevRep,
                        Dt = dt !== At.none,
                        U = kt ? kt._absoluteStartTime + kt._changeDuration : 0,
                        rt = kt && kt.parent !== v.parent,
                        xt = !it || it._isOverridden ? ut : it.parent === v.parent ? ut + it._delay : it._absoluteStartTime < it._absoluteUpdateStartTime ? it._absoluteStartTime : it._absoluteUpdateStartTime;
                    if ((p || (X !== et || C <= xt || kt && !rt && (!it || it.parent !== v.parent)) && (X !== 0 || C >= v._absoluteStartTime || rt && !v._hasFromValue && !kt._isOverridden && C >= U || it && !it._isOverridden && it.parent === v.parent && it._currentTime !== 0 && F < it._startTime)) && (!kt || rt || F >= v._startTime) && (!Dt || !v._isOverridden && (!v._isOverlapped || C <= ut) && (!it || it._isOverridden || C <= xt) && (!kt || kt._isOverridden || (rt ? C >= v._absoluteStartTime || !v._hasFromValue && C >= U : C >= U + v._delay)))) {
                        let $t = v._currentTime = I(F - v._startTime, 0, et),
                            ft = v._ease($t / v._updateDuration),
                            pt = v._modifier,
                            St = v._valueType,
                            Ct = v._tweenType,
                            Xt = Ct === bt.OBJECT,
                            ht = St === nt.NUMBER,
                            _t = ht && Xt || ft === 0 || ft === 1 ? -1 : E.precision,
                            Q, Tt;
                        if (ht) Q = Tt = pt(A($e(v._fromNumber, v._toNumber, ft), _t));
                        else if (St === nt.UNIT) Tt = pt(A($e(v._fromNumber, v._toNumber, ft), _t)), Q = `${Tt}${v._unit}`;
                        else if (St === nt.COLOR) {
                            let $ = v._numbers,
                                st = v._fromNumbers,
                                j = v._toNumbers,
                                W = 1 - ft,
                                mt = st[0],
                                Et = st[1],
                                Jt = st[2],
                                Ie = j[0],
                                Ve = j[1],
                                ps = j[2];
                            $[0] = pt(Math.sqrt(mt * mt * W + Ie * Ie * ft)), $[1] = pt(Math.sqrt(Et * Et * W + Ve * Ve * ft)), $[2] = pt(Math.sqrt(Jt * Jt * W + ps * ps * ft)), $[3] = pt($e(st[3], j[3], ft)), (!v._setter || i) && (Q = `rgba(${A($[0],0)},${A($[1],0)},${A($[2],0)},${$[3]})`)
                        } else St === nt.COMPLEX && (Q = js(v, ft, _t));
                        if (Dt && (v._number = Tt), !i && dt !== At.blend) {
                            let $ = v.property;
                            w = v.target, v._setter ? v._setter(w, Tt, v) : Xt ? w[$] = Q : Ct === bt.ATTRIBUTE ? w.setAttribute($, Q) : (V = w.style, Ct === bt.TRANSFORM ? (w !== B && (B = w, k = w[Te]), k[$] = Q, Y = 1) : Ct === bt.CSS ? V[$] = Q : Ct === bt.CSS_VAR && V.setProperty($, Q)), R && (M = 1)
                        } else v._value = Q
                    } else X && kt && !rt && F < v._startTime && (v._currentTime = 0);
                    Y && v._renderTransforms && (V.transform = Ws(k), Y = 0), v = v._next
                }!e && M && s.onRender(s)
            }!e && R && s.onUpdate(s)
        }
        return o && J ? !e && (o.began && !at && T > 0 && !a || at && T <= G && a) && (s.onComplete(s), s.completed = !at) : R && H ? c === 1 / 0 ? s._startTime += s.duration : s._currentIteration >= c - 1 && (s.paused = !0, !a && !y && (s.completed = !0, !e && !(o && (at || !o.began)) && (s.onComplete(s), s._resolve(s)))) : s.completed = !1, M
    },
    _e = (s, t, e, i, n) => {
        let o = s._currentIteration;
        if (Ss(s, t, e, i, n), s._hasChildren) {
            let r = s,
                a = r.backwards,
                l = i ? t : r._iterationTime,
                c = ue(),
                d = 0,
                u = !0;
            if (!i && r._currentIteration !== o) {
                let f = r.iterationDuration;
                ot(r, g => {
                    if (!a) !g.completed && !g.backwards && g._currentTime < g.iterationDuration && Ss(g, f, e, 1, Ut.FORCE), g.began = !1, g.completed = !1;
                    else {
                        let y = g.duration,
                            h = g._offset + g._delay,
                            m = h + y;
                        !e && y <= G && (!h || m === f) && g.onComplete(g)
                    }
                }), e || r.onLoop(r)
            }
            ot(r, f => {
                let g = A((l - f._offset) * f._speed, 12);
                if (a && g > f._delay + f.duration) return;
                let y = f._fps < r._fps ? f.requestTick(c) : n;
                d += Ss(f, g, e, i, y), !f.completed && u && (u = !1)
            }, a), !e && d && r.onRender(r), (u || a) && r._currentTime >= r.duration && (r.paused = !0, r.completed || (r.completed = !0, e || (r.onComplete(r), r._resolve(r))))
        }
    };
var no = {},
    ns = (s, t, e) => {
        if (e === bt.TRANSFORM) {
            let i = Qe.get(s);
            return i || s
        } else if (e === bt.CSS || e === bt.ATTRIBUTE && Fe(t) && s in t.style) {
            let i = no[s];
            if (i) return i; {
                let n = s && Je(s);
                return no[s] = n, n
            }
        } else return s
    },
    os = (s, t = !1) => {
        if (s._hasChildren) ot(s, e => os(e, t), !0);
        else {
            let e = s;
            e.pause(), ot(e, i => {
                let n = i.property,
                    o = i.target,
                    r = i._tweenType,
                    a = i._inlineValue,
                    l = fe(a) || a === Kt;
                if (i._setter) {
                    if (!t && !l) {
                        if (Yt(a, It), It.d) {
                            let c = It.d,
                                d = i._numbers;
                            for (let u = 0, f = c.length; u < f; u++) d[u] = c[u]
                        } else i._number = It.n;
                        i._setter(i.target, i._number, i)
                    }
                } else if (r === bt.OBJECT) !t && !l && (o[n] = a);
                else if (o[de])
                    if (r === bt.ATTRIBUTE) t || (l ? o.removeAttribute(n) : o.setAttribute(n, a));
                    else {
                        let c = o.style;
                        if (r === bt.TRANSFORM) {
                            let d = o[Te];
                            l ? delete d[n] : d[n] = a, i._renderTransforms && (Object.keys(d).length ? c.transform = Ws(d) : c.removeProperty("transform"))
                        } else l ? c.removeProperty(Je(n)) : c[n] = a
                    }
                o[de] && e._tail === i && e.targets.forEach(c => {
                    c.getAttribute && c.getAttribute("style") === Kt && c.removeAttribute("style")
                })
            })
        }
        return s
    },
    Gs = s => os(s, !0);
var rs = class {
    constructor(t = 0) {
        this.deltaTime = 0, this._currentTime = t, this._lastTickTime = t, this._startTime = t, this._lastTime = t, this._frameDuration = Vt / Ki, this._fps = Ki, this._speed = 1, this._hasChildren = !1, this._head = null, this._tail = null
    }
    get fps() {
        return this._fps
    }
    set fps(t) {
        let e = +t,
            i = e < G ? G : e,
            n = Vt / i;
        i > Ye.frameRate && (Ye.frameRate = i), this._fps = i, this._frameDuration = n
    }
    get speed() {
        return this._speed
    }
    set speed(t) {
        let e = +t;
        this._speed = e < G ? G : e
    }
    requestTick(t) {
        let e = this._frameDuration,
            i = t - this._lastTickTime,
            n = e * .25,
            o = n < 4 ? n : 4;
        return i + o < e ? Ut.NONE : (this._lastTickTime = i >= e ? t - i % e : t, Ut.AUTO)
    }
    computeDeltaTime(t) {
        let e = t - this._lastTime;
        return this.deltaTime = e, this._lastTime = t, e
    }
};
var ke = {
        animation: null,
        update: Z
    },
    oo = s => {
        let t = ke.animation;
        return t || (t = {
            duration: G,
            computeDeltaTime: Z,
            _offset: 0,
            _delay: 0,
            _head: null,
            _tail: null
        }, ke.animation = t, ke.update = () => {
            s.forEach(e => {
                for (let i in e) {
                    let n = e[i],
                        o = n._head;
                    if (o) {
                        let r = o._valueType,
                            a = r === nt.COMPLEX || r === nt.COLOR ? Mt(o._fromNumbers) : null,
                            l = o._fromNumber,
                            c = n._tail;
                        for (; c && c !== o;) {
                            if (a)
                                for (let d = 0, u = c._numbers.length; d < u; d++) a[d] += c._numbers[d];
                            else l += c._number;
                            c = c._prevAdd
                        }
                        o._toNumber = l, o._toNumbers = a
                    }
                }
            }), Ss(t, 1, 1, 0, Ut.FORCE)
        }), t
    };
var ro = be ? requestAnimationFrame : setImmediate,
    Wo = be ? cancelAnimationFrame : clearImmediate,
    sn = class extends rs {
        constructor(t) {
            super(t), this.useDefaultMainLoop = !0, this.pauseOnDocumentHidden = !0, this.defaults = Ye, this.paused = !0, this.reqId = 0
        }
        update() {
            let t = this._currentTime = ue();
            if (this.requestTick(t)) {
                this.computeDeltaTime(t);
                let e = this._speed,
                    i = this._fps,
                    n = this._head;
                for (; n;) {
                    let o = n._next;
                    n.paused ? (Gt(this, n), this._hasChildren = !!this._tail, n._running = !1, n.completed && !n._cancelled && n.cancel()) : _e(n, (t - n._startTime) * n._speed * e, 0, 0, n._fps < i ? n.requestTick(t) : Ut.AUTO), n = o
                }
                ke.update()
            }
        }
        wake() {
            return this.useDefaultMainLoop && !this.reqId && (this.requestTick(ue()), this.reqId = ro(ao)), this
        }
        pause() {
            if (this.reqId) return this.paused = !0, qo()
        }
        resume() {
            if (this.paused) return this.paused = !1, ot(this, t => t.resetTime()), this.wake()
        }
        get speed() {
            return this._speed * (E.timeScale === 1 ? 1 : Vt)
        }
        set speed(t) {
            let e = t * E.timeScale;
            this._speed !== e && (this._speed = e, ot(this, i => i.speed = i._speed))
        }
        get timeUnit() {
            return E.timeScale === 1 ? "ms" : "s"
        }
        set timeUnit(t) {
            let i = t === "s",
                n = i ? .001 : 1;
            if (E.timeScale !== n) {
                E.timeScale = n, E.tickThreshold = 200 * n;
                let o = i ? .001 : Vt;
                this.defaults.duration *= o, this._speed *= o
            }
        }
        get precision() {
            return E.precision
        }
        set precision(t) {
            E.precision = t
        }
    },
    Ft = (() => {
        let s = new sn(ue());
        return be && (Yn.engine = s, O.addEventListener("visibilitychange", () => {
            s.pauseOnDocumentHidden && (O.hidden ? s.pause() : s.resume())
        })), s
    })(),
    ao = () => {
        Ft._head ? (Ft.reqId = ro(ao), Ft.update()) : Ft.reqId = 0
    },
    qo = () => (Wo(Ft.reqId), Ft.reqId = 0, Ft);
var Zs = {
        _rep: new WeakMap,
        _add: new Map
    },
    ws = (s, t, e = "_rep") => {
        let i = Zs[e],
            n = i.get(s);
        return n || (n = {}, i.set(s, n)), n[t] ? n[t] : n[t] = {
            _head: null,
            _tail: null
        }
    },
    jo = (s, t) => s._isOverridden || s._absoluteStartTime > t._absoluteStartTime,
    _s = s => {
        s._isOverlapped = 1, s._isOverridden = 1, s._changeDuration = G, s._currentTime = G
    },
    Ks = (s, t) => {
        let e = s._composition;
        if (e === At.replace) {
            let i = s._absoluteStartTime;
            zt(t, s, jo, "_prevRep", "_nextRep");
            let n = s._prevRep;
            if (n) {
                let o = n.parent,
                    r = n._absoluteEndTime;
                if (s.parent.id !== o.id && o.iterationCount > 1 && r + (o.duration - o.iterationDuration) > i) {
                    _s(n);
                    let c = n._prevRep;
                    for (; c && c.parent.id === o.id;) _s(c), c = c._prevRep
                }
                let a = s._absoluteUpdateStartTime;
                if (r > a) {
                    let c = n._startTime,
                        d = r - (c + n._updateDuration),
                        u = A(a - d - c, 12);
                    n._changeDuration = u, n._currentTime = u, n._isOverlapped = 1, u < G && _s(n)
                }
                let l = s.parent.parent;
                if (!l || l !== o.parent) {
                    let c = !0;
                    if (ot(o, d => {
                            d._isOverlapped || (c = !1)
                        }), c) {
                        let d = o.parent;
                        if (d) {
                            let u = !0;
                            ot(d, f => {
                                f !== o && ot(f, g => {
                                    g._isOverlapped || (u = !1)
                                })
                            }), u && d.cancel()
                        } else o.cancel()
                    }
                }
            }
        } else if (e === At.blend) {
            let i = ws(s.target, s.property, "_add"),
                n = oo(Zs._add),
                o = i._head;
            o || (o = { ...s
            }, o._composition = At.replace, o._updateDuration = G, o._startTime = 0, o._numbers = Mt(s._fromNumbers), o._number = 0, o._next = null, o._prev = null, zt(i, o), zt(n, o));
            let r = s._toNumber;
            if (s._fromNumber = o._fromNumber - r, s._toNumber = 0, s._numbers = Mt(s._fromNumbers), s._number = 0, o._fromNumber = r, s._toNumbers.length) {
                let a = Mt(s._toNumbers);
                a.forEach((l, c) => {
                    s._fromNumbers[c] = o._fromNumbers[c] - l, s._toNumbers[c] = 0
                }), o._fromNumbers = a
            }
            zt(i, s, null, "_prevAdd", "_nextAdd")
        }
        return s
    },
    nn = s => {
        let t = s._composition;
        if (t !== At.none) {
            let e = s.target,
                i = s.property,
                r = Zs._rep.get(e)[i];
            if (Gt(r, s, "_prevRep", "_nextRep"), t === At.blend) {
                let a = Zs._add,
                    l = a.get(e);
                if (!l) return;
                let c = l[i],
                    d = ke.animation;
                Gt(c, s, "_prevAdd", "_nextAdd");
                let u = c._head;
                if (u && u === c._tail) {
                    Gt(c, u, "_prevAdd", "_nextAdd"), Gt(d, u);
                    let f = !0;
                    for (let g in l)
                        if (l[g]._head) {
                            f = !1;
                            break
                        }
                    f && a.delete(e)
                }
            }
        }
        return s
    },
    lo = (s, t, e) => {
        let i = !1;
        return ot(t, n => {
            let o = n.target;
            if (s.includes(o)) {
                let r = n.property,
                    a = n._tweenType,
                    l = ns(e, o, a);
                (!l || l && l === r) && (n.parent._tail === n && n._tweenType === bt.TRANSFORM && n._prev && n._prev._tweenType === bt.TRANSFORM && (n._prev._renderTransforms = 1), Gt(t, n), nn(n), i = !0)
            }
        }, !0), i
    },
    me = (s, t, e) => {
        let i = t || Ft,
            n;
        if (i._hasChildren) {
            let o = 0;
            ot(i, r => {
                if (!r._hasChildren)
                    if (n = lo(s, r, e), n && !r._head) r.cancel(), Gt(i, r);
                    else {
                        let l = r._offset + r._delay + r.duration;
                        l > o && (o = l)
                    }
                r._head ? me(s, r, e) : r._hasChildren = !1
            }, !0), S(i.iterationDuration) || (i.iterationDuration = o)
        } else n = lo(s, i, e);
        n && !i._head && (i._hasChildren = !1, i.cancel && i.cancel())
    };
var co = s => (s.paused = !0, s.began = !1, s.completed = !1, s),
    on = s => (s._cancelled && (s._hasChildren ? ot(s, on) : ot(s, t => {
        t._composition !== At.none && Ks(t, ws(t.target, t.property))
    }), s._cancelled = 0), s),
    ho = 0,
    Go = (s, t) => s._priority > t._priority,
    Ot = class extends rs {
        constructor(t = {}, e = null, i = 0) {
            super(0), ++ho;
            let {
                id: n,
                delay: o,
                duration: r,
                reversed: a,
                alternate: l,
                loop: c,
                loopDelay: d,
                autoplay: u,
                frameRate: f,
                playbackRate: g,
                priority: y,
                onComplete: h,
                onLoop: m,
                onPause: b,
                onBegin: T,
                onBeforeUpdate: _,
                onUpdate: x
            } = t;
            yt.current && yt.current.register(this);
            let L = e ? 0 : Ft._lastTickTime,
                R = e ? e.defaults : E.defaults,
                H = lt(o) || S(o) ? R.delay : +o,
                J = lt(r) || S(r) ? 1 / 0 : +r,
                K = P(c, R.loop),
                z = P(d, R.loopDelay),
                D = K === !0 || K === 1 / 0 || K < 0 ? 1 / 0 : K + 1,
                M = 0;
            e ? M = i : (Ft.reqId || Ft.requestTick(ue()), M = (Ft._lastTickTime - Ft._startTime) * E.timeScale), this.id = S(n) ? ho : n, this.parent = e, this.duration = is((J + z) * D - z) || G, this.backwards = !1, this.paused = !0, this.began = !1, this.completed = !1, this.onBegin = T || R.onBegin, this.onBeforeUpdate = _ || R.onBeforeUpdate, this.onUpdate = x || R.onUpdate, this.onLoop = m || R.onLoop, this.onPause = b || R.onPause, this.onComplete = h || R.onComplete, this.iterationDuration = J, this.iterationCount = D, this._autoplay = e ? !1 : P(u, R.autoplay), this._offset = M, this._delay = H, this._loopDelay = z, this._iterationTime = 0, this._currentIteration = 0, this._resolve = Z, this._running = !1, this._reversed = +P(a, R.reversed), this._reverse = this._reversed, this._cancelled = 0, this._alternate = P(l, R.alternate), this._prev = null, this._next = null, this._lastTickTime = L, this._startTime = L, this._lastTime = L, this._fps = P(f, R.frameRate), this._speed = P(g, R.playbackRate), this._priority = +P(y, 1)
        }
        get cancelled() {
            return !!this._cancelled
        }
        set cancelled(t) {
            t ? this.cancel() : this.reset(!0).play()
        }
        get currentTime() {
            return I(A(this._currentTime, E.precision), -this._delay, this.duration)
        }
        set currentTime(t) {
            let e = this.paused;
            this.pause().seek(+t), e || this.resume()
        }
        get iterationCurrentTime() {
            return I(A(this._iterationTime, E.precision), 0, this.iterationDuration)
        }
        set iterationCurrentTime(t) {
            this.currentTime = this.iterationDuration * this._currentIteration + t
        }
        get progress() {
            return I(A(this._currentTime / this.duration, 10), 0, 1)
        }
        set progress(t) {
            this.currentTime = this.duration * t
        }
        get iterationProgress() {
            return I(A(this._iterationTime / this.iterationDuration, 10), 0, 1)
        }
        set iterationProgress(t) {
            let e = this.iterationDuration;
            this.currentTime = e * this._currentIteration + e * t
        }
        get currentIteration() {
            return this._currentIteration
        }
        set currentIteration(t) {
            this.currentTime = this.iterationDuration * I(+t, 0, this.iterationCount - 1)
        }
        get reversed() {
            return !!this._reversed
        }
        set reversed(t) {
            t ? this.reverse() : this.play()
        }
        get speed() {
            return super.speed
        }
        set speed(t) {
            super.speed = t, this.resetTime()
        }
        reset(t = !1) {
            return on(this), this._reversed && !this._reverse && (this.reversed = !1), this._iterationTime = this.iterationDuration, _e(this, 0, 1, ~~t, Ut.FORCE), co(this), this._hasChildren && ot(this, co), this
        }
        init(t = !1) {
            this.fps = this._fps, this.speed = this._speed, !t && this._hasChildren && _e(this, this.duration, 1, ~~t, Ut.FORCE), this.reset(t);
            let e = this._autoplay;
            return e === !0 ? this.resume() : e && !S(e.linked) && e.link(this), this
        }
        resetTime() {
            let t = 1 / (this._speed * Ft._speed);
            return this._startTime = ue() - (this._currentTime + this._delay) * t, this
        }
        pause() {
            return this.paused ? this : (this.paused = !0, this.onPause(this), this)
        }
        resume() {
            return this.paused ? (this.paused = !1, this.duration <= G && !this._hasChildren ? _e(this, G, 0, 0, Ut.FORCE) : (this._running || (zt(Ft, this, Go), Ft._hasChildren = !0, this._running = !0), this.resetTime(), this._startTime -= 12, Ft.wake()), this) : this
        }
        restart() {
            return this.reset().resume()
        }
        seek(t, e = 0, i = 0) {
            on(this), this.completed = !1;
            let n = this.paused;
            return this.paused = !0, _e(this, t + this._delay, ~~e, ~~i, Ut.AUTO), n ? this : this.resume()
        }
        alternate() {
            let t = this._reversed,
                e = this.iterationCount,
                i = this.iterationDuration,
                n = e === 1 / 0 ? Re(ve / i) : e;
            return this._reversed = +(this._alternate && !(n % 2) ? t : !t), e === 1 / 0 ? this.iterationProgress = this._reversed ? 1 - this.iterationProgress : this.iterationProgress : this.seek(i * n - this._currentTime), this.resetTime(), this
        }
        play() {
            return this._reversed && this.alternate(), this.resume()
        }
        reverse() {
            return this._reversed || this.alternate(), this.resume()
        }
        cancel() {
            return this._hasChildren ? ot(this, t => t.cancel(), !0) : ot(this, nn), this._cancelled = 1, this.pause()
        }
        stretch(t) {
            let e = this.duration,
                i = Ne(t);
            if (e === i) return this;
            let n = t / e,
                o = t <= G;
            return this.duration = o ? G : i, this.iterationDuration = o ? G : Ne(this.iterationDuration * n), this._offset *= n, this._delay *= n, this._loopDelay *= n, this
        }
        revert() {
            _e(this, 0, 1, 0, Ut.AUTO);
            let t = this._autoplay;
            return t && t.linked && t.linked === this && t.revert(), this.cancel()
        }
        complete(t = 0) {
            return this.seek(this.duration, t).cancel()
        }
        then(t = Z) {
            let e = this.then,
                i = () => {
                    this.then = null, t(this), this.then = e, this._resolve = Z
                };
            return new Promise(n => (this._resolve = () => n(i()), this.completed && this._resolve(), this))
        }
    },
    Cs = s => new Ot(s, null, 0).init();

function Qs(s) {
    let t = vt(s) ? yt.root.querySelectorAll(s) : s;
    if (t instanceof NodeList || t instanceof HTMLCollection) return t
}

function Ht(s) {
    if (fe(s)) return [];
    if (!be) return Nt(s) && s.flat(1 / 0) || [s];
    if (Nt(s)) {
        let e = s.flat(1 / 0),
            i = [];
        for (let n = 0, o = e.length; n < o; n++) {
            let r = e[n];
            if (!fe(r)) {
                let a = Qs(r);
                if (a)
                    for (let l = 0, c = a.length; l < c; l++) {
                        let d = a[l];
                        if (!fe(d)) {
                            let u = !1;
                            for (let f = 0, g = i.length; f < g; f++)
                                if (i[f] === d) {
                                    u = !0;
                                    break
                                }
                            u || i.push(d)
                        }
                    } else {
                        let l = !1;
                        for (let c = 0, d = i.length; c < d; c++)
                            if (i[c] === r) {
                                l = !0;
                                break
                            }
                        l || i.push(r)
                    }
            }
        }
        return i
    }
    let t = Qs(s);
    return t ? Array.from(t) : [s]
}

function se(s) {
    let t = Ht(s),
        e = t.length;
    for (let i = 0; i < e; i++) {
        let n = t[i];
        if (!n[Zi]) {
            n[Zi] = !0;
            let o = Fe(n);
            (n.nodeType || o) && (n[de] = !0, n[Ke] = o, n[Te] = {})
        }
    }
    return t
}
var rn = {
        deg: 1,
        rad: 180 / oe,
        turn: 360
    },
    uo = {},
    qe = (s, t, e, i = !1) => {
        let n = t.u,
            o = t.n;
        if (t.t === nt.UNIT && n === e) return t;
        let r = o + n + e,
            a = uo[r];
        if (!S(a) && !i) t.n = a;
        else {
            let l;
            if (n in rn) l = o * rn[n] / rn[e];
            else {
                let d = s.cloneNode(),
                    u = s.parentNode,
                    f = u && u !== O ? u : O.body;
                f.appendChild(d);
                let g = d.style;
                g.width = 100 + n;
                let y = d.offsetWidth || 100;
                g.width = 100 + e;
                let h = d.offsetWidth || 100,
                    m = y / h;
                f.removeChild(d), l = m * o
            }
            t.n = l, uo[r] = l
        }
        return t.t, nt.UNIT, t.u = e, t
    };
var Wt = s => s;
var Es = (s = 1.68) => t => Le(t, +s),
    an = { in: s => t => s(t),
        out: s => t => 1 - s(1 - t),
        inOut: s => t => t < .5 ? s(t * 2) / 2 : 1 - s(t * -2 + 2) / 2,
        outIn: s => t => t < .5 ? (1 - s(1 - t * 2)) / 2 : (s(t * 2 - 1) + 1) / 2
    },
    Zo = oe / 2,
    fo = oe * 2,
    mo = {
        [Kt]: Es,
        Quad: Es(2),
        Cubic: Es(3),
        Quart: Es(4),
        Quint: Es(5),
        Sine: s => 1 - es(s * Zo),
        Circ: s => 1 - qt(1 - s * s),
        Expo: s => s ? Le(2, 10 * s - 10) : 0,
        Bounce: s => {
            let t, e = 4;
            for (; s < ((t = Le(2, --e)) - 1) / 11;);
            return 1 / Le(4, 3 - e) - 7.5625 * Le((t * 3 - 2) / 22 - s, 2)
        },
        Back: (s = 1.7) => t => (+s + 1) * t * t * t - +s * t * t,
        Elastic: (s = 1, t = .3) => {
            let e = I(+s, 1, 10),
                i = I(+t, G, 2),
                n = i / fo * Qn(1 / e),
                o = fo / i;
            return r => r === 0 || r === 1 ? r : -e * Le(2, -10 * (1 - r)) * ts((1 - r - n) * o)
        }
    },
    re = (() => {
        let s = {
            linear: Wt,
            none: Wt
        };
        for (let t in an)
            for (let e in mo) {
                let i = mo[e],
                    n = an[t];
                s[t + e] = e === Kt || e === "Back" || e === "Elastic" ? (o, r) => n(i(o, r)) : n(i)
            }
        return s
    })(),
    Js = {
        linear: Wt,
        none: Wt
    },
    ln = s => {
        if (Js[s]) return Js[s];
        if (s.indexOf("(") <= -1) {
            let e = an[s] || s.includes("Back") || s.includes("Elastic") ? re[s]() : re[s];
            return e ? Js[s] = e : Wt
        } else {
            let t = s.slice(0, -1).split("("),
                e = re[t[0]];
            return e ? Js[s] = e(...t[1].split(",")) : Wt
        }
    },
    po = ["steps(", "irregular(", "linear(", "cubicBezier("],
    Zt = s => {
        if (vt(s)) {
            for (let e = 0, i = po.length; e < i; e++)
                if (Pt(s, po[e])) return console.warn(`String syntax for \`ease: "${s}"\` has been removed from the core and replaced by importing and passing the easing function directly: \`ease: ${s}\``), Wt
        }
        return lt(s) ? s : vt(s) ? ln(s) : Wt
    };
var tt = qs(),
    ct = qs(),
    as = {},
    ti = {
        func: null
    },
    ei = {
        func: null
    },
    si = [null],
    ls = [null, null],
    ii = {
        to: null
    },
    Ko = 0,
    go = 0,
    Oe, we, Qo = (s, t) => {
        let e = {};
        if (Nt(s)) {
            let i = [].concat(...s.map(n => Object.keys(n))).filter(Ae);
            for (let n = 0, o = i.length; n < o; n++) {
                let r = i[n],
                    a = s.map(l => {
                        let c = {};
                        for (let d in l) {
                            let u = l[d];
                            Ae(d) ? d === r && (c.to = u) : c[d] = u
                        }
                        return c
                    });
                e[r] = a
            }
        } else {
            let i = P(t.duration, E.defaults.duration);
            Object.keys(s).map(o => ({
                o: parseFloat(o) / 100,
                p: s[o]
            })).sort((o, r) => o.o - r.o).forEach(o => {
                let r = o.o,
                    a = o.p;
                for (let l in a)
                    if (Ae(l)) {
                        let c = e[l];
                        c || (c = e[l] = []);
                        let d = r * i,
                            u = c.length,
                            f = c[u - 1],
                            g = {
                                to: a[l]
                            },
                            y = 0;
                        for (let h = 0; h < u; h++) y += c[h].duration;
                        u === 1 && (g.from = f.to), a.ease && (g.ease = a.ease), g.duration = d - (u ? y : 0), c.push(g)
                    }
                return o
            });
            for (let o in e) {
                let r = e[o],
                    a;
                for (let l = 0, c = r.length; l < c; l++) {
                    let d = r[l],
                        u = d.ease;
                    d.ease = a || void 0, a = u
                }
                r[0].duration || r.shift()
            }
        }
        return e
    },
    Qt = class extends Ot {
        constructor(t, e, i, n, o = !1, r = 0, a) {
            super(e, i, n), this._head, this._tail, ++go;
            let l = se(t),
                c = l.length,
                d = e.keyframes,
                u = d ? jt(Qo(d, e), e) : e,
                {
                    id: f,
                    delay: g,
                    duration: y,
                    ease: h,
                    playbackEase: m,
                    modifier: b,
                    composition: T,
                    onRender: _
                } = u,
                x = i ? i.defaults : E.defaults,
                L = P(h, x.ease),
                R = P(m, x.playbackEase),
                H = R ? Zt(R) : null,
                J = !S(L.ease),
                K = J ? L.ease : P(h, H ? "linear" : x.ease),
                z = J ? L.settlingDuration : P(y, x.duration),
                D = P(g, x.delay),
                M = b || x.modifier,
                q = S(T) && c >= Vt ? At.none : S(T) ? x.composition : T,
                N = this._offset + (i ? i._offset : 0);
            J && (L.parent = this);
            let F = NaN,
                at = NaN,
                p = 0,
                C = 0;
            for (let v = 0; v < c; v++) {
                let w = l[v],
                    V = r || v,
                    B = a || l,
                    k = NaN,
                    Y = NaN;
                for (let dt in u)
                    if (Ae(dt)) {
                        let X = xs(w, dt),
                            et = Ys(w, dt),
                            ut = ns(dt, w, X),
                            it = u[dt],
                            kt = Nt(it);
                        if (o && !kt && (ls[0] = it, ls[1] = it, it = ls), kt) {
                            let ft = it.length,
                                pt = !wt(it[0]);
                            ft === 2 && pt ? (ii.to = it, si[0] = ii, Oe = si) : ft > 2 && pt ? (Oe = [], it.forEach((St, Ct) => {
                                Ct ? Ct === 1 ? (ls[1] = St, Oe.push(ls)) : Oe.push(St) : ls[0] = St
                            })) : Oe = it
                        } else si[0] = it, Oe = si;
                        let Dt = null,
                            U = null,
                            rt = NaN,
                            xt = 0,
                            $t = 0;
                        for (let ft = Oe.length; $t < ft; $t++) {
                            let pt = Oe[$t];
                            wt(pt) ? we = pt : (ii.to = pt, we = ii), ti.func = null, ei.func = null;
                            let St = Rt(P(we.composition, q), w, V, B, null, null),
                                Ct = Lt(St) ? St : At[St];
                            !Dt && Ct !== At.none && (Dt = ws(w, ut));
                            let Xt = Dt ? Dt._tail : null,
                                ht = i && Xt && Xt.parent.parent === i ? Xt : U,
                                _t = Rt(we.to, w, V, B, ti, ht),
                                Q;
                            wt(_t) && !S(_t.to) ? (we = _t, Q = _t.to) : Q = _t;
                            let Tt = Rt(we.from, w, V, B, ei, ht),
                                $ = we.ease || K,
                                st = Rt($, w, V, B, null, ht),
                                j = lt(st) || vt(st) ? st : $,
                                W = !S(j) && !S(j.ease),
                                mt = W ? j.ease : j,
                                Et = W ? j.settlingDuration : Rt(P(we.duration, ft > 1 ? Rt(z, w, V, B, null, ht) / ft : z), w, V, B, null, ht),
                                Jt = Rt(P(we.delay, $t ? 0 : D), w, V, B, null, ht),
                                Ie = we.modifier || M,
                                Ve = !S(Tt),
                                ps = !S(Q),
                                gs = Nt(Q),
                                Bo = gs || Ve && ps,
                                Mo = U ? xt : 0,
                                Wi = U ? xt + Jt : Jt,
                                qi = A(N + Wi, 12),
                                Ho = A(N + Mo, 12);
                            !C && (Ve || gs) && (C = 1);
                            let he = U;
                            if (Ct !== At.none) {
                                let gt = Dt._head;
                                for (; gt && gt._absoluteStartTime <= qi;)
                                    if (gt._isOverridden || (he = gt), gt = gt._nextRep, gt && gt._absoluteStartTime >= qi)
                                        for (; gt;) _s(gt), gt = gt._nextRep
                            }
                            if (Bo) {
                                Yt(gs ? Rt(Q[0], w, V, B, ei, ht) : Tt, tt), Yt(gs ? Rt(Q[1], w, V, B, ti, ht) : Q, ct);
                                let gt = xe(w, ut, X, as);
                                tt.t === nt.NUMBER && (he ? he._valueType === nt.UNIT && (tt.t = nt.UNIT, tt.u = he._unit) : (Yt(gt, It), It.t === nt.UNIT && (tt.t = nt.UNIT, tt.u = It.u)))
                            } else ps ? Yt(Q, ct) : U ? en(U, ct) : Yt(i && he && he.parent.parent === i ? he._value : xe(w, ut, X, as), ct), Ve ? Yt(Tt, tt) : U ? en(U, tt) : Yt(i && he && he.parent.parent === i ? he._value : xe(w, ut, X, as), tt);
                            if (tt.o && (tt.n = Se(he ? he._toNumber : Yt(xe(w, ut, X, as), It).n, tt.n, tt.o)), ct.o && (ct.n = Se(tt.n, ct.n, ct.o)), tt.t !== ct.t) {
                                if (tt.t === nt.COMPLEX || ct.t === nt.COMPLEX) {
                                    let gt = tt.t === nt.COMPLEX ? tt : ct,
                                        te = tt.t === nt.COMPLEX ? ct : tt;
                                    te.t = nt.COMPLEX, te.s = Mt(gt.s), te.d = gt.d.map(() => te.n)
                                } else if (tt.t === nt.UNIT || ct.t === nt.UNIT) {
                                    let gt = tt.t === nt.UNIT ? tt : ct,
                                        te = tt.t === nt.UNIT ? ct : tt;
                                    te.t = nt.UNIT, te.u = gt.u
                                } else if (tt.t === nt.COLOR || ct.t === nt.COLOR) {
                                    let gt = tt.t === nt.COLOR ? tt : ct,
                                        te = tt.t === nt.COLOR ? ct : tt;
                                    te.t = nt.COLOR, te.d = gt.d.map(() => 0)
                                }
                            }
                            if (tt.u !== ct.u) {
                                let gt = ct.u ? tt : ct;
                                gt = qe(w, gt, ct.u ? ct.u : tt.u, !1)
                            }
                            if (ct.d && tt.d && ct.d.length !== tt.d.length) {
                                let gt = tt.d.length > ct.d.length ? tt : ct,
                                    te = gt === tt ? ct : tt;
                                te.d = gt.d.map((Pr, On) => S(te.d[On]) ? 0 : te.d[On]), te.s = Mt(gt.s)
                            }
                            let ji = A(+Et || G, 12),
                                In = as[ut];
                            fe(In) || (as[ut] = null);
                            let Xo = et ? et.set : null;
                            xt = A(Wi + ji, 12);
                            let Ms = tt.d,
                                Vn = ct.d,
                                Fn = ct.s,
                                le = {
                                    parent: this,
                                    id: Ko++,
                                    property: ut,
                                    target: w,
                                    _value: null,
                                    _toFunc: ti.func,
                                    _fromFunc: ei.func,
                                    _ease: Zt(mt),
                                    _fromNumbers: Ms ? Mt(Ms) : vs,
                                    _toNumbers: Vn ? Mt(Vn) : vs,
                                    _strings: Fn ? Mt(Fn) : vs,
                                    _fromNumber: tt.n,
                                    _toNumber: ct.n,
                                    _numbers: Ms ? Mt(Ms) : vs,
                                    _number: tt.n,
                                    _unit: ct.u,
                                    _modifier: Ie,
                                    _currentTime: 0,
                                    _startTime: Wi,
                                    _delay: +Jt,
                                    _updateDuration: ji,
                                    _changeDuration: ji,
                                    _absoluteStartTime: qi,
                                    _absoluteUpdateStartTime: Ho,
                                    _absoluteEndTime: A(N + xt, 12),
                                    _hasFromValue: Ve || gs ? 1 : 0,
                                    _tweenType: X,
                                    _setter: Xo,
                                    _valueType: ct.t,
                                    _composition: Ct,
                                    _isOverlapped: 0,
                                    _isOverridden: 0,
                                    _renderTransforms: 0,
                                    _inlineValue: In,
                                    _prevRep: null,
                                    _nextRep: null,
                                    _prevAdd: null,
                                    _nextAdd: null,
                                    _prev: null,
                                    _next: null
                                };
                            Ct !== At.none && Ks(le, Dt);
                            let Gi = le._valueType;
                            if (Gi === nt.COMPLEX) le._value = js(le, 1, -1);
                            else if (Gi === nt.UNIT) le._value = `${Ie(le._toNumber)}${le._unit}`;
                            else if (Gi === nt.COLOR) {
                                let gt = ct.d;
                                le._value = `rgba(${A(gt[0],0)},${A(gt[1],0)},${A(gt[2],0)},${gt[3]})`
                            } else le._value = Ie(le._toNumber);
                            isNaN(rt) && (rt = le._startTime), U = le, p++, zt(this, le)
                        }(isNaN(at) || rt < at) && (at = rt), (isNaN(F) || xt > F) && (F = xt), X === bt.TRANSFORM && (k = p - $t, Y = p)
                    }
                if (!isNaN(k)) {
                    let dt = 0;
                    ot(this, X => {
                        dt >= k && dt < Y && (X._renderTransforms = 1, X._composition === At.blend && ot(ke.animation, et => {
                            et.id === X.id && (et._renderTransforms = 1)
                        })), dt++
                    })
                }
            }
            c || console.warn("No target found. Make sure the element you're trying to animate is accessible before creating your animation."), at ? (ot(this, v => {
                v._startTime - v._delay || (v._delay -= at), v._startTime -= at
            }), F -= at) : at = 0, F || (F = G, this.iterationCount = 0), this.targets = l, this.id = S(f) ? go : f, this.duration = F === G ? G : is((F + this._loopDelay) * this.iterationCount - this._loopDelay) || G, this.onRender = _ || x.onRender, this._ease = H, this._delay = at, this.iterationDuration = F, !this._autoplay && C && this.onRender(this)
        }
        stretch(t) {
            let e = this.duration;
            if (e === Ne(t)) return this;
            let i = t / e;
            return ot(this, n => {
                n._updateDuration = Ne(n._updateDuration * i), n._changeDuration = Ne(n._changeDuration * i), n._currentTime *= i, n._delay *= i, n._startTime *= i, n._absoluteStartTime *= i, n._absoluteUpdateStartTime *= i, n._absoluteEndTime *= i
            }), super.stretch(t)
        }
        refresh() {
            return ot(this, t => {
                let e = t._toFunc,
                    i = t._fromFunc;
                (e || i) && (i ? (Yt(i(), tt), tt.u !== t._unit && t.target[de] && qe(t.target, tt, t._unit, !0), t._fromNumbers = Mt(tt.d), t._fromNumber = tt.n) : e && (Yt(xe(t.target, t.property, t._tweenType), It), t._fromNumbers = Mt(It.d), t._fromNumber = It.n), e && (Yt(e(), ct), t._toNumbers = Mt(ct.d), t._strings = Mt(ct.s), t._toNumber = ct.o ? Se(t._fromNumber, ct.n, ct.o) : ct.n))
            }), this.duration === G && this.restart(), this
        }
        revert() {
            return super.revert(), os(this)
        }
        then(t) {
            return super.then(t)
        }
    },
    Ce = (s, t) => E.editor ? E.editor.addAnimation(s, t) : new Qt(s, t, null, 0, !1).init();
var Jo = (s, t) => {
        if (Pt(t, "<")) {
            let e = t[1] === "<",
                i = s._tail,
                n = i ? i._offset + i._delay : 0;
            return e ? n : n + i.duration
        }
    },
    je = (s, t) => {
        let e = s.iterationDuration;
        if (e === G && (e = 0), S(t)) return e;
        if (Lt(+t)) return +t;
        let i = t,
            n = s ? s.labels : null,
            o = !fe(n),
            r = Jo(s, i),
            a = !S(r),
            l = zs.exec(i);
        if (l) {
            let c = l[0],
                d = i.split(c),
                u = o && d[0] ? n[d[0]] : e,
                f = a ? r : o ? u : e,
                g = +d[1];
            return Se(f, g, c[0])
        } else return a ? r : o ? S(n[i]) ? e : n[i] : e
    };

function tr(s) {
    return is((s.iterationDuration + s._loopDelay) * s.iterationCount - s._loopDelay) || G
}

function cn(s, t, e, i, n, o) {
    let a = Lt(s.duration) && s.duration <= G ? e - G : e;
    t.composition && _e(t, a, 1, 1, Ut.AUTO);
    let l = i ? new Qt(i, s, t, a, !1, n, o) : new Ot(s, t, a);
    return t.composition && l.init(!0), zt(t, l), ot(t, c => {
        let u = c._offset + c._delay + c.duration;
        u > t.iterationDuration && (t.iterationDuration = u)
    }), t.duration = tr(t), t
}
var yo = 0,
    As = class extends Ot {
        constructor(t = {}) {
            super(t, null, 0), ++yo, this.id = S(t.id) ? yo : t.id, this.duration = 0, this.labels = {};
            let e = t.defaults,
                i = E.defaults;
            this.defaults = e ? jt(e, i) : i, this.composition = P(t.composition, !0), this.onRender = t.onRender || i.onRender;
            let n = P(t.playbackEase, i.playbackEase);
            this._ease = n ? Zt(n) : null, this.iterationDuration = 0
        }
        add(t, e, i) {
            let n = wt(e),
                o = wt(t);
            if (n || o) {
                if (this._hasChildren = !0, n) {
                    let r = e,
                        a = E.editor && E.editor.addTimelineChild,
                        l = i && i.type === "Stagger" && E.editor,
                        c = lt(i) ? i : null;
                    if (c || l) {
                        let d = Ht(t),
                            u = this.duration,
                            f = this.iterationDuration,
                            g = r.id,
                            y = 0,
                            h = d.length,
                            m = a ? a(t, r, this.id, i, h) : null,
                            b = c || E.editor.resolveStagger(i.defaultValue);
                        d.forEach(T => {
                            let _ = { ...m || r
                            };
                            this.duration = u, this.iterationDuration = f, S(g) || (_.id = g + "-" + y);
                            let x = je(this, b(T, y, d, null, this));
                            cn(_, this, x, T, y, d), y++
                        })
                    } else {
                        let d = a ? a(t, r, this.id, i) : r,
                            u = i && i.type ? i.defaultValue : i;
                        cn(d, this, je(this, u), t)
                    }
                } else cn(t, this, je(this, e));
                return this.composition && this.init(!0), this
            }
        }
        sync(t, e) {
            if (S(t) || t && S(t.pause)) return this;
            t.pause();
            let i = +(t.effect ? t.effect.getTiming().duration : t.duration);
            !S(t) && !S(t.persist) && (t.persist = !0);
            let n = E.editor,
                o = n && n.addTimelineChild;
            n && n.addTimelineSync && (e = n.addTimelineSync(t, e, this.id), n.addTimelineChild = null);
            let r = this.add(t, {
                currentTime: [0, i],
                duration: i,
                delay: 0,
                ease: "linear",
                playbackEase: "linear"
            }, e);
            return n && (n.addTimelineChild = o), r
        }
        set(t, e, i) {
            return S(e) ? this : (e.duration = G, e.composition = At.replace, this.add(t, e, i))
        }
        call(t, e) {
            return S(t) || t && !lt(t) ? this : (E.editor && E.editor.addTimelineCall && (e = E.editor.addTimelineCall(t, e, this.id)), this.add({
                duration: 0,
                delay: 0,
                onComplete: () => t(this)
            }, e))
        }
        label(t, e) {
            return S(t) || t && !vt(t) ? this : (E.editor && E.editor.addTimelineLabel && (e = E.editor.addTimelineLabel(t, e, this.id)), this.labels[t] = je(this, e), this)
        }
        remove(t, e) {
            return me(Ht(t), this, e), this
        }
        stretch(t) {
            let e = this.duration;
            if (e === Ne(t)) return this;
            let i = t / e,
                n = this.labels;
            ot(this, o => o.stretch(o.duration * i));
            for (let o in n) n[o] *= i;
            return super.stretch(t)
        }
        refresh() {
            return ot(this, t => {
                t.refresh && t.refresh()
            }), this
        }
        revert() {
            return super.revert(), ot(this, t => t.revert, !0), os(this)
        }
        then(t) {
            return super.then(t)
        }
    },
    Be = s => E.editor ? E.editor.addTimeline(s) : new As(s).init();
var Ge = class {
        constructor(t, e) {
            yt.current && yt.current.register(this);
            let i = () => {
                    this.callbacks.completed && this.callbacks.reset(), this.callbacks.play()
                },
                n = () => {
                    if (this.callbacks.completed) return;
                    let l = !0;
                    for (let c in this.animations)
                        if (!this.animations[c].paused && l) {
                            l = !1;
                            break
                        }
                    l && this.callbacks.complete()
                },
                o = {
                    onBegin: i,
                    onComplete: n,
                    onPause: n
                },
                r = {
                    v: 1,
                    autoplay: !1
                },
                a = {};
            if (this.targets = [], this.animations = {}, this.callbacks = null, !(S(t) || S(e))) {
                for (let l in e) {
                    let c = e[l];
                    Ae(l) ? a[l] = c : Pt(l, "on") ? r[l] = c : o[l] = c
                }
                this.callbacks = new Qt({
                    v: 0
                }, r);
                for (let l in a) {
                    let c = a[l],
                        d = wt(c),
                        u = {},
                        f = "+=0";
                    if (d) {
                        let h = c.unit;
                        vt(h) && (f += h)
                    } else u.duration = c;
                    u[l] = d ? jt({
                        to: f
                    }, c) : f;
                    let g = jt(o, u);
                    g.composition = At.replace, g.autoplay = !1;
                    let y = this.animations[l] = new Qt(t, g, null, 0, !1).init();
                    this.targets.length || this.targets.push(...y.targets), this[l] = (h, m, b) => {
                        let T = y._head;
                        if (S(h) && T) {
                            let _ = T._numbers;
                            return _ && _.length ? _ : T._modifier(T._number)
                        } else return ot(y, _ => {
                            if (Nt(h))
                                for (let x = 0, L = h.length; x < L; x++) S(_._numbers[x]) || (_._fromNumbers[x] = _._modifier(_._numbers[x]), _._toNumbers[x] = h[x]);
                            else _._fromNumber = _._modifier(_._number), _._toNumber = h;
                            S(b) || (_._ease = Zt(b)), _._currentTime = 0
                        }), S(m) || y.stretch(m), y.reset(!0).resume(), this
                    }
                }
            }
        }
        revert() {
            for (let t in this.animations) this[t] = Z, this.animations[t].revert();
            return this.animations = {}, this.targets.length = 0, this.callbacks && this.callbacks.revert(), this
        }
    },
    vo = (s, t) => new Ge(s, t);
var ae = Vt * 10,
    Me = class {
        constructor(t = {}) {
            let e = !S(t.bounce) || !S(t.duration);
            this.timeStep = .02, this.restThreshold = 5e-4, this.restDuration = 200, this.maxDuration = 6e4, this.maxRestSteps = this.restDuration / this.timeStep / Vt, this.maxIterations = this.maxDuration / this.timeStep / Vt, this.bn = I(P(t.bounce, .5), -1, 1), this.pd = I(P(t.duration, 628), 10 * E.timeScale, ae * E.timeScale), this.m = I(P(t.mass, 1), 1, ae), this.s = I(P(t.stiffness, 100), G, ae), this.d = I(P(t.damping, 10), G, ae), this.v = I(P(t.velocity, 0), -ae, ae), this.w0 = 0, this.zeta = 0, this.wd = 0, this.b = 0, this.completed = !1, this.solverDuration = 0, this.settlingDuration = 0, this.parent = null, this.onComplete = t.onComplete || Z, e && this.calculateSDFromBD(), this.compute(), this.ease = i => {
                let n = i * this.settlingDuration,
                    o = this.completed,
                    r = this.pd;
                return n >= r && !o && (this.completed = !0, this.onComplete(this.parent)), n < r && o && (this.completed = !1), i === 0 || i === 1 ? i : this.solve(i * this.solverDuration)
            }
        }
        solve(t) {
            let {
                zeta: e,
                w0: i,
                wd: n,
                b: o
            } = this, r = t;
            return e < 1 ? r = bs(-r * e * i) * (1 * es(n * r) + o * ts(n * r)) : e === 1 ? r = (1 + o * r) * bs(-r * i) : r = ((1 + o) * bs((-e * i + n) * r) + (1 - o) * bs((-e * i - n) * r)) / 2, 1 - r
        }
        calculateSDFromBD() {
            let t = E.timeScale === 1 ? this.pd / Vt : this.pd;
            this.m = 1, this.v = 0, this.s = Le(2 * oe / t, 2), this.bn >= 0 ? this.d = (1 - this.bn) * 4 * oe / t : this.d = 4 * oe / (t * (1 + this.bn)), this.s = A(I(this.s, G, ae), 3), this.d = A(I(this.d, G, 300), 3)
        }
        calculateBDFromSD() {
            let t = 2 * oe / qt(this.s);
            this.pd = t * (E.timeScale === 1 ? Vt : 1), this.d / (2 * qt(this.s)) <= 1 ? this.bn = 1 - this.d * t / (4 * oe) : this.bn = 4 * oe / (this.d * t) - 1, this.bn = A(I(this.bn, -1, 1), 3), this.pd = A(I(this.pd, 10 * E.timeScale, ae * E.timeScale), 3)
        }
        compute() {
            let {
                maxRestSteps: t,
                maxIterations: e,
                restThreshold: i,
                timeStep: n,
                m: o,
                d: r,
                s: a,
                v: l
            } = this, c = this.w0 = I(qt(a / o), G, Vt), d = this.zeta = r / (2 * qt(a * o));
            d < 1 ? (this.wd = c * qt(1 - d * d), this.b = (d * c + -l) / this.wd) : d === 1 ? (this.wd = 0, this.b = -l + c) : (this.wd = c * qt(d * d - 1), this.b = (d * c + -l) / this.wd);
            let u = 0,
                f = 0,
                g = 0;
            for (; f <= t && g <= e;) ne(1 - this.solve(u)) < i ? f++ : f = 0, this.solverDuration = u, u += n, g++;
            this.settlingDuration = A(this.solverDuration * Vt, 0) * E.timeScale
        }
        get bounce() {
            return this.bn
        }
        set bounce(t) {
            this.bn = I(P(t, 1), -1, 1), this.calculateSDFromBD(), this.compute()
        }
        get duration() {
            return this.pd
        }
        set duration(t) {
            this.pd = I(P(t, 1), 10 * E.timeScale, ae * E.timeScale), this.calculateSDFromBD(), this.compute()
        }
        get stiffness() {
            return this.s
        }
        set stiffness(t) {
            this.s = I(P(t, 100), G, ae), this.calculateBDFromSD(), this.compute()
        }
        get damping() {
            return this.d
        }
        set damping(t) {
            this.d = I(P(t, 10), G, ae), this.calculateBDFromSD(), this.compute()
        }
        get mass() {
            return this.m
        }
        set mass(t) {
            this.m = I(P(t, 1), 1, ae), this.compute()
        }
        get velocity() {
            return this.v
        }
        set velocity(t) {
            this.v = I(P(t, 0), -ae, ae), this.compute()
        }
    },
    Ze = s => new Me(s),
    ni = s => (console.warn("createSpring() is deprecated use spring() instead"), new Me(s));
var hn = {
        _head: null,
        _tail: null
    },
    oi = (s, t, e) => {
        let i = hn._head,
            n;
        for (; i;) {
            let o = i._next,
                r = i.$el === s,
                a = !t || i.property === t,
                l = !e || i.parent === e;
            if (r && a && l) {
                n = i.animation;
                try {
                    n.commitStyles()
                } catch {}
                n.cancel(), Gt(hn, i);
                let c = i.parent;
                c && (c._completed++, c.animations.length === c._completed && (c.completed = !0, c.paused = !0, c.muteCallbacks || (c.onComplete(c), c._resolve(c))))
            }
            i = o
        }
        return n
    },
    dn = (s, t, e, i, n) => {
        let o = t.animate(i, n),
            r = n.delay + +n.duration * n.iterations;
        o.playbackRate = s._speed, s.paused && o.pause(), s.duration < r && (s.duration = r, s.controlAnimation = o), s.animations.push(o), oi(t, e), zt(hn, {
            parent: s,
            animation: o,
            $el: t,
            property: e,
            _next: null,
            _prev: null
        });
        let a = () => oi(t, e, s);
        return o.oncancel = a, o.onremove = a, s.persist || (o.onfinish = a), o
    };

function pe(s, t, e) {
    let i = se(s);
    if (!i.length) return;
    let [n] = i, o = xs(n, t), r = ns(t, n, o), a = xe(n, r);
    if (S(e)) return a;
    if (Yt(a, It), It.t === nt.NUMBER || It.t === nt.UNIT) {
        if (e === !1) return It.n; {
            let l = qe(n, It, e, !1);
            return `${A(l.n,E.precision)}${l.u}`
        }
    }
}
var ce = (s, t) => {
        if (!S(t)) return E.editor && E.editor.addSet ? E.editor.addSet(s, t) : (t.duration = G, t.composition = P(t.composition, At.none), new Qt(s, t, null, 0, !0).resume())
    },
    ri = (s, t, e) => {
        let i = Ht(s);
        for (let n = 0, o = i.length; n < o; n++) oi(i[n], e, t && t.controlAnimation && t);
        return me(i, t, e), i
    };
var He = s => {
        s.cancelable && s.preventDefault()
    },
    un = class {
        constructor(t) {
            this.el = t, this.zIndex = 0, this.parentElement = null, this.classList = {
                add: Z,
                remove: Z
            }
        }
        get x() {
            return this.el.x || 0
        }
        set x(t) {
            this.el.x = t
        }
        get y() {
            return this.el.y || 0
        }
        set y(t) {
            this.el.y = t
        }
        get width() {
            return this.el.width || 0
        }
        set width(t) {
            this.el.width = t
        }
        get height() {
            return this.el.height || 0
        }
        set height(t) {
            this.el.height = t
        }
        getBoundingClientRect() {
            return {
                top: this.y,
                right: this.x,
                bottom: this.y + this.height,
                left: this.x + this.width
            }
        }
    },
    fn = class {
        constructor(t) {
            this.$el = t, this.inlineTransforms = [], this.point = new DOMPoint, this.inversedMatrix = this.getMatrix().inverse()
        }
        normalizePoint(t, e) {
            return this.point.x = t, this.point.y = e, this.point.matrixTransform(this.inversedMatrix)
        }
        traverseUp(t) {
            let e = this.$el.parentElement,
                i = 0;
            for (; e && e !== O;) t(e, i), e = e.parentElement, i++
        }
        getMatrix() {
            let t = new DOMMatrix;
            return this.traverseUp(e => {
                let i = getComputedStyle(e).transform;
                if (i) {
                    let n = new DOMMatrix(i);
                    t.preMultiplySelf(n)
                }
            }), t
        }
        remove() {
            this.traverseUp((t, e) => {
                this.inlineTransforms[e] = t.style.transform, t.style.transform = "none"
            })
        }
        revert() {
            this.traverseUp((t, e) => {
                let i = this.inlineTransforms[e];
                i === "" ? t.style.removeProperty("transform") : t.style.transform = i
            })
        }
    },
    ie = (s, t) => s && lt(s) ? s(t) : s,
    ai = 0,
    Ps = class {
        constructor(t, e = {}) {
            if (!t) return;
            yt.current && yt.current.register(this);
            let i = e.x,
                n = e.y,
                o = e.trigger,
                r = e.modifier,
                a = e.releaseEase,
                l = a && Zt(a),
                c = !S(a) && !S(a.ease),
                d = wt(i) && !S(i.mapTo) ? i.mapTo : "translateX",
                u = wt(n) && !S(n.mapTo) ? n.mapTo : "translateY",
                f = ie(e.container, this);
            this.containerArray = Nt(f) ? f : null, this.$container = f && !this.containerArray ? Ht(f)[0] : O.body, this.useWin = this.$container === O.body, this.$scrollContainer = this.useWin ? ee : this.$container, this.$target = wt(t) ? new un(t) : Ht(t)[0], this.$trigger = Ht(o || t)[0], this.fixed = pe(this.$target, "position") === "fixed", this.isFinePointer = !0, this.containerPadding = [0, 0, 0, 0], this.containerFriction = 0, this.releaseContainerFriction = 0, this.snapX = 0, this.snapY = 0, this.scrollSpeed = 0, this.scrollThreshold = 0, this.dragSpeed = 0, this.dragThreshold = 3, this.maxVelocity = 0, this.minVelocity = 0, this.velocityMultiplier = 0, this.cursor = !1, this.releaseXSpring = c ? a : Ze({
                mass: P(e.releaseMass, 1),
                stiffness: P(e.releaseStiffness, 80),
                damping: P(e.releaseDamping, 20)
            }), this.releaseYSpring = c ? a : Ze({
                mass: P(e.releaseMass, 1),
                stiffness: P(e.releaseStiffness, 80),
                damping: P(e.releaseDamping, 20)
            }), this.releaseEase = l || re.outQuint, this.hasReleaseSpring = c, this.onGrab = e.onGrab || Z, this.onDrag = e.onDrag || Z, this.onRelease = e.onRelease || Z, this.onUpdate = e.onUpdate || Z, this.onSettle = e.onSettle || Z, this.onSnap = e.onSnap || Z, this.onResize = e.onResize || Z, this.onAfterResize = e.onAfterResize || Z, this.disabled = [0, 0];
            let g = {};
            if (r && (g.modifier = r), S(i) || i === !0) g[d] = 0;
            else if (wt(i)) {
                let y = i,
                    h = {};
                y.modifier && (h.modifier = y.modifier), y.composition && (h.composition = y.composition), g[d] = h
            } else i === !1 && (g[d] = 0, this.disabled[0] = 1);
            if (S(n) || n === !0) g[u] = 0;
            else if (wt(n)) {
                let y = n,
                    h = {};
                y.modifier && (h.modifier = y.modifier), y.composition && (h.composition = y.composition), g[u] = h
            } else n === !1 && (g[u] = 0, this.disabled[1] = 1);
            this.animate = new Ge(this.$target, g), this.xProp = d, this.yProp = u, this.destX = 0, this.destY = 0, this.deltaX = 0, this.deltaY = 0, this.scroll = {
                x: 0,
                y: 0
            }, this.coords = [this.x, this.y, 0, 0], this.snapped = [0, 0], this.pointer = [0, 0, 0, 0, 0, 0, 0, 0], this.scrollView = [0, 0], this.dragArea = [0, 0, 0, 0], this.containerBounds = [-ve, ve, ve, -ve], this.scrollBounds = [0, 0, 0, 0], this.targetBounds = [0, 0, 0, 0], this.window = [0, 0], this.velocityStack = [0, 0, 0], this.velocityStackIndex = 0, this.velocityTime = ue(), this.velocity = 0, this.angle = 0, this.cursorStyles = null, this.triggerStyles = null, this.bodyStyles = null, this.targetStyles = null, this.touchActionStyles = null, this.transforms = new fn(this.$target), this.overshootCoords = {
                x: 0,
                y: 0
            }, this.overshootTicker = new Ot({
                autoplay: !1,
                onUpdate: () => {
                    this.updated = !0, this.manual = !0, this.disabled[0] || this.animate[this.xProp](this.overshootCoords.x, 1), this.disabled[1] || this.animate[this.yProp](this.overshootCoords.y, 1)
                },
                onComplete: () => {
                    this.manual = !1, this.disabled[0] || this.animate[this.xProp](this.overshootCoords.x, 0), this.disabled[1] || this.animate[this.yProp](this.overshootCoords.y, 0)
                }
            }, null, 0).init(), this.updateTicker = new Ot({
                autoplay: !1,
                onUpdate: () => this.update()
            }, null, 0).init(), this.contained = !S(f), this.manual = !1, this.grabbed = !1, this.dragged = !1, this.updated = !1, this.released = !1, this.canScroll = !1, this.enabled = !1, this.initialized = !1, this.activeProp = this.disabled[1] ? d : u, this.animate.callbacks.onRender = () => {
                let y = this.updated,
                    m = !(this.grabbed && y) && this.released,
                    b = this.x,
                    T = this.y,
                    _ = b - this.coords[2],
                    x = T - this.coords[3];
                this.deltaX = _, this.deltaY = x, this.coords[2] = b, this.coords[3] = T, y && (_ || x) && this.onUpdate(this), m ? (this.computeVelocity(_, x), this.angle = ss(x, _)) : this.updated = !1
            }, this.animate.callbacks.onComplete = () => {
                !this.grabbed && this.released && (this.released = !1), this.manual || (this.deltaX = 0, this.deltaY = 0, this.velocity = 0, this.velocityStack[0] = 0, this.velocityStack[1] = 0, this.velocityStack[2] = 0, this.velocityStackIndex = 0, this.onSettle(this))
            }, this.resizeTicker = new Ot({
                autoplay: !1,
                duration: 150 * E.timeScale,
                onComplete: () => {
                    this.onResize(this), this.refresh(), this.onAfterResize(this)
                }
            }).init(), this.parameters = e, this.resizeObserver = new ResizeObserver(() => {
                this.initialized ? this.resizeTicker.restart() : this.initialized = !0
            }), this.enable(), this.refresh(), this.resizeObserver.observe(this.$container), wt(t) || this.resizeObserver.observe(this.$target)
        }
        computeVelocity(t, e) {
            let i = this.velocityTime,
                n = ue(),
                o = n - i;
            if (o < 17) return this.velocity;
            this.velocityTime = n;
            let r = this.velocityStack,
                a = this.velocityMultiplier,
                l = this.minVelocity,
                c = this.maxVelocity,
                d = this.velocityStackIndex;
            r[d] = A(I(qt(t * t + e * e) / o * a, l, c), 5);
            let u = Ji(r[0], r[1], r[2]);
            return this.velocity = u, this.velocityStackIndex = (d + 1) % 3, u
        }
        setX(t, e = !1) {
            if (this.disabled[0]) return;
            let i = A(t, 5);
            return this.overshootTicker.pause(), this.manual = !0, this.updated = !e, this.destX = i, this.snapped[0] = We(i, this.snapX), this.animate[this.xProp](i, 0), this.manual = !1, this
        }
        setY(t, e = !1) {
            if (this.disabled[1]) return;
            let i = A(t, 5);
            return this.overshootTicker.pause(), this.manual = !0, this.updated = !e, this.destY = i, this.snapped[1] = We(i, this.snapY), this.animate[this.yProp](i, 0), this.manual = !1, this
        }
        get x() {
            return A(this.animate[this.xProp](), E.precision)
        }
        set x(t) {
            this.setX(t, !1)
        }
        get y() {
            return A(this.animate[this.yProp](), E.precision)
        }
        set y(t) {
            this.setY(t, !1)
        }
        get progressX() {
            return Ts(this.x, this.containerBounds[3], this.containerBounds[1], 0, 1)
        }
        set progressX(t) {
            this.setX(Ts(t, 0, 1, this.containerBounds[3], this.containerBounds[1]), !1)
        }
        get progressY() {
            return Ts(this.y, this.containerBounds[0], this.containerBounds[2], 0, 1)
        }
        set progressY(t) {
            this.setY(Ts(t, 0, 1, this.containerBounds[0], this.containerBounds[2]), !1)
        }
        updateScrollCoords() {
            let t = A(this.useWin ? ee.scrollX : this.$container.scrollLeft, 0),
                e = A(this.useWin ? ee.scrollY : this.$container.scrollTop, 0),
                [i, n, o, r] = this.containerPadding,
                a = this.scrollThreshold;
            this.scroll.x = t, this.scroll.y = e, this.scrollBounds[0] = e - this.targetBounds[0] + i - a, this.scrollBounds[1] = t - this.targetBounds[1] - n + a, this.scrollBounds[2] = e - this.targetBounds[2] - o + a, this.scrollBounds[3] = t - this.targetBounds[3] + r - a
        }
        updateBoundingValues() {
            let t = this.$container;
            if (!t) return;
            let e = this.x,
                i = this.y,
                n = this.coords[2],
                o = this.coords[3];
            this.coords[2] = 0, this.coords[3] = 0, this.setX(0, !0), this.setY(0, !0), this.transforms.remove();
            let r = this.window[0] = ee.innerWidth,
                a = this.window[1] = ee.innerHeight,
                l = this.useWin,
                c = t.scrollWidth,
                d = t.scrollHeight,
                u = this.fixed,
                f = t.getBoundingClientRect(),
                [g, y, h, m] = this.containerPadding;
            this.dragArea[0] = l ? 0 : f.left, this.dragArea[1] = l ? 0 : f.top, this.scrollView[0] = l ? I(c, r, c) : c, this.scrollView[1] = l ? I(d, a, d) : d, this.updateScrollCoords();
            let {
                width: b,
                height: T,
                left: _,
                top: x,
                right: L,
                bottom: R
            } = t.getBoundingClientRect();
            this.dragArea[2] = A(l ? I(b, r, r) : b, 0), this.dragArea[3] = A(l ? I(T, a, a) : T, 0);
            let H = pe(t, "overflow"),
                J = H === "visible",
                K = H === "hidden";
            if (this.canScroll = u ? !1 : this.contained && (t === O.body && J || !K && !J) && (c > this.dragArea[2] + m - y || d > this.dragArea[3] + g - h) && (!this.containerArray || this.containerArray && !Nt(this.containerArray)), this.contained) {
                let z = this.scroll.x,
                    D = this.scroll.y,
                    M = this.canScroll,
                    q = this.$target.getBoundingClientRect(),
                    N = M ? l ? 0 : t.scrollLeft : 0,
                    F = M ? l ? 0 : t.scrollTop : 0,
                    at = M ? this.scrollView[0] - N - b : 0,
                    p = M ? this.scrollView[1] - F - T : 0;
                this.targetBounds[0] = A(q.top + D - (l ? 0 : x), 0), this.targetBounds[1] = A(q.right + z - (l ? r : L), 0), this.targetBounds[2] = A(q.bottom + D - (l ? a : R), 0), this.targetBounds[3] = A(q.left + z - (l ? 0 : _), 0), this.containerArray ? (this.containerBounds[0] = this.containerArray[0] + g, this.containerBounds[1] = this.containerArray[1] - y, this.containerBounds[2] = this.containerArray[2] - h, this.containerBounds[3] = this.containerArray[3] + m) : (this.containerBounds[0] = -A(q.top - (u ? I(x, 0, a) : x) + F - g, 0), this.containerBounds[1] = -A(q.right - (u ? I(L, 0, r) : L) - at + y, 0), this.containerBounds[2] = -A(q.bottom - (u ? I(R, 0, a) : R) - p + h, 0), this.containerBounds[3] = -A(q.left - (u ? I(_, 0, r) : _) + N - m, 0))
            }
            this.transforms.revert(), this.coords[2] = n, this.coords[3] = o, this.setX(e, !0), this.setY(i, !0)
        }
        isOutOfBounds(t, e, i) {
            if (!this.contained) return 0;
            let [n, o, r, a] = t, [l, c] = this.disabled, d = !l && e < a || !l && e > o, u = !c && i < n || !c && i > r;
            return d && !u ? 1 : !d && u ? 2 : d && u ? 3 : 0
        }
        refresh() {
            let t = this.parameters,
                e = t.x,
                i = t.y,
                n = ie(t.container, this),
                o = ie(t.containerPadding, this) || 0,
                r = Nt(o) ? o : [o, o, o, o],
                a = this.x,
                l = this.y,
                c = ie(t.cursor, this),
                d = {
                    onHover: "grab",
                    onGrab: "grabbing"
                };
            if (c) {
                let {
                    onHover: b,
                    onGrab: T
                } = c;
                b && (d.onHover = b), T && (d.onGrab = T)
            }
            let u = ie(t.dragThreshold, this),
                f = {
                    mouse: 3,
                    touch: 7
                };
            if (Lt(u)) f.mouse = u, f.touch = u;
            else if (u) {
                let {
                    mouse: b,
                    touch: T
                } = u;
                S(b) || (f.mouse = b), S(T) || (f.touch = T)
            }
            this.containerArray = Nt(n) ? n : null, this.$container = n && !this.containerArray ? Ht(n)[0] : O.body, this.useWin = this.$container === O.body, this.$scrollContainer = this.useWin ? ee : this.$container, this.isFinePointer = matchMedia("(pointer:fine)").matches, this.containerPadding = P(r, [0, 0, 0, 0]), this.containerFriction = I(P(ie(t.containerFriction, this), .8), 0, 1), this.releaseContainerFriction = I(P(ie(t.releaseContainerFriction, this), this.containerFriction), 0, 1), this.snapX = ie(wt(e) && !S(e.snap) ? e.snap : t.snap, this), this.snapY = ie(wt(i) && !S(i.snap) ? i.snap : t.snap, this), this.scrollSpeed = P(ie(t.scrollSpeed, this), 1.5), this.scrollThreshold = P(ie(t.scrollThreshold, this), 20), this.dragSpeed = P(ie(t.dragSpeed, this), 1), this.dragThreshold = this.isFinePointer ? f.mouse : f.touch, this.minVelocity = P(ie(t.minVelocity, this), 0), this.maxVelocity = P(ie(t.maxVelocity, this), 50), this.velocityMultiplier = P(ie(t.velocityMultiplier, this), 1), this.cursor = c === !1 ? !1 : d, this.updateBoundingValues();
            let [g, y, h, m] = this.containerBounds;
            this.setX(I(a, m, y), !0), this.setY(I(l, g, h), !0)
        }
        update() {
            if (this.updateScrollCoords(), this.canScroll) {
                let [T, _, x, L] = this.containerPadding, [R, H] = this.scrollView, J = this.dragArea[2], K = this.dragArea[3], z = this.scroll.x, D = this.scroll.y, M = this.$container.scrollWidth, q = this.$container.scrollHeight, N = this.useWin ? I(M, this.window[0], M) : M, F = this.useWin ? I(q, this.window[1], q) : q, at = R - N, p = H - F;
                this.dragged && at > 0 && (this.coords[0] -= at, this.scrollView[0] = N), this.dragged && p > 0 && (this.coords[1] -= p, this.scrollView[1] = F);
                let C = this.scrollSpeed * 10,
                    v = this.scrollThreshold,
                    [w, V] = this.coords,
                    [B, k, Y, dt] = this.scrollBounds,
                    X = A(I((V - B + T) / v, -1, 0) * C, 0),
                    et = A(I((w - k - _) / v, 0, 1) * C, 0),
                    ut = A(I((V - Y - x) / v, 0, 1) * C, 0),
                    it = A(I((w - dt + L) / v, -1, 0) * C, 0);
                if (X || ut || it || et) {
                    let [kt, Dt] = this.disabled, U = z, rt = D;
                    kt || (U = A(I(z + (it || et), 0, R - J), 0), this.coords[0] -= z - U), Dt || (rt = A(I(D + (X || ut), 0, H - K), 0), this.coords[1] -= D - rt), this.useWin ? this.$scrollContainer.scrollBy(-(z - U), -(D - rt)) : this.$scrollContainer.scrollTo(U, rt)
                }
            }
            let [t, e, i, n] = this.containerBounds, [o, r, a, l, c, d] = this.pointer;
            this.coords[0] += (o - c) * this.dragSpeed, this.coords[1] += (r - d) * this.dragSpeed, this.pointer[4] = o, this.pointer[5] = r;
            let [u, f] = this.coords, [g, y] = this.snapped, h = (1 - this.containerFriction) * this.dragSpeed;
            this.setX(u > e ? e + (u - e) * h : u < n ? n + (u - n) * h : u, !1), this.setY(f > i ? i + (f - i) * h : f < t ? t + (f - t) * h : f, !1), this.computeVelocity(o - c, r - d), this.angle = ss(r - l, o - a);
            let [m, b] = this.snapped;
            (m !== g && this.snapX || b !== y && this.snapY) && this.onSnap(this)
        }
        stop() {
            this.updateTicker.pause(), this.overshootTicker.pause();
            for (let t in this.animate.animations) this.animate.animations[t].pause();
            return me([this], null, "x"), me([this], null, "y"), me([this], null, "progressX"), me([this], null, "progressY"), me([this.scroll]), me([this.overshootCoords]), this
        }
        scrollInView(t, e = 0, i = re.inOutQuad) {
            this.updateScrollCoords();
            let n = this.destX,
                o = this.destY,
                r = this.scroll,
                a = this.scrollBounds,
                l = this.canScroll;
            if (!this.containerArray && this.isOutOfBounds(a, n, o)) {
                let [c, d, u, f] = a, g = A(I(o - c, -ve, 0), 0), y = A(I(n - d, 0, ve), 0), h = A(I(o - u, 0, ve), 0), m = A(I(n - f, -ve, 0), 0);
                new Qt(r, {
                    x: A(r.x + (m ? m - e : y ? y + e : 0), 0),
                    y: A(r.y + (g ? g - e : h ? h + e : 0), 0),
                    duration: S(t) ? 350 * E.timeScale : t,
                    ease: i,
                    onUpdate: () => {
                        this.canScroll = !1, this.$scrollContainer.scrollTo(r.x, r.y)
                    }
                }).init().then(() => {
                    this.canScroll = l
                })
            }
            return this
        }
        handleHover() {
            this.isFinePointer && this.cursor && !this.cursorStyles && (this.cursorStyles = ce(this.$trigger, {
                cursor: this.cursor.onHover
            }))
        }
        animateInView(t, e = 0, i = re.inOutQuad) {
            this.stop(), this.updateBoundingValues();
            let n = this.x,
                o = this.y,
                [r, a, l, c] = this.containerPadding,
                d = this.scroll.y - this.targetBounds[0] + r + e,
                u = this.scroll.x - this.targetBounds[1] - a - e,
                f = this.scroll.y - this.targetBounds[2] - l - e,
                g = this.scroll.x - this.targetBounds[3] + c + e,
                y = this.isOutOfBounds([d, u, f, g], n, o);
            if (y) {
                let [h, m] = this.disabled, b = I(We(n, this.snapX), g, u), T = I(We(o, this.snapY), d, f), _ = S(t) ? 350 * E.timeScale : t;
                !h && (y === 1 || y === 3) && this.animate[this.xProp](b, _, i), !m && (y === 2 || y === 3) && this.animate[this.yProp](T, _, i)
            }
            return this
        }
        handleDown(t) {
            let e = t.target;
            if (this.grabbed || e.type === "range") return;
            t.stopPropagation(), this.grabbed = !0, this.released = !1, this.stop(), this.updateBoundingValues();
            let i = t.changedTouches,
                n = i ? i[0].clientX : t.clientX,
                o = i ? i[0].clientY : t.clientY,
                {
                    x: r,
                    y: a
                } = this.transforms.normalizePoint(n, o),
                [l, c, d, u] = this.containerBounds,
                f = (1 - this.containerFriction) * this.dragSpeed,
                g = this.x,
                y = this.y;
            this.coords[0] = this.coords[2] = f ? g > c ? c + (g - c) / f : g < u ? u + (g - u) / f : g : g, this.coords[1] = this.coords[3] = f ? y > d ? d + (y - d) / f : y < l ? l + (y - l) / f : y : y, this.pointer[0] = r, this.pointer[1] = a, this.pointer[2] = r, this.pointer[3] = a, this.pointer[4] = r, this.pointer[5] = a, this.pointer[6] = r, this.pointer[7] = a, this.deltaX = 0, this.deltaY = 0, this.velocity = 0, this.velocityStack[0] = 0, this.velocityStack[1] = 0, this.velocityStack[2] = 0, this.velocityStackIndex = 0, this.angle = 0, this.targetStyles && (this.targetStyles.revert(), this.targetStyles = null);
            let h = pe(this.$target, "zIndex", !1);
            ai = (h > ai ? h : ai) + 1, this.targetStyles = ce(this.$target, {
                zIndex: ai
            }), this.triggerStyles && (this.triggerStyles.revert(), this.triggerStyles = null), this.cursorStyles && (this.cursorStyles.revert(), this.cursorStyles = null), this.isFinePointer && this.cursor && (this.bodyStyles = ce(O.body, {
                cursor: this.cursor.onGrab
            })), this.scrollInView(100, 0, re.out(3)), this.onGrab(this), O.addEventListener("touchmove", this), O.addEventListener("touchend", this), O.addEventListener("touchcancel", this), O.addEventListener("mousemove", this), O.addEventListener("mouseup", this), O.addEventListener("selectstart", this)
        }
        handleMove(t) {
            if (!this.grabbed) return;
            let e = t.changedTouches,
                i = e ? e[0].clientX : t.clientX,
                n = e ? e[0].clientY : t.clientY,
                {
                    x: o,
                    y: r
                } = this.transforms.normalizePoint(i, n),
                a = o - this.pointer[6],
                l = r - this.pointer[7],
                c = t.target,
                d = !1,
                u = !1,
                f = !1;
            for (; e && c && c !== this.$trigger;) {
                let g = pe(c, "overflow-y");
                if (g !== "hidden" && g !== "visible") {
                    let {
                        scrollTop: y,
                        scrollHeight: h,
                        clientHeight: m
                    } = c;
                    if (h > m) {
                        f = !0, d = y <= 3, u = y >= h - m - 3;
                        break
                    }
                }
                c = c.parentElement
            }
            f && (!d && !u || d && l < 0 || u && l > 0) ? (this.pointer[0] = o, this.pointer[1] = r, this.pointer[2] = o, this.pointer[3] = r, this.pointer[4] = o, this.pointer[5] = r, this.pointer[6] = o, this.pointer[7] = r) : (He(t), this.triggerStyles || (this.triggerStyles = ce(this.$trigger, {
                pointerEvents: "none"
            })), this.$trigger.addEventListener("touchstart", He, {
                passive: !1
            }), this.$trigger.addEventListener("touchmove", He, {
                passive: !1
            }), this.$trigger.addEventListener("touchend", He), (this.dragged || !this.disabled[0] && ne(a) > this.dragThreshold || !this.disabled[1] && ne(l) > this.dragThreshold) && (this.updateTicker.resume(), this.pointer[2] = this.pointer[0], this.pointer[3] = this.pointer[1], this.pointer[0] = o, this.pointer[1] = r, this.dragged = !0, this.released = !1, this.onDrag(this)))
        }
        handleUp() {
            if (!this.grabbed) return;
            this.updateTicker.pause(), this.triggerStyles && (this.triggerStyles.revert(), this.triggerStyles = null), this.bodyStyles && (this.bodyStyles.revert(), this.bodyStyles = null);
            let [t, e] = this.disabled, [i, n, o, r, a, l] = this.pointer, [c, d, u, f] = this.containerBounds, [g, y] = this.snapped, h = this.releaseXSpring, m = this.releaseYSpring, b = this.releaseEase, T = this.hasReleaseSpring, _ = this.overshootCoords, x = this.x, L = this.y, R = this.computeVelocity(i - a, n - l), H = this.angle = ss(n - r, i - o), J = R * 150, K = (1 - this.releaseContainerFriction) * this.dragSpeed, z = x + es(H) * J, D = L + ts(H) * J, M = z > d ? d + (z - d) * K : z < f ? f + (z - f) * K : z, q = D > u ? u + (D - u) * K : D < c ? c + (D - c) * K : D, N = this.destX = I(A(We(M, this.snapX), 5), f, d), F = this.destY = I(A(We(q, this.snapY), 5), c, u), at = this.isOutOfBounds(this.containerBounds, z, D), p = 0, C = 0, v = b, w = b, V = 0;
            if (_.x = x, _.y = L, !t) {
                let k = N === d ? x > d ? -1 : 1 : x < f ? -1 : 1,
                    Y = A(x - N, 0);
                h.velocity = e && T ? Y ? J * k / ne(Y) : 0 : R;
                let {
                    ease: dt,
                    settlingDuration: X,
                    restDuration: et
                } = h;
                p = x === N ? 0 : T ? X : X - et * E.timeScale, T && (v = dt), p > V && (V = p)
            }
            if (!e) {
                let k = F === u ? L > u ? -1 : 1 : L < c ? -1 : 1,
                    Y = A(L - F, 0);
                m.velocity = t && T ? Y ? J * k / ne(Y) : 0 : R;
                let {
                    ease: dt,
                    settlingDuration: X,
                    restDuration: et
                } = m;
                C = L === F ? 0 : T ? X : X - et * E.timeScale, T && (w = dt), C > V && (V = C)
            }
            if (!T && at && K && (p || C)) {
                let k = At.blend;
                new Qt(_, {
                    x: {
                        to: M,
                        duration: p * .65
                    },
                    y: {
                        to: q,
                        duration: C * .65
                    },
                    ease: b,
                    composition: k
                }).init(), new Qt(_, {
                    x: {
                        to: N,
                        duration: p
                    },
                    y: {
                        to: F,
                        duration: C
                    },
                    ease: b,
                    composition: k
                }).init(), this.overshootTicker.stretch(Ji(p, C)).restart()
            } else t || this.animate[this.xProp](N, p, v), e || this.animate[this.yProp](F, C, w);
            this.scrollInView(V, this.scrollThreshold, b);
            let B = !1;
            N !== g && (this.snapped[0] = N, this.snapX && (B = !0)), F !== y && this.snapY && (this.snapped[1] = F, this.snapY && (B = !0)), B && this.onSnap(this), this.grabbed = !1, this.dragged = !1, this.updated = !0, this.released = !0, this.onRelease(this), this.$trigger.removeEventListener("touchstart", He), this.$trigger.removeEventListener("touchmove", He), this.$trigger.removeEventListener("touchend", He), O.removeEventListener("touchmove", this), O.removeEventListener("touchend", this), O.removeEventListener("touchcancel", this), O.removeEventListener("mousemove", this), O.removeEventListener("mouseup", this), O.removeEventListener("selectstart", this)
        }
        reset() {
            return this.stop(), this.resizeTicker.pause(), this.grabbed = !1, this.dragged = !1, this.updated = !1, this.released = !1, this.canScroll = !1, this.setX(0, !0), this.setY(0, !0), this.coords[0] = 0, this.coords[1] = 0, this.pointer[0] = 0, this.pointer[1] = 0, this.pointer[2] = 0, this.pointer[3] = 0, this.pointer[4] = 0, this.pointer[5] = 0, this.pointer[6] = 0, this.pointer[7] = 0, this.velocity = 0, this.velocityStack[0] = 0, this.velocityStack[1] = 0, this.velocityStack[2] = 0, this.velocityStackIndex = 0, this.angle = 0, this
        }
        enable() {
            return this.enabled || (this.enabled = !0, this.$target.classList.remove("is-disabled"), this.touchActionStyles = ce(this.$trigger, {
                touchAction: this.disabled[0] ? "pan-x" : this.disabled[1] ? "pan-y" : "none"
            }), this.$trigger.addEventListener("touchstart", this, {
                passive: !0
            }), this.$trigger.addEventListener("mousedown", this, {
                passive: !0
            }), this.$trigger.addEventListener("mouseenter", this)), this
        }
        disable() {
            return this.enabled = !1, this.grabbed = !1, this.dragged = !1, this.updated = !1, this.released = !1, this.canScroll = !1, this.touchActionStyles.revert(), this.cursorStyles && (this.cursorStyles.revert(), this.cursorStyles = null), this.triggerStyles && (this.triggerStyles.revert(), this.triggerStyles = null), this.bodyStyles && (this.bodyStyles.revert(), this.bodyStyles = null), this.targetStyles && (this.targetStyles.revert(), this.targetStyles = null), this.$target.classList.add("is-disabled"), this.$trigger.removeEventListener("touchstart", this), this.$trigger.removeEventListener("mousedown", this), this.$trigger.removeEventListener("mouseenter", this), O.removeEventListener("touchmove", this), O.removeEventListener("touchend", this), O.removeEventListener("touchcancel", this), O.removeEventListener("mousemove", this), O.removeEventListener("mouseup", this), O.removeEventListener("selectstart", this), this
        }
        revert() {
            return this.reset(), this.disable(), this.$target.classList.remove("is-disabled"), this.updateTicker.revert(), this.overshootTicker.revert(), this.resizeTicker.revert(), this.animate.revert(), this.resizeObserver.disconnect(), this
        }
        handleEvent(t) {
            switch (t.type) {
                case "mousedown":
                    this.handleDown(t);
                    break;
                case "touchstart":
                    this.handleDown(t);
                    break;
                case "mousemove":
                    this.handleMove(t);
                    break;
                case "touchmove":
                    this.handleMove(t);
                    break;
                case "mouseup":
                    this.handleUp();
                    break;
                case "touchend":
                    this.handleUp();
                    break;
                case "touchcancel":
                    this.handleUp();
                    break;
                case "mouseenter":
                    this.handleHover();
                    break;
                case "selectstart":
                    He(t);
                    break
            }
        }
    },
    li = (s, t) => new Ps(s, t);
var cs = (s = Z) => new Ot({
        duration: 1 * E.timeScale,
        onComplete: s
    }, null, 0).resume(),
    Xe = s => {
        let t;
        return ((...e) => {
            let i, n, o, r, a;
            t && (i = t.currentIteration, n = t.iterationProgress, o = t.reversed, r = t._alternate, a = t._startTime, t.revert());
            let l = s(...e);
            return l && !lt(l) && l.revert && (t = l), S(n) || (t.currentIteration = i, t.iterationProgress = (r && i % 2 ? !o : o) ? 1 - n : n, t._startTime = a), l || Z
        })
    };
var Ls = class {
        constructor(t = {}) {
            yt.current && yt.current.register(this);
            let e = t.root,
                i = O;
            e && (i = e.current || e.nativeElement || Ht(e)[0] || O);
            let n = t.defaults,
                o = E.defaults,
                r = t.mediaQueries;
            if (this.defaults = n ? jt(n, o) : o, this.root = i, this.constructors = [], this.revertConstructors = [], this.revertibles = [], this.constructorsOnce = [], this.revertConstructorsOnce = [], this.revertiblesOnce = [], this.once = !1, this.onceIndex = 0, this.methods = {}, this.matches = {}, this.mediaQueryLists = {}, this.data = {}, r)
                for (let a in r) {
                    let l = ee.matchMedia(r[a]);
                    this.mediaQueryLists[a] = l, l.addEventListener("change", this)
                }
        }
        register(t) {
            (this.once ? this.revertiblesOnce : this.revertibles).push(t)
        }
        execute(t) {
            let e = yt.current,
                i = yt.root,
                n = E.defaults;
            yt.current = this, yt.root = this.root, E.defaults = this.defaults;
            let o = this.mediaQueryLists;
            for (let a in o) this.matches[a] = o[a].matches;
            let r = t(this);
            return yt.current = e, yt.root = i, E.defaults = n, r
        }
        refresh() {
            return this.onceIndex = 0, this.execute(() => {
                let t = this.revertibles.length,
                    e = this.revertConstructors.length;
                for (; t--;) this.revertibles[t].revert();
                for (; e--;) this.revertConstructors[e](this);
                this.revertibles.length = 0, this.revertConstructors.length = 0, this.constructors.forEach(i => {
                    let n = i(this);
                    lt(n) && this.revertConstructors.push(n)
                })
            }), this
        }
        add(t, e) {
            if (this.once = !1, lt(t)) {
                let i = t;
                this.constructors.push(i), this.execute(() => {
                    let n = i(this);
                    lt(n) && this.revertConstructors.push(n)
                })
            } else this.methods[t] = (...i) => this.execute(() => e(...i));
            return this
        }
        addOnce(t) {
            if (this.once = !0, lt(t)) {
                let e = this.onceIndex++;
                if (this.constructorsOnce[e]) return this;
                let n = t;
                this.constructorsOnce[e] = n, this.execute(() => {
                    let o = n(this);
                    lt(o) && this.revertConstructorsOnce.push(o)
                })
            }
            return this
        }
        keepTime(t) {
            this.once = !0;
            let e = this.onceIndex++,
                i = this.constructorsOnce[e];
            if (lt(i)) return i(this);
            let n = Xe(t);
            this.constructorsOnce[e] = n;
            let o;
            return this.execute(() => {
                o = n(this)
            }), o
        }
        handleEvent(t) {
            t.type === "change" && this.refresh()
        }
        revert() {
            let t = this.revertibles,
                e = this.revertConstructors,
                i = this.revertiblesOnce,
                n = this.revertConstructorsOnce,
                o = this.mediaQueryLists,
                r = t.length,
                a = e.length,
                l = i.length,
                c = n.length;
            for (; r--;) t[r].revert();
            for (; a--;) e[a](this);
            for (; l--;) i[l].revert();
            for (; c--;) n[c](this);
            for (let d in o) o[d].removeEventListener("change", this);
            t.length = 0, e.length = 0, this.constructors.length = 0, i.length = 0, n.length = 0, this.constructorsOnce.length = 0, this.onceIndex = 0, this.matches = {}, this.methods = {}, this.mediaQueryLists = {}, this.data = {}
        }
    },
    ci = s => new Ls(s);
var er = () => {
        let s = O.createElement("div");
        O.body.appendChild(s), s.style.height = "100lvh";
        let t = s.offsetHeight;
        return O.body.removeChild(s), t
    },
    hi = (s, t) => s && lt(s) ? s(t) : s,
    $s = new Map,
    mn = class {
        constructor(t) {
            this.element = t, this.useWin = this.element === O.body, this.winWidth = 0, this.winHeight = 0, this.width = 0, this.height = 0, this.left = 0, this.top = 0, this.scale = 1, this.zIndex = 0, this.scrollX = 0, this.scrollY = 0, this.prevScrollX = 0, this.prevScrollY = 0, this.scrollWidth = 0, this.scrollHeight = 0, this.velocity = 0, this.backwardX = !1, this.backwardY = !1, this.scrollTicker = new Ot({
                autoplay: !1,
                onBegin: () => this.dataTimer.resume(),
                onUpdate: () => {
                    let e = this.backwardX || this.backwardY;
                    ot(this, i => i.handleScroll(), e)
                },
                onComplete: () => this.dataTimer.pause()
            }).init(), this.dataTimer = new Ot({
                autoplay: !1,
                frameRate: 30,
                onUpdate: e => {
                    let i = e.deltaTime,
                        n = this.prevScrollX,
                        o = this.prevScrollY,
                        r = this.scrollX,
                        a = this.scrollY,
                        l = n - r,
                        c = o - a;
                    this.prevScrollX = r, this.prevScrollY = a, l && (this.backwardX = n > r), c && (this.backwardY = o > a), this.velocity = A(i > 0 ? Math.sqrt(l * l + c * c) / i : 0, 5)
                }
            }).init(), this.resizeTicker = new Ot({
                autoplay: !1,
                duration: 250 * E.timeScale,
                onComplete: () => {
                    this.updateWindowBounds(), this.refreshScrollObservers(), this.handleScroll()
                }
            }).init(), this.wakeTicker = new Ot({
                autoplay: !1,
                duration: 500 * E.timeScale,
                onBegin: () => {
                    this.scrollTicker.resume()
                },
                onComplete: () => {
                    this.scrollTicker.pause()
                }
            }).init(), this._head = null, this._tail = null, this.updateScrollCoords(), this.updateWindowBounds(), this.updateBounds(), this.refreshScrollObservers(), this.handleScroll(), this.resizeObserver = new ResizeObserver(() => this.resizeTicker.restart()), this.resizeObserver.observe(this.element), (this.useWin ? ee : this.element).addEventListener("scroll", this, !1)
        }
        updateScrollCoords() {
            let t = this.useWin,
                e = this.element;
            this.scrollX = A(t ? ee.scrollX : e.scrollLeft, 0), this.scrollY = A(t ? ee.scrollY : e.scrollTop, 0)
        }
        updateWindowBounds() {
            this.winWidth = ee.innerWidth, this.winHeight = er()
        }
        updateBounds() {
            let t = getComputedStyle(this.element),
                e = this.element;
            this.scrollWidth = e.scrollWidth + parseFloat(t.marginLeft) + parseFloat(t.marginRight), this.scrollHeight = e.scrollHeight + parseFloat(t.marginTop) + parseFloat(t.marginBottom), this.updateWindowBounds();
            let i, n;
            if (this.useWin) i = this.winWidth, n = this.winHeight;
            else {
                let o = e.getBoundingClientRect();
                i = e.clientWidth, n = e.clientHeight, this.top = o.top, this.left = o.left, this.scale = o.width ? i / o.width : o.height ? n / o.height : 1
            }
            this.width = i, this.height = n
        }
        refreshScrollObservers() {
            ot(this, t => {
                t.ready && t._debug && t.removeDebug()
            }), this.updateBounds(), ot(this, t => {
                t.ready && (t.refresh(), t.onResize(t), t._debug && t.debug())
            })
        }
        refresh() {
            this.updateWindowBounds(), this.updateBounds(), this.refreshScrollObservers(), this.handleScroll()
        }
        handleScroll() {
            this.updateScrollCoords(), this.wakeTicker.restart()
        }
        handleEvent(t) {
            t.type === "scroll" && this.handleScroll()
        }
        revert() {
            this.scrollTicker.cancel(), this.dataTimer.cancel(), this.resizeTicker.cancel(), this.wakeTicker.cancel(), this.resizeObserver.disconnect(), (this.useWin ? ee : this.element).removeEventListener("scroll", this), $s.delete(this.element)
        }
    },
    sr = s => {
        let t = s ? Ht(s)[0] || O.body : O.body,
            e = $s.get(t);
        return e || (e = new mn(t), $s.set(t, e)), e
    },
    Rs = (s, t, e, i, n) => {
        let o = t === "min",
            r = t === "max",
            a = t === "top" || t === "left" || t === "start" || o ? 0 : t === "bottom" || t === "right" || t === "end" || r ? "100%" : t === "center" ? "50%" : t,
            {
                n: l,
                u: c
            } = Yt(a, It),
            d = l;
        return c === "%" ? d = l / 100 * e : c && (d = qe(s, It, "px", !0).n), r && i < 0 && (d += i), o && n > 0 && (d += n), d
    },
    di = (s, t, e, i, n) => {
        let o;
        if (vt(t)) {
            let r = zs.exec(t);
            if (r) {
                let a = r[0],
                    l = a[0],
                    c = t.split(a),
                    d = c[0] === "min",
                    u = c[0] === "max",
                    f = Rs(s, c[0], e, i, n),
                    g = Rs(s, c[1], e, i, n);
                if (d) {
                    let y = Se(Rs(s, "min", e), g, l);
                    o = y < f ? f : y
                } else if (u) {
                    let y = Se(Rs(s, "max", e), g, l);
                    o = y > f ? f : y
                } else o = Se(f, g, l)
            } else o = Rs(s, t, e, i, n)
        } else o = t;
        return A(o, 0)
    },
    bo = s => {
        let t, e = s.targets;
        for (let i = 0, n = e.length; i < n; i++) {
            let o = e[i];
            if (o[de]) {
                t = o;
                break
            }
        }
        return t
    },
    ir = 0,
    To = ["#FF4B4B", "#FF971B", "#FFC730", "#F9F640", "#7AFF5A", "#18FF74", "#17E09B", "#3CFFEC", "#05DBE9", "#33B3F1", "#638CF9", "#C563FE", "#FF4FCF", "#F93F8A"],
    Ns = class {
        constructor(t = {}) {
            yt.current && yt.current.register(this);
            let e = P(t.sync, "play pause"),
                i = e ? Zt(e) : null,
                n = e && (e === "linear" || e === Wt),
                o = e && !(i === Wt && !n),
                r = e && (Lt(e) || e === !0 || n),
                a = e && vt(e) && !o && !r,
                l = a ? e.split(" ").map(d => () => {
                    let u = this.linked;
                    return u && u[d] ? u[d]() : null
                }) : null,
                c = a && l.length > 2;
            this.index = ir++, this.id = S(t.id) ? this.index : t.id, this.container = sr(t.container), this.target = null, this.linked = null, this.repeat = null, this.horizontal = null, this.enter = null, this.leave = null, this.sync = o || r || !!l, this.syncEase = o ? i : null, this.syncSmooth = r ? e === !0 || n ? 1 : e : null, this.onSyncEnter = l && !c && l[0] ? l[0] : Z, this.onSyncLeave = l && !c && l[1] ? l[1] : Z, this.onSyncEnterForward = l && c && l[0] ? l[0] : Z, this.onSyncLeaveForward = l && c && l[1] ? l[1] : Z, this.onSyncEnterBackward = l && c && l[2] ? l[2] : Z, this.onSyncLeaveBackward = l && c && l[3] ? l[3] : Z, this.onEnter = t.onEnter || Z, this.onLeave = t.onLeave || Z, this.onEnterForward = t.onEnterForward || Z, this.onLeaveForward = t.onLeaveForward || Z, this.onEnterBackward = t.onEnterBackward || Z, this.onLeaveBackward = t.onLeaveBackward || Z, this.onUpdate = t.onUpdate || Z, this.onResize = t.onResize || Z, this.onSyncComplete = t.onSyncComplete || Z, this.reverted = !1, this.ready = !1, this.completed = !1, this.began = !1, this.isInView = !1, this.forceEnter = !1, this.hasEntered = !1, this.offset = 0, this.offsetStart = 0, this.offsetEnd = 0, this.distance = 0, this.prevProgress = 0, this.thresholds = ["start", "end", "end", "start"], this.coords = [0, 0, 0, 0], this.debugStyles = null, this.$debug = null, this._params = t, this._debug = P(t.debug, !1), this._next = null, this._prev = null, zt(this.container, this), cs(() => {
                if (!this.reverted) {
                    if (!this.target) {
                        let d = Ht(t.target)[0];
                        this.target = d || O.body, this.refresh()
                    }
                    this._debug && this.debug()
                }
            })
        }
        link(t) {
            if (t && (t.pause(), this.linked = t, !S(t) && !S(t.persist) && (t.persist = !0), !this._params.target)) {
                let e;
                S(t.targets) ? ot(t, i => {
                    i.targets && !e && (e = bo(i))
                }) : e = bo(t), this.target = e || O.body, this.refresh()
            }
            return this
        }
        get velocity() {
            return this.container.velocity
        }
        get backward() {
            return this.horizontal ? this.container.backwardX : this.container.backwardY
        }
        get scroll() {
            return this.horizontal ? this.container.scrollX : this.container.scrollY
        }
        get progress() {
            let t = (this.scroll - this.offsetStart) / this.distance;
            return t === 1 / 0 || isNaN(t) ? 0 : A(I(t, 0, 1), 6)
        }
        refresh() {
            this.ready = !0, this.reverted = !1;
            let t = this._params;
            return this.repeat = P(hi(t.repeat, this), !0), this.horizontal = P(hi(t.axis, this), "y") === "x", this.enter = P(hi(t.enter, this), "end start"), this.leave = P(hi(t.leave, this), "start end"), this.updateBounds(), this.handleScroll(), this
        }
        removeDebug() {
            return this.$debug && (this.$debug.parentNode.removeChild(this.$debug), this.$debug = null), this.debugStyles && (this.debugStyles.revert(), this.$debug = null), this
        }
        debug() {
            this.removeDebug();
            let t = this.container,
                e = this.horizontal,
                i = t.element.querySelector(":scope > .animejs-onscroll-debug"),
                n = O.createElement("div"),
                o = O.createElement("div"),
                r = O.createElement("div"),
                a = To[this.index % To.length],
                l = t.useWin,
                c = l ? t.winWidth : t.width,
                d = l ? t.winHeight : t.height,
                u = t.scrollWidth,
                f = t.scrollHeight,
                g = this.container.width > 360 ? 320 : 260,
                y = e ? 0 : 10,
                h = e ? 10 : 0,
                m = e ? 24 : g / 2,
                b = e ? m : 15,
                T = e ? 60 : m,
                _ = e ? T : b,
                x = e ? "repeat-x" : "repeat-y",
                L = z => e ? "0px " + z + "px" : z + "px 2px",
                R = z => `linear-gradient(${e?90:0}deg, ${z} 2px, transparent 1px)`,
                H = (z, D, M, q, N) => `position:${z};left:${D}px;top:${M}px;width:${q}px;height:${N}px;`;
            n.style.cssText = `${H("absolute",y,h,e?u:g,e?g:f)}
      pointer-events: none;
      z-index: ${this.container.zIndex++};
      display: flex;
      flex-direction: ${e?"column":"row"};
      filter: drop-shadow(0px 1px 0px rgba(0,0,0,.75));
    `, o.style.cssText = `${H("sticky",0,0,e?c:m,e?m:d)}`, i || (o.style.cssText += `background:
        ${R("#FFFF")}${L(m-10)} / 100px 100px ${x},
        ${R("#FFF8")}${L(m-10)} / 10px 10px ${x};
      `), r.style.cssText = `${H("relative",0,0,e?u:m,e?m:f)}`, i || (r.style.cssText += `background:
        ${R("#FFFF")}${L(0)} / ${e?"100px 10px":"10px 100px"} ${x},
        ${R("#FFF8")}${L(0)} / ${e?"10px 0px":"0px 10px"} ${x};
      `);
            let J = [" enter: ", " leave: "];
            this.coords.forEach((z, D) => {
                let M = D > 1,
                    q = (M ? 0 : this.offset) + z,
                    N = D % 2,
                    F = q < _,
                    at = q > (M ? e ? c : d : e ? u : f) - _,
                    p = (M ? N && !F : !N && !F) || at,
                    C = O.createElement("div"),
                    v = O.createElement("div"),
                    w = e ? p ? "right" : "left" : p ? "bottom" : "top",
                    V = p ? (e ? T : b) + (M ? e ? -1 : at ? 0 : -2 : e ? -1 : -2) : e ? 1 : 0;
                v.innerHTML = `${this.id}${J[N]}${this.thresholds[D]}`, C.style.cssText = `${H("absolute",0,0,T,b)}
        display: flex;
        flex-direction: ${e?"column":"row"};
        justify-content: flex-${M?"start":"end"};
        align-items: flex-${p?"end":"start"};
        border-${w}: 2px solid ${a};
      `, v.style.cssText = `
        overflow: hidden;
        max-width: ${g/2-10}px;
        height: ${b};
        margin-${e?p?"right":"left":p?"bottom":"top"}: -2px;
        padding: 1px;
        font-family: ui-monospace, monospace;
        font-size: 10px;
        letter-spacing: -.025em;
        line-height: 9px;
        font-weight: 600;
        text-align: ${e&&p||!e&&!M?"right":"left"};
        white-space: pre;
        text-overflow: ellipsis;
        color: ${N?a:"rgba(0,0,0,.75)"};
        background-color: ${N?"rgba(0,0,0,.65)":a};
        border: 2px solid ${N?a:"transparent"};
        border-${e?p?"top-left":"top-right":p?"top-left":"bottom-left"}-radius: 5px;
        border-${e?p?"bottom-left":"bottom-right":p?"top-right":"bottom-right"}-radius: 5px;
      `, C.appendChild(v);
                let B = q - V + (e ? 1 : 0);
                C.style[e ? "left" : "top"] = `${B}px`, (M ? o : r).appendChild(C)
            }), n.appendChild(o), n.appendChild(r), t.element.appendChild(n), i || n.classList.add("animejs-onscroll-debug"), this.$debug = n, pe(t.element, "position") === "static" && (this.debugStyles = ce(t.element, {
                position: "relative "
            }))
        }
        updateBounds() {
            this._debug && this.removeDebug();
            let t, e = this.target,
                i = this.container,
                n = this.horizontal,
                o = this.linked,
                r, a = e;
            for (o && (r = o.currentTime, o.seek(0, !0)); a && a !== i.element && a !== O.body;) {
                let N = pe(a, "position") === "sticky" ? ce(a, {
                    position: "static"
                }) : !1;
                a = a.parentElement, N && (t || (t = []), t.push(N))
            }
            let l = e.getBoundingClientRect(),
                c = i.scale,
                d = (n ? l.left + i.scrollX - i.left : l.top + i.scrollY - i.top) * c,
                u = (n ? l.width : l.height) * c,
                f = n ? i.width : i.height,
                y = (n ? i.scrollWidth : i.scrollHeight) - f,
                h = this.enter,
                m = this.leave,
                b = "start",
                T = "end",
                _ = "end",
                x = "start";
            if (vt(h)) {
                let N = h.split(" ");
                _ = N[0], b = N.length > 1 ? N[1] : b
            } else if (wt(h)) {
                let N = h;
                S(N.container) || (_ = N.container), S(N.target) || (b = N.target)
            } else Lt(h) && (_ = h);
            if (vt(m)) {
                let N = m.split(" ");
                x = N[0], T = N.length > 1 ? N[1] : T
            } else if (wt(m)) {
                let N = m;
                S(N.container) || (x = N.container), S(N.target) || (T = N.target)
            } else Lt(m) && (x = m);
            let L = di(e, b, u),
                R = di(e, T, u),
                H = L + d - f,
                J = R + d - y,
                K = di(e, _, f, H, J),
                z = di(e, x, f, H, J),
                D = L + d - K,
                M = R + d - z,
                q = M - D;
            this.offset = d, this.offsetStart = D, this.offsetEnd = M, this.distance = q <= 0 ? 0 : q, this.thresholds = [b, T, _, x], this.coords = [L, R, K, z], t && t.forEach(N => N.revert()), o && o.seek(r, !0), this._debug && this.debug()
        }
        handleScroll() {
            if (!this.ready) return;
            let t = this.linked,
                e = this.sync,
                i = this.syncEase,
                n = this.syncSmooth,
                o = t && (i || n),
                r = this.horizontal,
                a = this.container,
                l = this.scroll,
                c = l <= this.offsetStart,
                d = l >= this.offsetEnd,
                u = !c && !d,
                f = l === this.offsetStart || l === this.offsetEnd,
                g = !this.hasEntered && f,
                y = this._debug && this.$debug,
                h = !1,
                m = !1,
                b = this.progress;
            if (c && this.began && (this.began = !1), b > 0 && !this.began && (this.began = !0), o) {
                let T = t.progress;
                if (n && Lt(n)) {
                    if (n < 1) {
                        let x = T < b && b === 1 ? 1e-4 : T > b && !b ? -1e-4 : 0;
                        b = A($e(T, b, $e(.01, .2, n)) + x, 6)
                    }
                } else i && (b = i(b));
                h = b !== this.prevProgress, m = T === 1, h && !m && n && T && a.wakeTicker.restart()
            }
            if (y) {
                let T = r ? a.scrollY : a.scrollX;
                y.style[r ? "top" : "left"] = T + 10 + "px"
            }(u && !this.isInView || g && !this.forceEnter && !this.hasEntered) && (u && (this.isInView = !0), !this.forceEnter || !this.hasEntered ? (y && u && (y.style.zIndex = `${this.container.zIndex++}`), this.onSyncEnter(this), this.onEnter(this), this.backward ? (this.onSyncEnterBackward(this), this.onEnterBackward(this)) : (this.onSyncEnterForward(this), this.onEnterForward(this)), this.hasEntered = !0, g && (this.forceEnter = !0)) : u && (this.forceEnter = !1)), (u || !u && this.isInView) && (h = !0), h && (o && t.seek(t.duration * b), this.onUpdate(this)), !u && this.isInView && (this.isInView = !1, this.onSyncLeave(this), this.onLeave(this), this.backward ? (this.onSyncLeaveBackward(this), this.onLeaveBackward(this)) : (this.onSyncLeaveForward(this), this.onLeaveForward(this)), e && !n && (m = !0)), b >= 1 && this.began && !this.completed && (e && m || !e) && (e && this.onSyncComplete(this), this.completed = !0, (!this.repeat && !t || !this.repeat && t && t.completed) && this.revert()), b < 1 && this.completed && (this.completed = !1), this.prevProgress = b
        }
        revert() {
            if (this.reverted) return;
            let t = this.container;
            return Gt(t, this), t._head || t.revert(), this._debug && this.removeDebug(), this.reverted = !0, this.ready = !1, this
        }
    },
    xo = (s = {}) => new Ns(s);
var pn = {};
ys(pn, {
    Spring: () => Me,
    createSpring: () => ni,
    cubicBezier: () => ui,
    eases: () => re,
    irregular: () => mi,
    linear: () => hs,
    spring: () => Ze,
    steps: () => fi
});
var So = (s, t, e) => (((1 - 3 * e + 3 * t) * s + (3 * e - 6 * t)) * s + 3 * t) * s,
    nr = (s, t, e) => {
        let i = 0,
            n = 1,
            o, r, a = 0;
        do r = i + (n - i) / 2, o = So(r, t, e) - s, o > 0 ? n = r : i = r; while (ne(o) > 1e-7 && ++a < 100);
        return r
    },
    ui = (s = .5, t = 0, e = .5, i = 1) => s === t && e === i ? Wt : n => n === 0 || n === 1 ? n : So(nr(n, s, e), t, i);
var fi = (s = 10, t) => {
    let e = t ? Kn : Re;
    return i => e(I(i, 0, 1) * s) * (1 / s)
};
var hs = (...s) => {
    let t = s.length;
    if (!t) return Wt;
    let e = t - 1,
        i = s[0],
        n = s[e],
        o = [0],
        r = [Pe(i)];
    for (let a = 1; a < e; a++) {
        let l = s[a],
            c = vt(l) ? l.trim().split(" ") : [l],
            d = c[0],
            u = c[1];
        o.push(S(u) ? a / e : Pe(u) / 100), r.push(Pe(d))
    }
    return r.push(Pe(n)), o.push(1),
        function(l) {
            for (let c = 1, d = o.length; c < d; c++) {
                let u = o[c];
                if (l <= u) {
                    let f = o[c - 1],
                        g = r[c - 1];
                    return g + (r[c] - g) * (l - f) / (u - f)
                }
            }
            return r[r.length - 1]
        }
};
var mi = (s = 10, t = 1) => {
    let e = [0],
        i = s - 1;
    for (let n = 1; n < i; n++) {
        let o = e[n - 1],
            r = n / i,
            a = (n + 1) / i,
            l = r + (a - r) * Math.random(),
            c = r * (1 - t) + l * t;
        e.push(I(c, o, 1))
    }
    return e.push(1), hs(...e)
};
var pi = (s, t = 100) => {
        let e = [];
        for (let i = 0; i <= t; i++) e.push(A(s(i / t), 4));
        return `linear(${e.join(", ")})`
    },
    _o = {},
    wo = s => {
        let t = _o[s];
        if (t) return t;
        if (t = "linear", vt(s)) {
            if (Pt(s, "linear") || Pt(s, "cubic-") || Pt(s, "steps") || Pt(s, "ease")) t = s;
            else if (Pt(s, "cubicB")) t = Je(s);
            else {
                let e = ln(s);
                lt(e) && (t = e === Wt ? "linear" : pi(e))
            }
            _o[s] = t
        } else if (lt(s)) {
            let e = pi(s);
            e && (t = e)
        } else s.ease && (t = pi(s.ease));
        return t
    },
    Eo = ["x", "y", "z"],
    or = ["perspective", "width", "height", "margin", "padding", "top", "right", "bottom", "left", "borderWidth", "fontSize", "borderRadius", ...Eo],
    rr = [...Eo, ...Ee.filter(s => ["X", "Y", "Z"].some(t => s.endsWith(t)))],
    gn = null,
    ks = (s, t, e, i, n) => {
        let o = vt(t) ? t : Rt(t, e, i, n, null, null);
        return Lt(o) ? or.includes(s) || Pt(s, "translate") ? `${o}px` : Pt(s, "rotate") || Pt(s, "skew") ? `${o}deg` : `${o}` : o
    },
    Co = (s, t, e, i, n, o) => {
        let r = "0",
            a = S(i) ? getComputedStyle(s)[t] : ks(t, i, s, n, o);
        return S(e) ? r = Nt(i) ? i.map(l => ks(t, l, s, n, o)) : a : r = [ks(t, e, s, n, o), a], r
    },
    Ds = class {
        constructor(t, e) {
            yt.current && yt.current.register(this), fe(gn) && (be && (S(CSS) || !Object.hasOwnProperty.call(CSS, "registerProperty")) ? gn = !1 : (Ee.forEach(g => {
                let y = Pt(g, "skew"),
                    h = Pt(g, "scale"),
                    m = Pt(g, "rotate"),
                    b = Pt(g, "translate"),
                    T = m || y,
                    _ = T ? "<angle>" : h ? "<number>" : b ? "<length-percentage>" : "*";
                try {
                    CSS.registerProperty({
                        name: "--" + g,
                        syntax: _,
                        inherits: !1,
                        initialValue: b ? "0px" : T ? "0deg" : h ? "1" : "0"
                    })
                } catch {}
            }), gn = !0));
            let i = se(t);
            i.length || console.warn("No target found. Make sure the element you're trying to animate is accessible before creating your animation.");
            let n = P(e.autoplay, E.defaults.autoplay),
                o = n && n.link ? n : !1,
                r = e.alternate && e.alternate === !0,
                a = e.reversed && e.reversed === !0,
                l = P(e.loop, E.defaults.loop),
                c = l === !0 || l === 1 / 0 ? 1 / 0 : Lt(l) ? l + 1 : 1,
                d = r ? a ? "alternate-reverse" : "alternate" : a ? "reverse" : "normal",
                u = "both",
                f = E.timeScale === 1 ? 1 : Vt;
            this.targets = i, this.animations = [], this.controlAnimation = null, this.onComplete = e.onComplete || E.defaults.onComplete, this.duration = 0, this.muteCallbacks = !1, this.completed = !1, this.paused = !n || o !== !1, this.reversed = a, this.persist = P(e.persist, E.defaults.persist), this.autoplay = n, this._speed = P(e.playbackRate, E.defaults.playbackRate), this._resolve = Z, this._completed = 0, this._inlineStyles = [], i.forEach((g, y) => {
                let h = g[Te],
                    m = rr.some(D => e.hasOwnProperty(D)),
                    b = g.style,
                    T = this._inlineStyles[y] = {},
                    _ = P(e.ease, E.defaults.ease),
                    x = Rt(_, g, y, i, null, null),
                    L = lt(x) || vt(x) ? x : _,
                    R = _.ease && _,
                    H = wo(L),
                    J = (R ? R.settlingDuration : Rt(P(e.duration, E.defaults.duration), g, y, i, null, null)) * f,
                    K = Rt(P(e.delay, E.defaults.delay), g, y, i, null, null) * f,
                    z = P(e.composition, "replace");
                for (let D in e) {
                    if (!Ae(D)) continue;
                    let M = {},
                        q = {
                            iterations: c,
                            direction: d,
                            fill: u,
                            easing: H,
                            duration: J,
                            delay: K,
                            composite: z
                        },
                        N = e[D],
                        F = m ? Ee.includes(D) ? D : Qe.get(D) : !1,
                        at = F ? "transform" : D;
                    T[at] || (T[at] = b[at]);
                    let p;
                    if (wt(N)) {
                        let C = N,
                            v = P(C.ease, H),
                            w = v.ease && v,
                            V = C.to,
                            B = C.from;
                        if (q.duration = (w ? w.settlingDuration : Rt(P(C.duration, J), g, y, i, null, null)) * f, q.delay = Rt(P(C.delay, K), g, y, i, null, null) * f, q.composite = P(C.composition, z), q.easing = wo(v), p = Co(g, D, B, V, y, i), F ? (M[`--${F}`] = p, h[F] = p) : M[D] = Co(g, D, B, V, y, i), dn(this, g, D, M, q), !S(B))
                            if (!F) b[D] = M[D][0];
                            else {
                                let k = `--${F}`;
                                b.setProperty(k, M[k][0])
                            }
                    } else p = Nt(N) ? N.map(C => ks(D, C, g, y, i)) : ks(D, N, g, y, i), F ? (M[`--${F}`] = p, h[F] = p) : M[D] = p, dn(this, g, D, M, q)
                }
                if (m) {
                    let D = Kt;
                    for (let M in h) D += `${Xs[M]}var(--${M})) `;
                    b.transform = D
                }
            }), o && this.autoplay.link(this)
        }
        forEach(t) {
            try {
                let e = vt(t) ? i => i[t]() : t;
                this.animations.forEach(e)
            } catch {}
            return this
        }
        get speed() {
            return this._speed
        }
        set speed(t) {
            this._speed = +t, this.forEach(e => e.playbackRate = t)
        }
        get currentTime() {
            let t = this.controlAnimation,
                e = E.timeScale;
            return this.completed ? this.duration : t ? +t.currentTime * (e === 1 ? 1 : e) : 0
        }
        set currentTime(t) {
            let e = t * (E.timeScale === 1 ? 1 : Vt);
            this.forEach(i => {
                !this.persist && e >= this.duration && i.play(), i.currentTime = e
            })
        }
        get progress() {
            return this.currentTime / this.duration
        }
        set progress(t) {
            this.forEach(e => e.currentTime = t * this.duration || 0)
        }
        resume() {
            return this.paused ? (this.paused = !1, this.forEach("play")) : this
        }
        pause() {
            return this.paused ? this : (this.paused = !0, this.forEach("pause"))
        }
        alternate() {
            return this.reversed = !this.reversed, this.forEach("reverse"), this.paused && this.forEach("pause"), this
        }
        play() {
            return this.reversed && this.alternate(), this.resume()
        }
        reverse() {
            return this.reversed || this.alternate(), this.resume()
        }
        seek(t, e = !1) {
            return e && (this.muteCallbacks = !0), t < this.duration && (this.completed = !1), this.currentTime = t, this.muteCallbacks = !1, this.paused && this.pause(), this
        }
        restart() {
            return this.completed = !1, this.seek(0, !0).resume()
        }
        commitStyles() {
            return this.forEach("commitStyles")
        }
        complete() {
            return this.seek(this.duration)
        }
        cancel() {
            return this.muteCallbacks = !0, this.commitStyles().forEach("cancel"), this.animations.length = 0, requestAnimationFrame(() => {
                this.targets.forEach(t => {
                    t.style.transform === "none" && t.style.removeProperty("transform")
                })
            }), this
        }
        revert() {
            return this.cancel().targets.forEach((t, e) => {
                let i = t.style,
                    n = this._inlineStyles[e];
                for (let o in n) {
                    let r = n[o];
                    S(r) || r === Kt ? i.removeProperty(Je(o)) : t.style[o] = r
                }
                t.getAttribute("style") === Kt && t.removeAttribute("style")
            }), this
        }
        then(t = Z) {
            let e = this.then,
                i = () => {
                    this.then = null, t(this), this.then = e, this._resolve = Z
                };
            return new Promise(n => (this._resolve = () => n(i()), this.completed && this._resolve(), this))
        }
    },
    gi = {
        animate: (s, t) => new Ds(s, t),
        convertEase: pi
    };
var ar = 0,
    lr = 0,
    vi = (s, t) => !s || !t ? !1 : s === t || s.contains(t),
    us = s => {
        if (!s) return null;
        let t = s.style,
            e = t.transition || "";
        return t.setProperty("transition", "none", "important"), e
    },
    bi = (s, t) => {
        if (!s) return;
        let e = s.style;
        t ? e.transition = t : e.removeProperty("transition")
    },
    cr = s => {
        let t = s.layout.transitionMuteStore,
            e = s.$el,
            i = s.$measure;
        e && !t.has(e) && t.set(e, us(e)), i && !t.has(i) && t.set(i, us(i))
    },
    yi = s => {
        s.forEach((t, e) => bi(e, t)), s.clear()
    },
    hr = {
        display: "none",
        visibility: "hidden",
        opacity: "0",
        transform: "none",
        position: "static"
    },
    dr = s => {
        if (!s) return;
        let t = s.parentNode;
        t && (t._head === s && (t._head = s._next), t._tail === s && (t._tail = s._prev), s._prev && (s._prev._next = s._next), s._next && (s._next._prev = s._prev), s._prev = null, s._next = null, s.parentNode = null)
    },
    Ao = (s, t, e, i) => {
        let n = s.dataset.layoutId;
        n || (n = s.dataset.layoutId = `node-${lr++}`);
        let o = i || {};
        return o.$el = s, o.$measure = s, o.id = n, o.index = 0, o.targets = null, o.delay = 0, o.duration = 0, o.ease = null, o.state = e, o.layout = e.layout, o.parentNode = t || null, o.isTarget = !1, o.isEntering = !1, o.isLeaving = !1, o.isInlined = !1, o.hasTransform = !1, o.inlineStyles = [], o.inlineTransforms = null, o.inlineTransition = null, o.branchAdded = !1, o.branchRemoved = !1, o.branchNotRendered = !1, o.sizeChanged = !1, o.hasVisibilitySwap = !1, o.hasDisplayNone = !1, o.hasVisibilityHidden = !1, o.measuredInlineTransform = null, o.measuredInlineTransition = null, o.measuredDisplay = null, o.measuredVisibility = null, o.measuredPosition = null, o.measuredHasDisplayNone = !1, o.measuredHasVisibilityHidden = !1, o.measuredIsVisible = !1, o.measuredIsRemoved = !1, o.measuredIsInsideRoot = !1, o.properties = {
            transform: "none",
            x: 0,
            y: 0,
            left: 0,
            top: 0,
            clientLeft: 0,
            clientTop: 0,
            width: 0,
            height: 0
        }, o.layout.properties.forEach(r => o.properties[r] = 0), o._head = null, o._tail = null, o._prev = null, o._next = null, o
    },
    Po = (s, t, e, i) => {
        let n = s.$el,
            o = s.layout.root,
            r = o === n,
            a = s.properties,
            l = s.state.rootNode,
            c = s.parentNode,
            d = e.transform,
            u = n.style.transform,
            f = c ? c.measuredIsRemoved : !1,
            g = e.position;
        r && (s.layout.absoluteCoords = g === "fixed" || g === "absolute"), s.$measure = t, s.inlineTransforms = u, s.hasTransform = d && d !== "none", s.measuredIsInsideRoot = vi(o, t), s.measuredInlineTransform = null, s.measuredDisplay = e.display, s.measuredVisibility = e.visibility, s.measuredPosition = g, s.measuredHasDisplayNone = e.display === "none", s.measuredHasVisibilityHidden = e.visibility === "hidden", s.measuredIsVisible = !(s.measuredHasDisplayNone || s.measuredHasVisibilityHidden), s.measuredIsRemoved = s.measuredHasDisplayNone || s.measuredHasVisibilityHidden || f;
        let y = !1,
            h = n.previousSibling;
        for (; h && (h.nodeType === Node.COMMENT_NODE || h.nodeType === Node.TEXT_NODE && !h.textContent.trim());) h = h.previousSibling;
        if (h && h.nodeType === Node.TEXT_NODE) y = !0;
        else {
            for (h = n.nextSibling; h && (h.nodeType === Node.COMMENT_NODE || h.nodeType === Node.TEXT_NODE && !h.textContent.trim());) h = h.nextSibling;
            y = h !== null && h.nodeType === Node.TEXT_NODE
        }
        if (s.isInlined = y, s.hasTransform && !i) {
            let R = s.layout.transitionMuteStore;
            R.get(n) || (s.inlineTransition = us(n)), t === n ? n.style.transform = "none" : (R.get(t) || (s.measuredInlineTransition = us(t)), s.measuredInlineTransform = t.style.transform, t.style.transform = "none")
        }
        let m = 0,
            b = 0,
            T = 0,
            _ = 0;
        if (!i) {
            let R = t.getBoundingClientRect();
            m = R.left, b = R.top, T = R.width, _ = R.height
        }
        for (let R in a) {
            let H = R === "transform" ? d : e[R] || e.getPropertyValue && e.getPropertyValue(R);
            S(H) || (a[R] = H)
        }
        a.left = m, a.top = b, a.clientLeft = i ? 0 : t.clientLeft, a.clientTop = i ? 0 : t.clientTop;
        let x, L;
        if (r) s.layout.absoluteCoords ? (x = m, L = b) : (x = 0, L = 0);
        else {
            let R = c || l,
                H = R.properties.left,
                J = R.properties.top,
                K = R.properties.clientLeft,
                z = R.properties.clientTop;
            if (s.layout.absoluteCoords) x = m - H - K, L = b - J - z;
            else if (R === l) {
                let D = l.properties.left,
                    M = l.properties.top,
                    q = l.properties.clientLeft,
                    N = l.properties.clientTop;
                x = m - D - q, L = b - M - N
            } else x = m - H - K, L = b - J - z
        }
        return a.x = x, a.y = L, a.width = T, a.height = _, s
    },
    Lo = (s, t) => {
        if (t)
            for (let e in t) s.properties[e] = t[e]
    },
    Is = (s, t) => {
        let e = Rt(t.ease, s.$el, s.index, s.targets, null, null),
            i = lt(e) ? e : t.ease,
            n = !S(i) && !S(i.ease);
        s.ease = n ? i.ease : i, s.duration = n ? i.settlingDuration : Rt(t.duration, s.$el, s.index, s.targets, null, null), s.delay = Rt(t.delay, s.$el, s.index, s.targets, null, null)
    },
    ur = s => {
        let t = s.$el.style,
            e = s.inlineStyles;
        e.length = 0, s.layout.recordedProperties.forEach(i => {
            e.push(i, t[i] || "")
        })
    },
    Ro = s => {
        let t = s.$el.style,
            e = s.inlineStyles;
        for (let i = 0, n = e.length; i < n; i += 2) {
            let o = e[i],
                r = e[i + 1];
            r && r !== "" ? t[o] = r : (t[o] = "", t.removeProperty(o))
        }
    },
    fr = s => {
        let t = s.inlineTransforms,
            e = s.$el.style;
        !s.hasTransform || !t || s.hasTransform && e.transform === "none" || t && t === "none" ? e.removeProperty("transform") : t && (e.transform = t);
        let i = s.$measure;
        if (s.hasTransform && i !== s.$el) {
            let n = i.style,
                o = s.measuredInlineTransform;
            o && o !== "" ? n.transform = o : n.removeProperty("transform")
        }
        s.measuredInlineTransform = null, s.inlineTransition !== null && (bi(s.$el, s.inlineTransition), s.inlineTransition = null), i !== s.$el && s.measuredInlineTransition !== null && (bi(i, s.measuredInlineTransition), s.measuredInlineTransition = null)
    },
    $o = s => {
        (s.measuredIsRemoved || s.hasVisibilitySwap) && (s.$el.style.removeProperty("display"), s.$el.style.removeProperty("visibility"), s.hasVisibilitySwap && (s.$measure.style.removeProperty("display"), s.$measure.style.removeProperty("visibility"))), s.layout.pendingRemoval.delete(s.$el)
    },
    yn = (s, t, e) => (t.properties = { ...s.properties
    }, t.state = e, t.isTarget = s.isTarget, t.hasTransform = s.hasTransform, t.inlineTransforms = s.inlineTransforms, t.measuredIsVisible = s.measuredIsVisible, t.measuredDisplay = s.measuredDisplay, t.measuredIsRemoved = s.measuredIsRemoved, t.measuredHasDisplayNone = s.measuredHasDisplayNone, t.measuredHasVisibilityHidden = s.measuredHasVisibilityHidden, t.hasDisplayNone = s.hasDisplayNone, t.isInlined = s.isInlined, t.hasVisibilityHidden = s.hasVisibilityHidden, t),
    Ti = class {
        constructor(t) {
            this.layout = t, this.rootNode = null, this.rootNodes = new Set, this.nodes = new Map, this.scrollX = 0, this.scrollY = 0
        }
        revert() {
            return this.forEachNode(t => {
                this.layout.pendingRemoval.delete(t.$el), t.$el.removeAttribute("data-layout-id"), t.$measure.removeAttribute("data-layout-id")
            }), this.rootNode = null, this.rootNodes.clear(), this.nodes.clear(), this
        }
        getNode(t) {
            if (!(!t || !t.dataset)) return this.nodes.get(t.dataset.layoutId)
        }
        getComputedValue(t, e) {
            let i = this.getNode(t);
            if (i) return i.properties[e]
        }
        forEach(t, e) {
            let i = t,
                n = 0;
            for (; i;)
                if (e(i, n++), i._head) i = i._head;
                else if (i._next) i = i._next;
            else {
                for (; i && !i._next;) i = i.parentNode;
                i && (i = i._next)
            }
        }
        forEachRootNode(t) {
            this.forEach(this.rootNode, t)
        }
        forEachNode(t) {
            for (let e of this.rootNodes) this.forEach(e, t)
        }
        registerElement(t, e) {
            if (!t || t.nodeType !== 1) return null;
            this.layout.transitionMuteStore.has(t) || this.layout.transitionMuteStore.set(t, us(t));
            let i = [t, e],
                n = this.layout.root,
                o = null;
            for (; i.length;) {
                let r = i.pop(),
                    a = i.pop();
                if (!a || a.nodeType !== 1 || Fe(a)) continue;
                let l = r ? r.measuredIsRemoved : !1,
                    c = l ? hr : getComputedStyle(a),
                    d = l ? !0 : c.display === "none",
                    u = l ? !0 : c.visibility === "hidden",
                    f = !d && !u,
                    g = a.dataset.layoutId,
                    y = vi(n, a),
                    h = g ? this.nodes.get(g) : null;
                if (h && h.$el !== a) {
                    let b = vi(n, h.$el),
                        T = h.measuredIsVisible,
                        _ = !b && (y || !y && !T && f),
                        x = b && !T && f;
                    if (_) dr(h), h = Ao(a, r, this, h);
                    else if (x) {
                        Po(h, a, c, l);
                        let L = a.lastElementChild;
                        for (; L;) i.push(L, h), L = L.previousElementSibling;
                        o || (o = h);
                        continue
                    } else {
                        let L = a.lastElementChild;
                        for (; L;) i.push(L, r), L = L.previousElementSibling;
                        o || (o = h);
                        continue
                    }
                } else h = Ao(a, r, this, h);
                h.branchAdded = !1, h.branchRemoved = !1, h.branchNotRendered = !1, h.isTarget = !1, h.sizeChanged = !1, h.hasVisibilityHidden = u, h.hasDisplayNone = d, h.hasVisibilitySwap = u && !h.measuredHasVisibilityHidden || d && !h.measuredHasDisplayNone, this.nodes.set(h.id, h), h.parentNode = r || null, h._prev = null, h._next = null, r ? (this.rootNodes.delete(h), r._head ? (r._tail._next = h, h._prev = r._tail, r._tail = h) : (r._head = h, r._tail = h)) : this.rootNodes.add(h), Po(h, h.$el, c, l);
                let m = a.lastElementChild;
                for (; m;) i.push(m, h), m = m.previousElementSibling;
                o || (o = h)
            }
            return o
        }
        ensureDetachedNode(t, e) {
            if (!t || t === this.layout.root) return null;
            let i = t.dataset.layoutId,
                n = i ? this.nodes.get(i) : null;
            if (n && n.$el === t) return n;
            let o = null,
                r = t.parentElement;
            for (; r && r !== this.layout.root;) {
                if (e.has(r)) {
                    o = this.ensureDetachedNode(r, e);
                    break
                }
                r = r.parentElement
            }
            return this.registerElement(t, o)
        }
        record() {
            let t = this.layout,
                e = t.children,
                i = t.root,
                n = Nt(e) ? e : [e],
                o = [],
                r = e === "*" ? i : yt.root,
                a = [],
                l = i.parentElement;
            for (; l && l.nodeType === 1;) {
                let m = getComputedStyle(l);
                if (m.transform && m.transform !== "none") {
                    let b = l.style.transform || "",
                        T = us(l);
                    a.push(l, b, T), l.style.transform = "none"
                }
                l = l.parentElement
            }
            for (let m = 0, b = n.length; m < b; m++) {
                let T = n[m];
                o[m] = vt(T) ? r.querySelectorAll(T) : T
            }
            let c = se(o);
            this.nodes.clear(), this.rootNodes.clear();
            let d = this.registerElement(i, null);
            d.isTarget = !0, this.rootNode = d;
            let u = new Set,
                f = 0,
                g = [];
            this.nodes.forEach(m => {
                g.push(m.$el)
            }), this.nodes.forEach((m, b) => {
                m.index = f++, m.targets = g, m && m.measuredIsInsideRoot && u.add(b)
            });
            let y = new Set,
                h = [];
            for (let m = 0, b = c.length; m < b; m++) {
                let T = c[m];
                if (!T || T.nodeType !== 1 || T === i) continue;
                if (!vi(i, T)) {
                    let x = T.dataset.layoutId;
                    if (!x || !u.has(x)) continue
                }
                y.has(T) || (y.add(T), h.push(T))
            }
            for (let m = 0, b = h.length; m < b; m++) this.ensureDetachedNode(h[m], y);
            for (let m = 0, b = c.length; m < b; m++) {
                let T = c[m],
                    _ = this.getNode(T);
                if (_) {
                    let x = _;
                    for (; x && !x.isTarget;) x.isTarget = !0, x = x.parentNode
                }
            }
            this.scrollX = window.scrollX, this.scrollY = window.scrollY, this.forEachNode(fr);
            for (let m = 0, b = a.length; m < b; m += 3) {
                let T = a[m],
                    _ = a[m + 1],
                    x = a[m + 2];
                _ && _ !== "" ? T.style.transform = _ : T.style.removeProperty("transform"), bi(T, x)
            }
            return this
        }
    };

function ds(s) {
    let t = {},
        e = {};
    for (let i in s) {
        let n = s[i],
            o = i === "ease";
        i === "duration" || i === "delay" || o ? e[i] = n : t[i] = n
    }
    return [t, e]
}
var Vs = class {
        constructor(t, e = {}) {
            yt.current && yt.current.register(this);
            let i = ds(e.swapAt),
                n = ds(e.enterFrom),
                o = ds(e.leaveTo),
                r = e.properties;
            if (e.duration = P(e.duration, 350), e.delay = P(e.delay, 0), e.ease = P(e.ease, "inOut(3.5)"), this.params = e, this.root = se(t)[0], this.id = e.id || ar++, this.children = e.children || "*", this.absoluteCoords = !1, this.swapAtParams = jt(e.swapAt || {
                    opacity: 0
                }, {
                    ease: "inOut(1.75)"
                }), this.enterFromParams = e.enterFrom || {
                    opacity: 0
                }, this.leaveToParams = e.leaveTo || {
                    opacity: 0
                }, this.properties = new Set(["opacity", "fontSize", "color", "backgroundColor", "borderRadius", "border", "filter", "clipPath"]), i[0])
                for (let a in i[0]) this.properties.add(a);
            if (n[0])
                for (let a in n[0]) this.properties.add(a);
            if (o[0])
                for (let a in o[0]) this.properties.add(a);
            if (r)
                for (let a = 0, l = r.length; a < l; a++) this.properties.add(r[a]);
            this.recordedProperties = new Set(["display", "visibility", "translate", "position", "left", "top", "marginLeft", "marginTop", "width", "height", "maxWidth", "maxHeight", "minWidth", "minHeight"]), this.properties.forEach(a => this.recordedProperties.add(a)), this.pendingRemoval = new WeakSet, this.transitionMuteStore = new Map, this.oldState = new Ti(this), this.newState = new Ti(this), this.timeline = null, this.transformAnimation = null, this.animating = [], this.swapping = [], this.leaving = [], this.entering = [], this.oldState.record(), yi(this.transitionMuteStore)
        }
        revert() {
            return this.root.classList.remove("is-animated"), this.timeline && (this.timeline.complete(), this.timeline = null), this.transformAnimation && (this.transformAnimation.complete(), this.transformAnimation = null), this.animating.length = this.swapping.length = this.leaving.length = this.entering.length = 0, this.oldState.revert(), this.newState.revert(), requestAnimationFrame(() => yi(this.transitionMuteStore)), this
        }
        record() {
            return this.transformAnimation && (this.transformAnimation.cancel(), this.transformAnimation = null), this.oldState.record(), this.timeline && (this.timeline.cancel(), this.timeline = null), this.newState.forEachRootNode(Ro), this
        }
        animate(t = {}) {
            let e = {
                    ease: P(t.ease, this.params.ease),
                    delay: P(t.delay, this.params.delay),
                    duration: P(t.duration, this.params.duration)
                },
                i = {
                    id: this.id
                },
                n = P(t.onComplete, this.params.onComplete),
                o = P(t.onPause, this.params.onPause);
            for (let p in Ye) p !== "ease" && p !== "duration" && p !== "delay" && (S(t[p]) ? S(this.params[p]) || (i[p] = this.params[p]) : i[p] = t[p]);
            i.onComplete = () => {
                let p = t.autoplay,
                    C = E.editor;
                if (p && p.linked || C && C.showPanel) {
                    n && n(this.timeline);
                    return
                }
                this.transformAnimation && this.transformAnimation.cancel(), m.forEachRootNode(w => {
                    $o(w), Ro(w)
                });
                for (let w = 0, V = J.length; w < V; w++) {
                    let B = J[w];
                    B.style.transform = m.getComputedValue(B, "transform")
                }
                this.root.classList.contains("is-animated") && (this.root.classList.remove("is-animated"), n && n(this.timeline)), requestAnimationFrame(() => {
                    this.root.classList.contains("is-animated") || yi(this.transitionMuteStore)
                })
            }, i.onPause = () => {
                let p = t.autoplay;
                if (p && p.linked) {
                    n && n(this.timeline), o && o(this.timeline);
                    return
                }
                this.root.classList.contains("is-animated") && (this.transformAnimation && this.transformAnimation.cancel(), m.forEachRootNode($o), this.root.classList.remove("is-animated"), n && n(this.timeline), o && o(this.timeline))
            }, i.composition = !1;
            let r = jt(jt(t.swapAt || {}, this.swapAtParams), e),
                a = jt(jt(t.enterFrom || {}, this.enterFromParams), e),
                l = jt(jt(t.leaveTo || {}, this.leaveToParams), e),
                [c, d] = ds(r),
                [u, f] = ds(a),
                [g, y] = ds(l),
                h = this.oldState,
                m = this.newState,
                b = this.animating,
                T = this.swapping,
                _ = this.entering,
                x = this.leaving,
                L = this.pendingRemoval;
            b.length = T.length = _.length = x.length = 0, h.forEachRootNode(cr), m.record(), m.forEachRootNode(ur);
            let R = [],
                H = [],
                J = [],
                K = [],
                z = m.rootNode,
                D = z.$el;
            m.forEachRootNode(p => {
                let C = p.$el,
                    v = p.id,
                    w = p.parentNode,
                    V = w ? w.branchAdded : !1,
                    B = w ? w.branchRemoved : !1,
                    k = w ? w.branchNotRendered : !1,
                    Y = h.nodes.get(v),
                    dt = !Y;
                dt ? (Y = yn(p, {}, h), h.nodes.set(v, Y), Y.measuredIsRemoved = !0) : Y.measuredIsRemoved && !p.measuredIsRemoved && (yn(p, Y, h), Y.measuredIsRemoved = !0);
                let X = Y.parentNode,
                    et = X ? X.id : null,
                    ut = w ? w.id : null,
                    it = et !== ut,
                    kt = Y.$el !== p.$el,
                    Dt = Y.measuredIsRemoved,
                    U = p.measuredIsRemoved;
                if (!Y.measuredIsRemoved && !U && !dt && (it || kt)) {
                    let Xt = Y.properties.left,
                        ht = Y.properties.top,
                        _t = w || m.rootNode,
                        Q = _t.id ? h.nodes.get(_t.id) : null,
                        Tt = Q ? Q.properties.left : _t.properties.left,
                        $ = Q ? Q.properties.top : _t.properties.top,
                        st = Q ? Q.properties.clientLeft : _t.properties.clientLeft,
                        j = Q ? Q.properties.clientTop : _t.properties.clientTop;
                    Y.properties.x = Xt - Tt - st, Y.properties.y = ht - $ - j
                }
                p.hasVisibilitySwap && (p.hasVisibilityHidden && (p.$el.style.visibility = "visible", p.$measure.style.visibility = "hidden"), p.hasDisplayNone && (p.$el.style.display = Y.measuredDisplay || p.measuredDisplay || "", p.$measure.style.visibility = "hidden"));
                let rt = L.has(C),
                    xt = Y.measuredIsVisible,
                    $t = p.measuredIsVisible,
                    ft = !xt && $t && !k,
                    pt = !U && (Dt || rt) && !V,
                    St = U && !Dt && !B,
                    Ct = St || U && rt && !B;
                p.branchAdded = V || pt, p.branchRemoved = B || Ct, p.branchNotRendered = k || U, U && xt && (p.$el.style.display = Y.measuredDisplay, p.$el.style.visibility = "visible", yn(Y, p, m)), St ? (p.isTarget && (x.push(C), p.isLeaving = !0), L.add(C)) : !U && rt && L.delete(C), pt && !k || ft ? (Lo(Y, u), p.isTarget && (_.push(C), p.isEntering = !0)) : Ct && !k && Lo(p, g), p !== z && p.isTarget && !p.isEntering && !p.isLeaving && b.push(C), R.push(C)
            });
            let M = 0,
                q = 0,
                N = 0;
            m.forEachRootNode(p => {
                let C = p.$el,
                    v = p.parentNode,
                    w = h.nodes.get(p.id),
                    V = p.properties,
                    B = w.properties,
                    k = v !== z && v;
                for (; k && !k.isTarget && k !== z;) k = k.parentNode;
                p === z ? (p.index = 0, p.targets = b, Is(p, e)) : p.isEntering ? (p.index = k ? k.index : M, p.targets = k ? b : _, Is(p, f), M++) : p.isLeaving ? (p.index = k ? k.index : q, p.targets = k ? b : x, q++, Is(p, y)) : p.isTarget ? (p.index = N++, p.targets = b, Is(p, e)) : (p.index = k ? k.index : 0, p.targets = b, Is(p, d)), w.index = p.index, w.targets = p.targets;
                for (let et in V) V[et] = Rt(V[et], C, p.index, p.targets, null, null), B[et] = Rt(B[et], C, w.index, w.targets, null, null);
                let Y = 1,
                    dt = Math.abs(V.width - B.width) > Y,
                    X = Math.abs(V.height - B.height) > Y;
                if (p.sizeChanged = dt || X, p.isTarget && (!p.measuredIsRemoved && w.measuredIsVisible || p.measuredIsRemoved && p.measuredIsVisible)) {
                    (V.transform !== "none" || B.transform !== "none") && (p.hasTransform = !0, J.push(C));
                    for (let et in V)
                        if (et !== "transform" && V[et] !== B[et]) {
                            H.push(C);
                            break
                        }
                }
                p.isTarget || (T.push(C), p.sizeChanged && v && v.isTarget && v.sizeChanged && (c.transform && (p.hasTransform = !0, J.push(C)), K.push(C)))
            });
            let F = {
                delay: p => m.getNode(p).delay,
                duration: p => m.getNode(p).duration,
                ease: p => m.getNode(p).ease
            };
            if (i.defaults = F, this.timeline = Be(i), !H.length && !J.length && !T.length) return yi(this.transitionMuteStore), this.timeline.complete();
            if (R.length) {
                this.root.classList.add("is-animated");
                for (let p = 0, C = R.length; p < C; p++) {
                    let v = R[p],
                        w = v.dataset.layoutId,
                        V = h.nodes.get(w),
                        B = m.nodes.get(w),
                        k = V.properties;
                    B.isInlined || ((V.measuredDisplay === "grid" || B.measuredDisplay === "grid") && v.style.setProperty("display", "block", "important"), (v !== D || this.absoluteCoords) && (v.style.position = this.absoluteCoords ? "fixed" : "absolute", v.style.left = "0px", v.style.top = "0px", v.style.marginLeft = "0px", v.style.marginTop = "0px", v.style.translate = `${k.x}px ${k.y}px`), v === D && B.measuredPosition === "static" && (v.style.position = "relative", v.style.left = "0px", v.style.top = "0px")), v.style.width = `${k.width}px`, v.style.height = `${k.height}px`, v.style.minWidth = "auto", v.style.minHeight = "auto", v.style.maxWidth = "none", v.style.maxHeight = "none"
                }(h.scrollX !== window.scrollX || h.scrollY !== window.scrollY) && requestAnimationFrame(() => window.scrollTo(h.scrollX, h.scrollY));
                for (let p = 0, C = H.length; p < C; p++) {
                    let v = H[p],
                        w = v.dataset.layoutId,
                        V = h.nodes.get(w),
                        B = m.nodes.get(w),
                        k = V.properties,
                        Y = B.properties,
                        dt = !1,
                        X = {
                            composition: "none"
                        };
                    k.width !== Y.width && (X.width = [k.width, Y.width], dt = !0), k.height !== Y.height && (X.height = [k.height, Y.height], dt = !0), !B.hasTransform && !B.isInlined && (X.translate = [`${k.x}px ${k.y}px`, `${Y.x}px ${Y.y}px`], dt = !0), this.properties.forEach(et => {
                        let ut = k[et],
                            it = Y[et];
                        et !== "transform" && ut !== it && (X[et] = [ut, it], dt = !0)
                    }), dt && this.timeline.add(v, X, 0)
                }
            }
            if (T.length) {
                for (let p = 0, C = T.length; p < C; p++) {
                    let v = T[p],
                        w = h.getNode(v),
                        V = w.properties;
                    v.style.width = `${V.width}px`, v.style.height = `${V.height}px`, v.style.minWidth = "auto", v.style.minHeight = "auto", v.style.maxWidth = "none", v.style.maxHeight = "none", w.isInlined || (v.style.translate = `${V.x}px ${V.y}px`), this.properties.forEach(B => {
                        B !== "transform" && (v.style[B] = `${h.getComputedValue(v,B)}`)
                    })
                }
                for (let p = 0, C = T.length; p < C; p++) {
                    let v = T[p],
                        w = m.getNode(v),
                        V = w.properties;
                    this.timeline.call(() => {
                        v.style.width = `${V.width}px`, v.style.height = `${V.height}px`, v.style.minWidth = "auto", v.style.minHeight = "auto", v.style.maxWidth = "none", v.style.maxHeight = "none", w.isInlined || (v.style.translate = `${V.x}px ${V.y}px`), this.properties.forEach(B => {
                            B !== "transform" && (v.style[B] = `${m.getComputedValue(v,B)}`)
                        })
                    }, w.delay + w.duration / 2)
                }
                if (K.length) {
                    let p = Zt(m.nodes.get(K[0].dataset.layoutId).ease),
                        C = w => 1 - p(1 - w),
                        v = {};
                    if (c)
                        for (let w in c) w !== "transform" && (v[w] = [{
                            from: V => h.getComputedValue(V, w),
                            to: c[w]
                        }, {
                            from: c[w],
                            to: V => m.getComputedValue(V, w),
                            ease: C
                        }]);
                    this.timeline.add(K, v, 0)
                }
            }
            let at = J.length;
            if (at) {
                for (let p = 0; p < at; p++) {
                    let C = J[p],
                        v = m.getNode(C);
                    v.isInlined || (C.style.translate = `${h.getComputedValue(C,"x")}px ${h.getComputedValue(C,"y")}px`), C.style.transform = h.getComputedValue(C, "transform"), K.includes(C) && (v.ease = Rt(r.ease, C, v.index, v.targets, null, null), v.duration = Rt(r.duration, C, v.index, v.targets, null, null))
                }
                this.transformAnimation = gi.animate(J, {
                    translate: p => m.getNode(p).isInlined ? "0px 0px" : `${m.getComputedValue(p,"x")}px ${m.getComputedValue(p,"y")}px`,
                    transform: p => {
                        let C = m.getComputedValue(p, "transform");
                        if (!K.includes(p)) return C;
                        let v = h.getComputedValue(p, "transform"),
                            w = m.getNode(p);
                        return [v, Rt(c.transform, p, w.index, w.targets, null, null), C]
                    },
                    autoplay: !1,
                    ...F
                }), this.timeline.sync(this.transformAnimation, 0)
            }
            return this.timeline.init()
        }
        update(t, e = {}) {
            return this.record(), t(this), this.animate(e)
        }
    },
    No = (s, t) => new Vs(s, t);
var Bt = {};
ys(Bt, {
    $: () => se,
    addChild: () => zt,
    clamp: () => Ri,
    cleanInlineStyles: () => Gs,
    createSeededRandom: () => De,
    damp: () => ki,
    degToRad: () => Ai,
    forEachChildren: () => ot,
    get: () => pe,
    keepTime: () => Xe,
    lerp: () => Ni,
    mapRange: () => Ei,
    padEnd: () => wi,
    padStart: () => _i,
    radToDeg: () => Pi,
    random: () => Ue,
    randomPick: () => Di,
    remove: () => ri,
    removeChild: () => Gt,
    round: () => $i,
    roundPad: () => Si,
    set: () => ce,
    shuffle: () => fs,
    snap: () => Li,
    stagger: () => ms,
    sync: () => cs,
    wrap: () => Ci
});
var ge = Jn,
    xi = {},
    mr = (s, t = 0) => (...e) => t ? i => s(...e, i) : i => s(i, ...e),
    ko = s => (...t) => {
        let e = s(...t);
        return new Proxy(Z, {
            apply: (i, n, [o]) => e(o),
            get: (i, n) => {
                if (xi[n]) return ko((...o) => {
                    let r = xi[n](...o);
                    return a => r(e(a))
                })
            }
        })
    },
    ye = (s, t, e = 0) => {
        let i = (...n) => (n.length < t.length ? ko(mr(t, e)) : t)(...n);
        return xi[s] || (xi[s] = i), i
    },
    Si = ye("roundPad", ge.roundPad),
    _i = ye("padStart", ge.padStart),
    wi = ye("padEnd", ge.padEnd),
    Ci = ye("wrap", ge.wrap),
    Ei = ye("mapRange", ge.mapRange),
    Ai = ye("degToRad", ge.degToRad),
    Pi = ye("radToDeg", ge.radToDeg),
    Li = ye("snap", ge.snap),
    Ri = ye("clamp", ge.clamp),
    $i = ye("round", ge.round),
    Ni = ye("lerp", ge.lerp, 1),
    ki = ye("damp", ge.damp, 1);
var Ue = (s = 0, t = 1, e = 0) => {
        let i = 10 ** e;
        return Math.floor((Math.random() * (t - s + 1 / i) + s) * i) / i
    },
    pr = 0,
    De = (s, t = 0, e = 1, i = 0) => {
        let n = s === void 0 ? pr++ : s;
        return (o = t, r = e, a = i) => {
            n += 1831565813, n = Math.imul(n ^ n >>> 15, n | 1), n ^= n + Math.imul(n ^ n >>> 7, n | 61);
            let l = 10 ** a;
            return Math.floor((((n ^ n >>> 14) >>> 0) / 4294967296 * (r - o + 1 / l) + o) * l) / l
        }
    },
    Di = s => s[Ue(0, s.length - 1)],
    fs = (s, t = Ue) => {
        let e = s.length,
            i, n;
        for (; e;) n = t(0, --e), i = s[e], s[e] = s[n], s[n] = i;
        return s
    };
var ms = (s, t = {}) => {
    let e = [],
        i = 0,
        n, o = null,
        r = t.from,
        a = t.reversed,
        l = t.ease,
        c = !S(l),
        u = c && !S(l.ease) ? l.ease : c ? Zt(l) : null,
        f = t.grid,
        g = f === !0,
        y = t.axis,
        h = t.total,
        m = S(r) || r === 0 || r === "first",
        b = r === "center",
        T = r === "last",
        _ = r === "random",
        x = Nt(r),
        L = Nt(s),
        R = t.use,
        H = L ? Pe(s[0]) : Pe(s),
        J = L ? Pe(s[1]) : 0,
        K = Us.exec((L ? s[1] : s) + Kt),
        z = t.start || 0 + (L ? H : 0),
        D = t.seed,
        q = !S(D) && D !== !1 ? De(D === !0 ? 0 : D) : Ue,
        N = t.jitter,
        F = !S(N),
        at = Nt(N),
        p = at ? N[0] : N || 0,
        C = at ? N[1] : N || 0,
        v = m ? 0 : Lt(r) ? r : 0;
    return (w, V, B, k, Y) => {
        let [dt] = se(w), X = S(h) ? B.length : h, et = S(R) ? !1 : lt(R) ? R(dt, V, X) : xe(dt, R), ut = Lt(et) || vt(et) && Lt(+et) ? +et : V, it = ut >= 0 && ut < X ? ut : V;
        if (b && (v = (X - 1) / 2), T && (v = X - 1), !e.length) {
            if (g) {
                let U = !0,
                    rt = !1,
                    xt = 1 / 0,
                    $t = 1 / 0,
                    ft = 1 / 0,
                    pt = -1 / 0,
                    St = -1 / 0,
                    Ct = -1 / 0,
                    Xt = [],
                    ht = [],
                    _t = [];
                for (let Q = 0; Q < X; Q++) {
                    let Tt = B[Q],
                        $ = 0,
                        st = 0,
                        j = 0,
                        W = !1;
                    if (Tt && lt(Tt.getBoundingClientRect)) {
                        let mt = Tt.getBoundingClientRect();
                        $ = mt.left + mt.width / 2, st = mt.top + mt.height / 2, W = !0
                    } else {
                        let mt = Tt;
                        mt && Lt(mt.x) && Lt(mt.y) && ($ = mt.x, st = mt.y, Lt(mt.z) && (j = mt.z, rt = !0), W = !0)
                    }
                    if (!W) {
                        U = !1;
                        break
                    }
                    Xt.push($), ht.push(st), _t.push(j), $ < xt && (xt = $), st < $t && ($t = st), j < ft && (ft = j), $ > pt && (pt = $), st > St && (St = st), j > Ct && (Ct = j)
                }
                if (U) {
                    let Q = Xt[0],
                        Tt = ht[0],
                        $ = _t[0];
                    x ? (Q = xt + r[0] * (pt - xt), Tt = $t + r[1] * (St - $t), $ = rt ? ft + (r.length >= 3 ? r[2] : .5) * (Ct - ft) : 0) : b ? (Q = (xt + pt) / 2, Tt = ($t + St) / 2, $ = (ft + Ct) / 2) : T ? (Q = Xt[X - 1], Tt = ht[X - 1], $ = _t[X - 1]) : Lt(r) && (Q = Xt[r], Tt = ht[r], $ = _t[r]);
                    for (let j = 0; j < X; j++) {
                        let W = Q - Xt[j],
                            mt = Tt - ht[j],
                            Et = $ - _t[j],
                            Jt = qt(W * W + mt * mt + (rt ? Et * Et : 0));
                        y === "x" && (Jt = -W), y === "y" && (Jt = -mt), y === "z" && (Jt = -Et), e.push(Jt)
                    }
                    let st = 1 / 0;
                    for (let j = 0; j < X; j++) {
                        let W = ne(e[j]);
                        W > 0 && W < st && (st = W)
                    }
                    if (st > 0 && st < 1 / 0)
                        for (let j = 0; j < X; j++) e[j] = e[j] / st
                } else
                    for (let Q = 0; Q < X; Q++) e.push(ne(v - Q))
            } else
                for (let U = 0; U < X; U++)
                    if (!f) e.push(ne(v - U));
                    else {
                        let rt = f.length,
                            xt = f[0] * f[1],
                            $t, ft, pt;
                        x ? ($t = r[0] * (f[0] - 1), ft = r[1] * (f[1] - 1), pt = rt === 3 ? (r.length >= 3 ? r[2] : .5) * (f[2] - 1) : 0) : b ? ($t = (f[0] - 1) / 2, ft = (f[1] - 1) / 2, pt = rt === 3 ? (f[2] - 1) / 2 : 0) : ($t = v % f[0], ft = Re(v / f[0]) % f[1], pt = rt === 3 ? Re(v / xt) : 0);
                        let St = U % f[0],
                            Ct = Re(U / f[0]) % f[1],
                            Xt = rt === 3 ? Re(U / xt) : 0,
                            ht = $t - St,
                            _t = ft - Ct,
                            Q = pt - Xt,
                            Tt = qt(ht * ht + _t * _t + (rt === 3 ? Q * Q : 0));
                        y === "x" && (Tt = -ht), y === "y" && (Tt = -_t), y === "z" && (Tt = -Q), e.push(Tt)
                    }
            i = e[0];
            for (let U = 1; U < X; U++) e[U] > i && (i = e[U]);
            if (u || a)
                for (let U = 0; U < X; U++) {
                    let rt = e[U];
                    u && (rt = u(rt / i) * i), a && (rt = y ? -rt : ne(i - rt)), e[U] = rt
                }
            if (F) {
                o = new Array(X);
                for (let U = 0; U < X; U++) o[U] = q(-1, 1, 4)
            }
            _ && (e = fs(e, q))
        }
        let kt = L ? (J - H) / i : H;
        S(n) && (n = Y ? je(Y, S(t.start) ? Y.iterationDuration : z) : z);
        let Dt = n + (kt * A(e[it], 2) || 0);
        if (F) {
            let U = i ? e[it] / i : 0,
                rt = p + (C - p) * U;
            Dt = Dt + o[it] * rt
        }
        return t.modifier && (Dt = t.modifier(Dt)), K && (Dt = `${Dt}${K[2]}`), Dt
    }
};
var Tn = {};
ys(Tn, {
    createDrawable: () => Fi,
    createMotionPath: () => Vi,
    morphTo: () => Oi
});
var Ii = s => {
    let e = Ht(s)[0];
    return !e || !Fe(e) ? console.warn(`${s} is not a valid SVGGeometryElement`) : e
};
var vn = (s, t, e, i, n) => {
        let o = e + i,
            r = n ? Math.max(0, Math.min(o, t)) : (o % t + t) % t;
        return s.getPointAtLength(r)
    },
    bn = (s, t, e = 0) => i => {
        let n = +s.getTotalLength(),
            o = i[Ke],
            r = s.getCTM(),
            a = e === 0;
        return {
            from: 0,
            to: n,
            modifier: l => {
                let c = e * n,
                    d = l + c;
                if (t === "a") {
                    let u = vn(s, n, d, -1, a),
                        f = vn(s, n, d, 1, a);
                    return ss(f.y - u.y, f.x - u.x) * 180 / oe
                } else {
                    let u = vn(s, n, d, 0, a);
                    return t === "x" ? o || !r ? u.x : u.x * r.a + u.y * r.c + r.e : o || !r ? u.y : u.x * r.b + u.y * r.d + r.f
                }
            }
        }
    },
    Vi = (s, t = 0) => {
        let e = Ii(s);
        if (e) return {
            translateX: bn(e, "x", t),
            translateY: bn(e, "y", t),
            rotate: bn(e, "a", t)
        }
    };
var gr = s => {
        let t = 1;
        if (s && s.getCTM) {
            let e = s.getCTM();
            if (e) {
                let i = qt(e.a * e.a + e.b * e.b),
                    n = qt(e.c * e.c + e.d * e.d);
                t = (i + n) / 2
            }
        }
        return t
    },
    yr = (s, t, e) => {
        let i = Vt,
            n = getComputedStyle(s),
            o = n.strokeLinecap,
            r = n.vectorEffect === "non-scaling-stroke" ? s : null,
            a = o,
            l = new Proxy(s, {
                get(c, d) {
                    let u = c[d];
                    return d === Hs ? c : d === "setAttribute" ? (...f) => {
                        if (f[0] === "draw") {
                            let y = f[1].split(" "),
                                h = +y[0],
                                m = +y[1],
                                b = gr(r),
                                T = h * -i * b,
                                _ = m * i * b + T,
                                x = i * b + (h === 0 && m === 1 || h === 1 && m === 0 ? 0 : 10 * b) - _;
                            if (o !== "butt") {
                                let L = h === m ? "butt" : o;
                                a !== L && (c.style.strokeLinecap = `${L}`, a = L)
                            }
                            c.setAttribute("stroke-dashoffset", `${T}`), c.setAttribute("stroke-dasharray", `${_} ${x}`)
                        }
                        return Reflect.apply(u, c, f)
                    } : lt(u) ? (...f) => Reflect.apply(u, c, f) : u
                }
            });
        return s.getAttribute("pathLength") !== `${i}` && (s.setAttribute("pathLength", `${i}`), l.setAttribute("draw", `${t} ${e}`)), l
    },
    Fi = (s, t = 0, e = 0) => Ht(s).map(n => yr(n, t, e));
var Oi = (s, t = .33) => (e, i, n, o) => {
    if (!(e.tagName || "").toLowerCase().match(/^(path|polygon|polyline)$/)) throw new Error(`Can't morph a <${e.tagName}> SVG element. Use <path>, <polygon> or <polyline>.`);
    let a = Ii(s);
    if (!a) throw new Error("Can't morph to an invalid target. 'path2' must resolve to an existing <path>, <polygon> or <polyline> SVG element.");
    if (!(a.tagName || "").toLowerCase().match(/^(path|polygon|polyline)$/)) throw new Error(`Can't morph a <${a.tagName}> SVG element. Use <path>, <polygon> or <polyline>.`);
    let c = e.tagName === "path",
        d = c ? " " : ",",
        u = o ? o._value : null;
    u && e.setAttribute(c ? "d" : "points", u);
    let f = "",
        g = "";
    if (!t) f = e.getAttribute(c ? "d" : "points"), g = a.getAttribute(c ? "d" : "points");
    else {
        let y = e.getTotalLength(),
            h = a.getTotalLength(),
            m = Math.max(Math.ceil(y * t), Math.ceil(h * t));
        for (let b = 0; b < m; b++) {
            let T = b / (m - 1),
                _ = e.getPointAtLength(y * T),
                x = a.getPointAtLength(h * T),
                L = c ? b === 0 ? "M" : "L" : "";
            f += L + A(_.x, 3) + d + _.y + " ", g += L + A(x.x, 3) + d + x.y + " "
        }
    }
    return [f, g]
};
var Rn = {};
ys(Rn, {
    TextSplitter: () => ze,
    scrambleText: () => zi,
    split: () => Ui,
    splitText: () => Xi
});
var Bi = typeof Intl < "u" && Intl.Segmenter,
    vr = /\{value\}/g,
    br = /\{i\}/g,
    xn = /(\s+)/,
    An = /^\s+$/,
    Pn = "line",
    Fs = "word",
    Os = "char",
    Bs = "data-line",
    Sn = null,
    _n = null,
    Hi = null,
    Do = s => s.isWordLike || s.segment === " " || Lt(+s.segment),
    wn = s => s.setAttribute("aria-hidden", "true"),
    Mi = (s, t) => [...s.querySelectorAll(`[data-${t}]:not([data-${t}] [data-${t}])`)],
    Tr = {
        line: "#00D672",
        word: "#FF4B4B",
        char: "#5A87FF"
    },
    Io = s => {
        if (!s.childElementCount && !s.textContent.trim()) {
            let t = s.parentElement;
            s.remove(), t && Io(t)
        }
    },
    Vo = (s, t, e) => {
        let i = s.getAttribute(Bs);
        if (i !== null && +i !== t || s.tagName === "BR") {
            e.add(s);
            let o = s.previousSibling,
                r = s.nextSibling;
            o && o.nodeType === 3 && An.test(o.textContent) && e.add(o), r && r.nodeType === 3 && An.test(r.textContent) && e.add(r)
        }
        let n = s.childElementCount;
        for (; n--;) Vo(s.children[n], t, e);
        return e
    },
    Cn = (s, t = {}) => {
        let e = "";
        t || (t = {});
        let i = vt(t.class) ? ` class="${t.class}"` : "",
            n = P(t.clone, !1),
            o = P(t.wrap, !1),
            r = o ? o === !0 ? "clip" : o : n ? "clip" : !1;
        if (o && (e += `<span${r?` style="overflow:${r};"`:""}>`), e += `<span${i}${n?' style="position:relative;"':""} data-${s}="{i}">`, n) {
            let a = n === "left" ? "-100%" : n === "right" ? "100%" : "0",
                l = n === "top" ? "-100%" : n === "bottom" ? "100%" : "0";
            e += "<span>{value}</span>", e += `<span inert style="position:absolute;top:${l};left:${a};white-space:nowrap;">{value}</span>`
        } else e += "{value}";
        return e += "</span>", o && (e += "</span>"), e
    },
    En = (s, t, e, i, n, o, r, a, l) => {
        let c = n === Pn,
            d = n === Os,
            u = `_${n}_`,
            f = lt(s) ? s(e) : s,
            g = c ? "block" : "inline-block";
        Hi.innerHTML = f.replace(vr, `<i class="${u}"></i>`).replace(br, `${d?l:c?r:a}`);
        let y = Hi.content,
            h = y.firstElementChild,
            m = y.querySelector(`[data-${n}]`) || h,
            b = y.querySelectorAll(`i.${u}`),
            T = b.length;
        if (T) {
            h.style.display = g, m.style.display = g, m.setAttribute(Bs, `${r}`), c || (m.setAttribute("data-word", `${a}`), d && m.setAttribute("data-char", `${l}`));
            let _ = T;
            for (; _--;) {
                let x = b[_],
                    L = x.parentElement;
                L.style.display = g, c ? L.innerHTML = e.innerHTML : L.replaceChild(e.cloneNode(!0), x)
            }
            t.push(m), i.appendChild(y)
        } else console.warn('The expression "{value}" is missing from the provided template.');
        return o && (h.style.outline = `1px dotted ${Tr[n]}`), h
    },
    ze = class {
        constructor(t, e = {}) {
            Sn || (Sn = Bi ? new Bi([], {
                granularity: Fs
            }) : {
                segment: y => {
                    let h = [],
                        m = y.split(xn);
                    for (let b = 0, T = m.length; b < T; b++) {
                        let _ = m[b];
                        h.push({
                            segment: _,
                            isWordLike: !An.test(_)
                        })
                    }
                    return h
                }
            }), _n || (_n = Bi ? new Bi([], {
                granularity: "grapheme"
            }) : {
                segment: y => [...y].map(h => ({
                    segment: h
                }))
            }), !Hi && be && (Hi = O.createElement("template")), yt.current && yt.current.register(this);
            let {
                words: i,
                chars: n,
                lines: o,
                accessible: r,
                includeSpaces: a,
                debug: l
            } = e, c = (t = Nt(t) ? t[0] : t) && t.nodeType ? t : (Qs(t) || [])[0], d = o === !0 ? {} : o, u = i === !0 || S(i) ? {} : i, f = n === !0 ? {} : n;
            this.debug = P(l, !1), this.includeSpaces = P(a, !1), this.accessible = P(r, !0), this.linesOnly = d && !u && !f, this.lineTemplate = wt(d) ? Cn(Pn, d) : d, this.wordTemplate = wt(u) || this.linesOnly ? Cn(Fs, u) : u, this.charTemplate = wt(f) ? Cn(Os, f) : f, this.$target = c, this.html = c && c.innerHTML, this.lines = [], this.words = [], this.chars = [], this.effects = [], this.effectsCleanups = [], this.cache = null, this.ready = !1, this.width = 0, this.resizeTimeout = null;
            let g = () => this.html && (d || u || f) && this.split();
            this.resizeObserver = new ResizeObserver(() => {
                clearTimeout(this.resizeTimeout), this.resizeTimeout = setTimeout(() => {
                    let y = c.offsetWidth;
                    y !== this.width && (this.width = y, g())
                }, 150)
            }), this.lineTemplate && !this.ready ? O.fonts.ready.then(g) : g(), c ? this.resizeObserver.observe(c) : console.warn("No Text Splitter target found.")
        }
        addEffect(t) {
            if (!lt(t)) return console.warn("Effect must return a function."), this;
            let e = Xe(t);
            return this.effects.push(e), this.ready && (this.effectsCleanups[this.effects.length - 1] = e(this)), this
        }
        revert() {
            return clearTimeout(this.resizeTimeout), this.lines.length = this.words.length = this.chars.length = 0, this.resizeObserver.disconnect(), this.effectsCleanups.forEach(t => lt(t) ? t(this) : t.revert && t.revert()), this.$target.innerHTML = this.html, this
        }
        splitNode(t) {
            let e = this.wordTemplate,
                i = this.charTemplate,
                n = this.includeSpaces,
                o = this.debug,
                r = t.nodeType;
            if (r === 3) {
                let a = t.nodeValue;
                if (a.trim()) {
                    let l = [],
                        c = this.words,
                        d = this.chars,
                        u = Sn.segment(a),
                        f = O.createDocumentFragment(),
                        g = null;
                    for (let y of u) {
                        let h = y.segment,
                            m = Do(y);
                        if (!g || m && g && Do(g)) l.push(h);
                        else {
                            let b = l.length - 1,
                                T = l[b];
                            !xn.test(T) && !xn.test(h) ? l[b] += h : l.push(h)
                        }
                        g = y
                    }
                    for (let y = 0, h = l.length; y < h; y++) {
                        let m = l[y];
                        if (m.trim()) {
                            let b = l[y + 1],
                                T = n && b && !b.trim(),
                                _ = m,
                                x = i ? _n.segment(_) : null,
                                L = i ? O.createDocumentFragment() : O.createTextNode(T ? m + "\xA0" : m);
                            if (i) {
                                let R = [...x];
                                for (let H = 0, J = R.length; H < J; H++) {
                                    let K = R[H],
                                        D = H === J - 1 && T ? K.segment + "\xA0" : K.segment,
                                        M = O.createTextNode(D);
                                    En(i, d, M, L, Os, o, -1, c.length, d.length)
                                }
                            }
                            e ? En(e, c, L, f, Fs, o, -1, c.length, d.length) : i ? f.appendChild(L) : f.appendChild(O.createTextNode(m)), T && y++
                        } else {
                            if (y && n) continue;
                            f.appendChild(O.createTextNode(m))
                        }
                    }
                    t.parentNode.replaceChild(f, t)
                }
            } else if (r === 1) {
                let a = [...t.childNodes];
                for (let l = 0, c = a.length; l < c; l++) this.splitNode(a[l])
            }
        }
        split(t = !1) {
            let e = this.$target,
                i = !!this.cache && !t,
                n = this.lineTemplate,
                o = this.wordTemplate,
                r = this.charTemplate,
                a = O.fonts.status !== "loading",
                l = n && a;
            this.ready = !n || a, (l || t) && this.effectsCleanups.forEach(f => lt(f) && f(this)), i || (t && (e.innerHTML = this.html, this.words.length = this.chars.length = 0), this.splitNode(e), this.cache = e.innerHTML), l && (i && (e.innerHTML = this.cache), this.lines.length = 0, o && (this.words = Mi(e, Fs))), r && (l || o) && (this.chars = Mi(e, Os));
            let c = this.words.length ? this.words : this.chars,
                d, u = 0;
            for (let f = 0, g = c.length; f < g; f++) {
                let y = c[f],
                    {
                        top: h,
                        height: m
                    } = y.getBoundingClientRect();
                !S(d) && h - d > m * .5 && u++, y.setAttribute(Bs, `${u}`);
                let b = y.querySelectorAll(`[${Bs}]`),
                    T = b.length;
                for (; T--;) b[T].setAttribute(Bs, `${u}`);
                d = h
            }
            if (l) {
                let f = O.createDocumentFragment(),
                    g = new Set,
                    y = [];
                for (let h = 0; h < u + 1; h++) {
                    let m = e.cloneNode(!0);
                    Vo(m, h, new Set).forEach(b => {
                        let T = b.parentNode;
                        T && (b.nodeType === 1 && g.add(T), T.removeChild(b))
                    }), y.push(m)
                }
                g.forEach(Io);
                for (let h = 0, m = y.length; h < m; h++) En(n, this.lines, y[h], f, Pn, this.debug, h);
                e.innerHTML = "", e.appendChild(f), o && (this.words = Mi(e, Fs)), r && (this.chars = Mi(e, Os))
            }
            if (this.linesOnly) {
                let f = this.words,
                    g = f.length;
                for (; g--;) {
                    let y = f[g];
                    y.replaceWith(y.textContent)
                }
                f.length = 0
            }
            if (this.accessible && (l || !i)) {
                let f = O.createElement("span");
                f.style.cssText = "position:absolute;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);width:1px;height:1px;white-space:nowrap;", f.innerHTML = this.html, e.insertBefore(f, e.firstChild), this.lines.forEach(wn), this.words.forEach(wn), this.chars.forEach(wn)
            }
            return this.width = e.offsetWidth, (l || t) && this.effects.forEach((f, g) => this.effectsCleanups[g] = f(this)), this
        }
        refresh() {
            this.split(!0)
        }
    },
    Xi = (s, t) => new ze(s, t),
    Ui = (s, t) => (console.warn("text.split() is deprecated, import splitText() directly, or text.splitText()"), new ze(s, t));
var Fo = s => {
        let t = "";
        for (let e = 0, i = s.length; e < i; e++)
            if (e + 2 < i && s[e + 1] === "-" && s.charCodeAt(e) < s.charCodeAt(e + 2)) {
                let n = s.charCodeAt(e),
                    o = s.charCodeAt(e + 2);
                for (let r = n; r <= o; r++) t += String.fromCharCode(r);
                e += 2
            } else t += s[e];
        return t
    },
    Oo = {
        lowercase: "a-z",
        uppercase: "A-Z",
        numbers: "0-9",
        symbols: "!%#_|*+=",
        braille: "\u2800-\u28FF",
        blocks: "\u2580-\u259F",
        shades: "\u2591-\u2593"
    },
    Ln = new WeakMap,
    zi = (s = {}) => {
        s || (s = {});
        let t = s.chars,
            e = Zt(s.ease || "linear"),
            i = s.text,
            n = s.from,
            o = s.reversed || !1,
            r = s.perturbation || 0,
            a = s.cursor,
            l = a === !0 ? "_" : typeof a == "number" ? String.fromCharCode(a) : typeof a == "string" ? a : "",
            c = l.length,
            d = s.seed || 0,
            u = s.override !== void 0 ? s.override : !0,
            f = s.revealRate || 60,
            g = 1e3 * E.timeScale / f,
            y = s.settleDuration || 300 * E.timeScale,
            h = s.settleRate || 30,
            m = s.duration,
            b = s.revealDelay,
            T = s.delay,
            _ = s.onChange || Z;
        return (x, L, R, H) => {
            let J = typeof t == "function" ? t(x, L, R) : t || "a-zA-Z0-9!%#_",
                K = Fo(Oo[J] || J),
                z = K.length - 1,
                D = typeof m == "function" ? m(x, L, R) : m,
                M = typeof b == "function" ? b(x, L, R) : b || 0,
                q = typeof T == "function" ? T(x, L, R) : T || 0,
                N = d ? De(d) : De();
            Ln.has(x) || Ln.set(x, x.textContent);
            let F = H ? H._value : x.textContent,
                at = i !== void 0 ? typeof i == "function" ? i(x, L, R) : i : H ? H._value : Ln.get(x),
                p = at === " " || at === "&nbsp;" ? "\xA0" : at,
                C = F === "\xA0" ? 0 : F.length,
                v = p.length,
                w = u === !0 ? K : typeof u == "string" && u.length > 0 ? Fo(Oo[u] || u) : null,
                V = w ? w.length - 1 : 0,
                B = u === " " ? "\xA0" : null,
                k = u === "" ? v : Math.max(C, v),
                Y = D > 0 ? D : (k - 1) * g + y,
                dt = A((Y + M) / E.timeScale, 0) * E.timeScale,
                X = M > 0 ? A(M / dt, 12) : 0,
                et = n === void 0 || n === "auto" ? v < C ? "right" : "left" : n,
                ut = new Int32Array(k);
            if (et === "random") {
                for (let $ = 0; $ < k; $++) ut[$] = $;
                for (let $ = k - 1; $ > 0; $--) {
                    let st = N(0, $),
                        j = ut[$];
                    ut[$] = ut[st], ut[st] = j
                }
            } else {
                let $ = et === "right" ? (u === "" || !C ? k : C) - 1 : et === "center" ? ((u === "" || !C ? k : C) - 1) / 2 : typeof et == "number" ? et : 0,
                    st = Math.abs,
                    j = new Array(k);
                for (let W = 0; W < k; W++) j[W] = W;
                j.sort((W, mt) => st(W - $) - st(mt - $));
                for (let W = 0; W < k; W++) ut[j[W]] = W
            }
            if (o) {
                let $ = k - 1;
                for (let st = 0; st < k; st++) ut[st] = $ - ut[st]
            }
            let it = A(y / Y, 12),
                kt = A((1 - it) / k, 12),
                Dt = c * kt,
                U = A(1e3 * E.timeScale / (h * dt), 12),
                rt = new Float32Array(k),
                xt = new Float32Array(k),
                $t = r > 0 ? r * it : 0;
            for (let $ = 0; $ < k; $++) {
                let st = $t > 0 ? (N(0, 2e3) - 1e3) / 1e3 * $t : 0,
                    j = $t > 0 ? (N(0, 2e3) - 1e3) / 1e3 * $t : 0;
                rt[$] = ut[$] * kt + st, xt[$] = Math.ceil((rt[$] + it + j) / U) * U
            }
            if (v < k && et !== "left" && et !== "right" && et !== "random") {
                let $ = 0;
                for (let W = v; W < k; W++) xt[W] > $ && ($ = xt[W]);
                let st = new Array(v);
                for (let W = 0; W < v; W++) st[W] = W;
                st.sort((W, mt) => ut[W] - ut[mt]);
                let j = (1 - $) / v;
                for (let W = 0; W < v; W++) {
                    let mt = $ + W * j;
                    mt > xt[st[W]] && (xt[st[W]] = mt)
                }
            }
            let ft = new Array(k);
            for (let $ = 0; $ < k; $++) ft[$] = K[N(0, z)];
            let pt = w ? w === K ? ft : new Array(k) : null;
            if (pt && pt !== ft)
                for (let $ = 0; $ < k; $++) pt[$] = B || w[N(0, w.length - 1)];
            let St = F;
            if (!H) {
                if (u === "") St = "";
                else if (w) {
                    St = "";
                    for (let $ = 0; $ < C; $++) St += F[$] === " " ? " " : pt[$]
                }
            }
            let Ct = -1,
                Xt = -1,
                ht = "",
                _t = u !== "",
                Q = !!w,
                Tt = c > 0;
            return {
                from: 0,
                to: 1,
                duration: dt,
                delay: q,
                ease: "linear",
                modifier: $ => {
                    if ($ === Ct) return ht;
                    if (Ct = $, q > 0 && $ <= 0) return ht = F, F;
                    if ($ <= 0) return ht = St, St;
                    if ($ >= 1) return ht = p, p;
                    ht = "";
                    let st = $ / U | 0,
                        j = st !== Xt;
                    j && (Xt = st);
                    let W = X > 0 ? ($ - X) / (1 - X) : $,
                        mt = W > 0 ? e(W) : 0;
                    for (let Et = 0; Et < k; Et++) {
                        let Jt = rt[Et],
                            Ie = xt[Et];
                        if (mt >= Ie) {
                            Et < v && (ht += p[Et]);
                            continue
                        }
                        if (mt <= 0 || mt < Jt) {
                            _t && Et < C && (Q ? F[Et] === " " ? ht += " " : (j && (pt[Et] = B || w[N(0, V)]), ht += pt[Et]) : ht += F[Et]);
                            continue
                        }
                        Et < v && p[Et] === " " || Et < C && F[Et] === " " ? ht += " " : Tt && mt - Jt < Dt ? ht += l[c - 1 - ((mt - Jt) / kt | 0)] : (j && (ft[Et] = K[N(0, z)]), ht += ft[Et])
                    }
                    return j && _(ht, mt), ht
                }
            }
        }
    };
var Sr = {
        minM: "(min-width: 900px)",
        isM: "(min-width: 900px) and (max-width: 1199px)",
        minL: "(min-width: 1200px)"
    },
    Yi = ci({
        mediaQueries: Sr
    });
Yi.add(s => {
    let t = document.querySelector("#site-header"),
        e = document.querySelector("#site-menu"),
        i = document.querySelector("#toggle-site-menu");
    if (s.add("preventDefault", n => {
            t.contains(n.target) || (n.preventDefault(), s.methods.closeSiteMenu())
        }), s.add("preventScroll", () => {
            document.documentElement.style.overflow = "hidden", document.body.style.position = "fixed", document.body.style.top = `-${window.scrollY}px`, document.addEventListener("touchstart", s.methods.preventDefault, {
                passive: !1
            })
        }), s.add("allowScroll", () => {
            let n = document.body.style.top;
            document.removeEventListener("touchstart", s.methods.preventDefault), document.documentElement.style.overflow = "", document.body.style.position = "", document.body.style.top = "", window.scrollTo(0, parseInt(n || "0") * -1)
        }), !s.matches.minL) {
        let [n, o] = i.querySelectorAll("rect"), {
            offsetWidth: r,
            offsetHeight: a
        } = e;
        Bt.set(e, {
            width: r * 2,
            willChange: "transform"
        });
        let l = Be({
            defaults: {
                duration: 250
            },
            autoplay: !1
        }).add(n, {
            rotate: ["45deg", "0deg"],
            y: [12, 8]
        }, 0).add(o, {
            rotate: ["-45deg", "0deg"],
            y: [12, 14]
        }, 0).add(t, {
            "--overlay-opacity": [1, 0]
        }, 0);
        s.data.draggable = li(e, {
            container: [0, r * 2, a, r],
            x: {
                snap: r
            },
            y: !1,
            velocityMultiplier: 4,
            minVelocity: 2,
            onUpdate: c => {
                l.progress = c.progressX;
                let d = c.progressX === 0,
                    u = c.progressX === 1;
                e.classList.toggle("is-active", d), d && s.methods.preventScroll(), u && s.methods.allowScroll()
            }
        }), s.data.draggable.progressX = 1
    }
    return s.add("openSiteMenu", () => {
        s.matches.minL || e.classList.contains("is-active") || Ce(s.data.draggable, {
            progressX: 0,
            ease: "outElastic(.75, 1.25)",
            duration: 500
        })
    }), s.add("closeSiteMenu", () => {
        s.matches.minL || !e.classList.contains("is-active") || Ce(s.data.draggable, {
            progressX: 1,
            ease: "inOut(2.5)",
            duration: 250
        })
    }), s.add("toggleSiteMenu", () => {
        if (s.matches.minL || !e) return;
        e.classList.contains("is-active") ? s.methods.closeSiteMenu() : s.methods.openSiteMenu()
    }), () => {
        e && (e.classList.remove("is-active"), s.methods.allowScroll())
    }
});

function _r(s) {
    s.preventDefault();
    let t = s.ctrlKey;
    s.key === "g" && t && document.body.classList.toggle("show-grid")
}

function wr(s) {
    let t = s.target,
        e = t.closest("#toggle-site-menu");
    e && Yi.methods.toggleSiteMenu(e), !document.getElementById("site-menu").contains(t) && !e && Yi.methods.closeSiteMenu();
    let n = s.target.closest("a[title].sponsor");
    if (n) {
        let r = n.getAttribute("title"),
            a = n.parentElement ? .getAttribute("path") || "not_set";
        gtag("event", "sponsor_click", {
            sponsor_type: a,
            sponsor_name: r,
            sponsor_url: n.href,
            link_domain: new URL(n.href).hostname
        })
    }
    let o = s.target.closest('a.footer-notice-link[href*="awwwards"]');
    o && gtag("event", "sponsor_click", {
        sponsor_type: "awwwards",
        sponsor_name: "awwwards",
        link_url: o.href,
        link_domain: new URL(o.href).hostname
    })
}
document.addEventListener("keyup", _r, !1);
document.addEventListener("click", wr, !1);

function Cr() {
    let s = this.value;
    s && (window.location.href = s)
}
var Er = document.querySelector("#docs-versions select"),
    Ar = document.querySelectorAll("#docs-versions option");
Ar[0].textContent = window.AnimeJS[0].version;
Er.addEventListener("change", Cr, !1);
var $n = class extends HTMLElement {
    constructor() {
        super(), this.abortController = null
    }
    static get observedAttributes() {
        return ["path", "location"]
    }
    connectedCallback() {
        this.loadSponsors()
    }
    disconnectedCallback() {
        this.abortController && (this.abortController.abort(), this.abortController = null)
    }
    attributeChangedCallback(t, e, i) {
        e !== i && this.loadSponsors()
    }
    get path() {
        return this.getAttribute("path") || "github-sponsors"
    }
    get location() {
        return this.getAttribute("location") || "home"
    }
    async loadSponsors() {
        this.abortController && this.abortController.abort(), this.abortController = new AbortController;
        try {
            let t = await fetch(window.paths[this.path], {
                signal: this.abortController.signal
            });
            if (!t.ok) throw new Error(`HTTP error! status: ${t.status}`);
            let e = await t.text();
            this.innerHTML = e;
            let i = this.querySelectorAll(".sponsor"),
                n = this.location === "docs";
            for (let o = 0, r = i.length; o < r; o++) {
                let a = i[o],
                    l = a.dataset.urlParams,
                    c = a.dataset.urlParamsDocs,
                    d = "?ref=animejs" + (n && c ? c : l);
                a.href += d
            }
            this.abortController = null
        } catch (t) {
            if (t.name === "AbortError") return null;
            console.error("Error loading sponsors:", t), this.innerHTML = "", this.abortController = null
        }
    }
};
customElements.define("sponsors-list", $n);
var Nn = class extends HTMLElement {
    constructor() {
        super(), this.heartsAnimation = null, this.pointerAnimation = null, this.iconAnimation = null, this.pointerX = 0, this.pointerY = 0, this.spread = 16, this.$svg = null, this.interval = 100, this.duration = 1200, this.randomTimer = null, this.autoplay = !1, this.isHovering = !1, this.isVisible = !1, this.observer = null, this.particlePool = [], this.poolSize = 24
    }
    connectedCallback() {
        let t = this.querySelector("svg.icon");
        if (t) this.$svg = t;
        else {
            let e = document.createElement("div");
            e.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="icon"><g id="sponsor" fill="none" fill-rule="evenodd"><path fill="currentColor" fill-rule="nonzero" d="M12 18.445a.778.778 0 0 1-.34-.078C11.39 18.235 5 15.077 5 9.889a3.889 3.889 0 0 1 6.638-2.75L12 7.5l.362-.361A3.889 3.889 0 0 1 19 9.889c0 5.17-6.387 8.344-6.66 8.478a.778.778 0 0 1-.34.078z"></path></g></svg>', this.$svg = e.querySelector("svg")
        }
        this.getAttribute("data-color") || this.setAttribute("data-color", "0"), this.getAttribute("interval") && (this.interval = +this.getAttribute("interval")), this.getAttribute("duration") && (this.duration = +this.getAttribute("duration")), this.initParticlePool(), this.heartsAnimation = Cs({
            autoplay: !1,
            duration: this.interval,
            loop: !0,
            onLoop: () => this.emitParticle()
        }), this.autoplay = this.getAttribute("autoplay") !== null, this.autoplay && this.initObserver(), this.addEventListener("mouseenter", this), this.addEventListener("mousemove", this), this.addEventListener("mouseleave", this)
    }
    initObserver() {
        this.observer = new IntersectionObserver(t => {
            let e = t[0];
            this.isVisible = e.isIntersecting, this.isVisible && !this.isHovering ? this.startRandomAnimation() : this.isVisible || this.stopRandomAnimation()
        }, {
            threshold: 0
        }), this.observer.observe(this)
    }
    initParticlePool() {
        for (let t = 0; t < this.poolSize; t++) {
            let e = this.$svg.cloneNode(!0);
            e.style.cssText = "position: absolute; top: -12px; left: -12px; mix-blend-mode: plus-lighter; visibility: hidden;", e.classList.add("particle"), this.appendChild(e), this.particlePool.push({
                el: e,
                inUse: !1
            })
        }
    }
    getParticle() {
        let t = this.particlePool.find(e => !e.inUse);
        return t ? (t.inUse = !0, t.el.style.visibility = "visible", t) : null
    }
    releaseParticle(t) {
        t.inUse = !1, t.el.style.visibility = "hidden"
    }
    emitParticle() {
        let t = this.getParticle();
        if (!t) return;
        let e = t.el,
            i = Bt.randomPick(["-=", "+="]),
            n = i === "-=" ? "+=" : "-=";
        Ce(e, {
            opacity: {
                to: [0, 1],
                duration: 150
            },
            translateX: [this.pointerX + Bt.random(-this.spread, this.spread), i + (5 + Bt.random(-2, 2, 2)), n + (6 + Bt.random(-2, 2, 2)), i + (4 + Bt.random(-2, 2, 2))],
            translateY: [{
                from: this.pointerY + Bt.random(-5, 5),
                to: "-=" + Bt.random(30, 50)
            }],
            scale: [{
                from: 0,
                to: .85
            }, {
                to: 0
            }],
            duration: this.duration,
            onComplete: () => this.releaseParticle(t)
        })
    }
    startRandomAnimation() {
        if (this.isHovering || !this.isVisible) return;
        let {
            width: t,
            height: e
        } = this.getBoundingClientRect();
        this.pointerAnimation && this.pointerAnimation.revert();
        let i = Bt.randomPick([0, 1]),
            n = (1 - re.out(2)(Bt.random(0, 1, 3))) * t * .5,
            o = i === 0 ? n : t - n,
            r = Bt.random(e * 1.2, 0);
        this.pointerAnimation = Ce(this, {
            pointerX: [o, o],
            pointerY: [r, r],
            ease: "linear",
            duration: this.interval,
            onBegin: () => this.heartsAnimation.play(),
            onComplete: () => {
                this.heartsAnimation.pause(), this.randomTimer = Cs({
                    duration: 10,
                    onComplete: () => this.startRandomAnimation()
                })
            }
        })
    }
    stopRandomAnimation() {
        this.randomTimer && (this.randomTimer.revert(), this.randomTimer = null), this.pointerAnimation && (this.pointerAnimation.revert(), this.pointerAnimation = null), this.heartsAnimation ? .pause()
    }
    disconnectedCallback() {
        this.removeEventListener("mouseenter", this), this.removeEventListener("mousemove", this), this.removeEventListener("mouseleave", this), this.observer && (this.observer.disconnect(), this.observer = null), this.stopRandomAnimation(), this.heartsAnimation && this.heartsAnimation.revert(), this.iconAnimation && this.iconAnimation.revert(), this.particlePool = [], Bt.remove(this.$svg)
    }
    mousemove(t) {
        let {
            width: e,
            height: i,
            left: n,
            top: o
        } = this.getBoundingClientRect();
        this.pointerX = Bt.clamp(t.clientX - n, this.spread, e - this.spread), this.pointerY = Bt.clamp(t.clientY - o, 0, i)
    }
    mouseenter(t) {
        this.isHovering = !0, this.stopRandomAnimation(), this.mousemove(t), this.iconAnimation && this.iconAnimation.revert(), this.iconAnimation = Ce(this.$svg, {
            scale: [1, 1.25, 1],
            loop: !0,
            duration: 900
        }), this.heartsAnimation.play()
    }
    mouseleave() {
        this.isHovering = !1, this.iconAnimation && this.iconAnimation.revert(), this.iconAnimation = Ce(this.$svg, {
            scale: 1,
            duration: 500
        }), this.heartsAnimation.pause(), this.autoplay && this.isVisible && this.startRandomAnimation()
    }
    handleEvent(t) {
        this[t.type] && this[t.type](t)
    }
};
customElements.define("sponsor-button", Nn);
var kn = class extends HTMLElement {
    constructor() {
        super()
    }
    static get observedAttributes() {
        return ["path", "goal"]
    }
    connectedCallback() {
        this.innerHTML = `
      <div class="box-heading">
        <h3>Funding goal</h3>
        <div class="funding-level-status"><span class="percents">0%</span></div>
      </div>
      <div class="chart">
        <div style="width: 0%" class="chart-bar color-red"></div>
      </div>
      <div class="sponsors-list">Loading sponsors...</div>
      <p>
        Support the project, <sponsor-button><a href="https://github.com/sponsors/juliangarnier" target="_blank">become a sponsor</a></sponsor-button>.
      </p>
    `, this.$percents = this.querySelector(".percents"), this.$chartBar = this.querySelector(".chart-bar"), this.$sponsorsList = this.querySelector(".sponsors-list"), this.loadSponsors()
    }
    get path() {
        return this.getAttribute("path") || "github-sponsors"
    }
    get goal() {
        return this.getAttribute("goal") || "500"
    }
    async loadSponsors() {
        try {
            let t = await fetch(window.paths[this.path]);
            if (!t.ok) throw new Error(`HTTP error! status: ${t.status}`);
            let e = await t.text(),
                i = document.createElement("div");
            i.innerHTML = e;
            let n = i.querySelectorAll(".sponsor"),
                o = n.length,
                r = +this.goal,
                a = o > 50 ? 50 : o,
                l = o / r * 100 + "%";
            this.$percents.innerHTML = l, this.$chartBar.style.width = l, this.$sponsorsList.innerHTML = "";
            for (let c = 0; c < a; c++) this.$sponsorsList.appendChild(n[c]);
            Be().add(this.$chartBar, {
                width: {
                    from: "0%"
                }
            }).add(this.$percents, {
                innerHTML: {
                    from: "0%"
                },
                modifier: Bt.round(0)
            }, 0).add(this.$sponsorsList.querySelectorAll(".sponsor"), {
                opacity: {
                    to: [0, 1],
                    duration: 1500,
                    ease: "linear"
                },
                scale: [{
                    from: .9,
                    to: 1.2,
                    duration: 250
                }, {
                    to: 1
                }],
                delay: ms(1)
            }, 0).init()
        } catch (t) {
            this.innerHTML = `Error loading sponsors: ${t.message}`
        }
    }
};
customElements.define("funding-level", kn);
var Dn = class extends HTMLElement {
    constructor() {
        super()
    }
    connectedCallback() {
        this.url = this.getAttribute("url") || "", this.setupFormListener()
    }
    setupFormListener() {
        let t = this.querySelector("form"),
            e = this.querySelector(".email-signup-fields"),
            i = this.querySelector(".email-signup-success"),
            n = this.querySelector(".email-signup-error");
        t && t.addEventListener("submit", o => {
            o.preventDefault(), t.classList.add("is-pending");
            let r = this.querySelector('input[type="email"]'),
                a = r ? r.value : "",
                l = new FormData;
            l.append("email", a), fetch(this.url, {
                method: "POST",
                body: l
            }).then(c => {
                if (c.ok) i.classList.add("is-active"), t.classList.remove("is-pending"), e.classList.remove("is-active");
                else throw new Error("Network response was not ok")
            }).catch(c => {
                n.classList.add("is-active"), t.classList.remove("is-pending"), e.classList.remove("is-active"), setTimeout(() => {
                    n.classList.remove("is-active"), t.classList.remove("is-pending"), e.classList.add("is-active")
                }, 2e4)
            })
        })
    }
};
customElements.define("email-signup", Dn);
export {
    Gs as a, Cs as b, re as c, Ce as d, Be as e, vo as f, Ze as g, li as h, ci as i, xo as j, fi as k, pn as l, gi as m, ms as n, Bt as o, Fi as p, Tn as q, Xi as r, xr as s, Sr as t
};
/*! Bundled license information:

animejs/dist/modules/core/transforms.js:
animejs/dist/modules/core/colors.js:
animejs/dist/modules/core/values.js:
animejs/dist/modules/core/render.js:
animejs/dist/modules/core/styles.js:
animejs/dist/modules/core/clock.js:
animejs/dist/modules/core/targets.js:
animejs/dist/modules/core/units.js:
  (**
   * Anime.js - core - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/animation/additive.js:
animejs/dist/modules/animation/composition.js:
animejs/dist/modules/animation/animation.js:
  (**
   * Anime.js - animation - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/engine/engine.js:
  (**
   * Anime.js - engine - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/timer/timer.js:
  (**
   * Anime.js - timer - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/easings/none.js:
animejs/dist/modules/easings/eases/parser.js:
animejs/dist/modules/easings/spring/index.js:
animejs/dist/modules/easings/cubic-bezier/index.js:
animejs/dist/modules/easings/steps/index.js:
animejs/dist/modules/easings/linear/index.js:
animejs/dist/modules/easings/irregular/index.js:
animejs/dist/modules/easings/index.js:
  (**
   * Anime.js - easings - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/timeline/position.js:
animejs/dist/modules/timeline/timeline.js:
  (**
   * Anime.js - timeline - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/animatable/animatable.js:
  (**
   * Anime.js - animatable - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/waapi/composition.js:
animejs/dist/modules/waapi/waapi.js:
  (**
   * Anime.js - waapi - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/utils/target.js:
animejs/dist/modules/utils/time.js:
animejs/dist/modules/utils/chainable.js:
animejs/dist/modules/utils/random.js:
animejs/dist/modules/utils/stagger.js:
animejs/dist/modules/utils/index.js:
  (**
   * Anime.js - utils - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/draggable/draggable.js:
  (**
   * Anime.js - draggable - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/scope/scope.js:
  (**
   * Anime.js - scope - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/events/scroll.js:
  (**
   * Anime.js - events - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/layout/layout.js:
  (**
   * Anime.js - layout - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/svg/helpers.js:
animejs/dist/modules/svg/motionpath.js:
animejs/dist/modules/svg/drawable.js:
animejs/dist/modules/svg/morphto.js:
animejs/dist/modules/svg/index.js:
  (**
   * Anime.js - svg - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/text/split.js:
animejs/dist/modules/text/scramble.js:
animejs/dist/modules/text/index.js:
  (**
   * Anime.js - text - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)

animejs/dist/modules/index.js:
  (**
   * Anime.js - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)
*/