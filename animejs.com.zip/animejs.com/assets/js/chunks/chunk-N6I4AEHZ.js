import {
    Aa as _,
    wa as rt,
    za as u
} from "./chunk-FX45FQRC.js";
import {
    H as it,
    I as j,
    L as et,
    M as st,
    N as ot,
    O as L,
    ga as nt,
    y as p
} from "./chunk-CPVC3KGU.js";
var kt = t => !!(t && !t.nodeType && (t.isObject3D || t.isMaterial || t.isTexture || t.isFog || t.isFogExp2 || t.isUniformNode || t.isColor || t.isVector2 || t.isVector3 || t.isVector4 || t.isAnimejsInstanceProxy)),
    g = rt(kt);
var f = 1 / 255,
    $ = {
        X: "x",
        Y: "y",
        Z: "z",
        W: "w"
    },
    h = 0,
    X = 1,
    H = 2,
    Z = 0,
    R = 1,
    U = 2,
    a = {
        kind: 0,
        path: 0,
        base: "",
        axis: "x"
    };

function E(t, r, i, e, s, o, n) {
    if (r !== 0) {
        let c = Math.tan(u(r));
        t[4] += t[0] * c, t[5] += t[1] * c, t[6] += t[2] * c
    }
    if (i !== 0) {
        let c = Math.tan(u(i));
        t[0] += t[4] * c, t[1] += t[5] * c, t[2] += t[6] * c
    }
    if (e !== 0) {
        let c = Math.tan(u(e));
        t[0] += t[8] * c, t[1] += t[9] * c, t[2] += t[10] * c
    }(s !== 0 || o !== 0 || n !== 0) && (t[12] += s - (t[0] * s + t[4] * o + t[8] * n), t[13] += o - (t[1] * s + t[5] * o + t[9] * n), t[14] += n - (t[2] * s + t[6] * o + t[10] * n))
}

function A(t) {
    return t ? `#${t.getHexString(p)}` : null
}

function k(t, r) {
    return t ? r === "x" || r === "y" ? !!(t.isVector2 || t.isVector3 || t.isVector4) : r === "z" ? !!(t.isVector3 || t.isVector4) : !!t.isVector4 : !1
}

function K(t, r) {
    let i = t[r];
    if (i !== void 0) {
        if (i && i.isColor) return a.kind = Z, a.path = h, a;
        if (i && i.isUniformNode) {
            let n = i.value;
            return n && n.isColor ? (a.kind = Z, a.path = H, a) : typeof n == "number" || typeof n == "boolean" ? (a.kind = R, a.path = H, a) : null
        }
        return typeof i == "number" || typeof i == "boolean" ? (a.kind = R, a.path = h, a) : null
    }
    let e = t.uniforms,
        s = e && e[r];
    if (s) {
        let n = s.value;
        if (n && n.isColor) return a.kind = Z, a.path = X, a;
        if (typeof n == "number") return a.kind = R, a.path = X, a
    }
    let o = $[r[r.length - 1]];
    if (o) {
        let n = r.slice(0, -1);
        if (k(t[n], o)) return a.kind = U, a.path = h, a.base = n, a.axis = o, a;
        let c = t[n];
        if (c && c.isUniformNode && k(c.value, o)) return a.kind = U, a.path = H, a.base = n, a.axis = o, a;
        let w = e && e[n];
        if (w && k(w.value, o)) return a.kind = U, a.path = X, a.base = n, a.axis = o, a
    }
    return null
}

function C(t, r, i) {
    if (i === h) return t[r];
    if (i === X) {
        let s = t.uniforms,
            o = s && s[r];
        return o ? o.value : null
    }
    let e = t[r];
    return e ? e.value : null
}

function at(t, r, i, e) {
    if (e === h) {
        t[r] = i;
        return
    }
    if (e === X) {
        let o = t.uniforms,
            n = o && o[r];
        n && (n.value = i);
        return
    }
    let s = t[r];
    s && (s.value = i)
}

function x(t, r, i, e) {
    if (e === void 0 && (e = 0), !t) return e;
    let s = Array.isArray(t) ? t[0] : t;
    if (!s) return e;
    let o = C(s, r, i);
    return o ? ? e
}

function P(t, r, i, e) {
    if (t)
        if (Array.isArray(t))
            for (let s = 0, o = t.length; s < o; s++) at(t[s], r, i, e);
        else at(t, r, i, e)
}

function v(t, r, i) {
    if (!t) return null;
    let e = Array.isArray(t) ? t[0] : t;
    return A(e ? C(e, r, i) : null)
}

function T(t, r, i, e) {
    if (!t) return;
    let s = i[0] * f,
        o = i[1] * f,
        n = i[2] * f;
    if (Array.isArray(t))
        for (let c = 0, w = t.length; c < w; c++) {
            let Y = C(t[c], r, e);
            Y && Y.setRGB(s, o, n, p)
        } else {
            let c = C(t, r, e);
            c && c.setRGB(s, o, n, p)
        }
}

function ct(t, r, i, e) {
    if (!t) return 0;
    let s = Array.isArray(t) ? t[0] : t,
        o = s ? C(s, r, e) : null;
    return o ? o[i] : 0
}

function lt(t, r, i, e, s) {
    if (t)
        if (Array.isArray(t))
            for (let o = 0, n = t.length; o < n; o++) {
                let c = C(t[o], r, s);
                c && (c[i] = e)
            } else {
                let o = C(t, r, s);
                o && (o[i] = e)
            }
}
var wt = t => t,
    Ct = t => t.material,
    At = [{}, {}, {}],
    xt = [{}, {}, {}],
    Ot = [{}, {}, {}],
    St = [{}, {}, {}],
    Rt = [{}, {}, {}],
    Pt = [{}, {}, {}],
    ft = (t, r, i, e, s, o) => {
        let n = r.path;
        if (r.kind === Z) {
            let y = e[n];
            return y[t] || (y[t] = {
                get: m => v(i(m), t, n),
                set: (m, tt, dt) => T(i(m), t, dt._numbers, n)
            })
        }
        if (r.kind === R) {
            let y = s[n];
            return y[t] || (y[t] = {
                get: m => x(i(m), t, n),
                set: (m, tt) => P(i(m), t, tt, n)
            })
        }
        let c = r.base,
            w = r.axis,
            Y = o[n];
        return Y[t] || (Y[t] = {
            get: y => ct(i(y), c, w, n),
            set: (y, m) => lt(i(y), c, w, m, n)
        })
    };
g.registerPropertyResolver((t, r) => {
    let i = K(t, r);
    return !i || i.kind === R && i.path === h ? null : ft(r, i, wt, At, xt, Ot)
});
g.registerPropertyResolver((t, r) => {
    if (t[r] !== void 0) return null;
    let i = t.material;
    if (!i) return null;
    let e = Array.isArray(i) ? i[0] : i;
    if (!e) return null;
    let s = K(e, r);
    return s ? ft(r, s, Ct, St, Rt, Pt) : null
});
var gt = {
        rotation: 1,
        angle: 1
    },
    ht = {};
g.registerPropertyResolver((t, r) => !gt[r] || typeof t[r] != "number" ? null : ht[r] || (ht[r] = {
    get: i => _(i[r]),
    set: (i, e) => {
        i[r] = u(e)
    }
}));
var ut = {};
g.registerPropertyResolver((t, r) => {
    let i = $[r[r.length - 1]];
    if (!i) return null;
    let e = r.slice(0, -1);
    if (!gt[e]) return null;
    let s = t[e];
    return !s || !s.isEuler ? null : ut[r] || (ut[r] = {
        get: o => _(o[e][i]),
        set: (o, n) => {
            o[e][i] = u(n)
        }
    })
});
var M = g.registerTargetAdapter(t => !!(t && t.isUniformNode));
M.registerProperty("color", t => A(t.value), (t, r, i) => {
    let e = i._numbers;
    t.value.setRGB(e[0] * f, e[1] * f, e[2] * f, p)
}, t => !!(t.value && t.value.isColor));
M.registerProperty("x", t => t.value.x, (t, r) => {
    t.value.x = r
}, t => k(t.value, "x"));
M.registerProperty("y", t => t.value.y, (t, r) => {
    t.value.y = r
}, t => k(t.value, "y"));
M.registerProperty("z", t => t.value.z, (t, r) => {
    t.value.z = r
}, t => k(t.value, "z"));
M.registerProperty("w", t => t.value.w, (t, r) => {
    t.value.w = r
}, t => k(t.value, "w"));
var _t = t => t.isLight ? t : t.material,
    V = Symbol("animejs.skewOrigin"),
    q = Symbol("animejs.opacity");

function I(t, r) {
    if (r === void 0)
        if (t.material) r = x(t.material, "opacity", h, 1);
        else {
            let e = t[q];
            r = e === void 0 ? 1 : e
        }
    let i = t.scale;
    t.visible = !!(r && i.x && i.y && i.z)
}

function pt(t) {
    let r = t[V];
    if (r) return r;
    r = t[V] = {
        skewX: 0,
        skewY: 0,
        skewZ: 0,
        originX: 0,
        originY: 0,
        originZ: 0
    };
    let i = t.updateMatrix;
    return t.updateMatrix = function() {
        i.call(this);
        let e = this[V];
        (e.skewX !== 0 || e.skewY !== 0 || e.skewZ !== 0 || e.originX !== 0 || e.originY !== 0 || e.originZ !== 0) && E(this.matrix.elements, e.skewX, e.skewY, e.skewZ, e.originX, e.originY, e.originZ)
    }, r
}
var l = g.registerTargetAdapter(t => t instanceof ot);
l.registerProperty("x", t => t.position.x, (t, r) => {
    t.position.x = r
});
l.registerProperty("y", t => t.position.y, (t, r) => {
    t.position.y = r
});
l.registerProperty("z", t => t.position.z, (t, r) => {
    t.position.z = r
});
l.registerProperty("rotateX", t => _(t.rotation.x), (t, r) => {
    t.rotation.x = u(r)
});
l.registerProperty("rotateY", t => _(t.rotation.y), (t, r) => {
    t.rotation.y = u(r)
});
l.registerProperty("rotateZ", t => _(t.rotation.z), (t, r) => {
    t.rotation.z = u(r)
});
l.registerProperty("scaleX", t => t.scale.x, (t, r) => {
    t.scale.x = r, I(t)
});
l.registerProperty("scaleY", t => t.scale.y, (t, r) => {
    t.scale.y = r, I(t)
});
l.registerProperty("scaleZ", t => t.scale.z, (t, r) => {
    t.scale.z = r, I(t)
});
l.registerProperty("scale", t => t.scale.x, (t, r) => {
    t.scale.x = r, t.scale.y = r, t.scale.z = r, I(t)
});
l.registerProperty("visible", t => t.visible, (t, r) => {
    t.visible = !!r
});
l.registerProperty("opacity", t => {
    if (t.material) return x(t.material, "opacity", h, 1);
    let r = t[q];
    return r === void 0 ? 1 : r
}, (t, r) => {
    t.material ? P(t.material, "opacity", r, h) : t[q] = r, I(t, r)
}, t => !t.isLight);
l.registerProperty("color", t => v(_t(t), "color", h), (t, r, i) => T(_t(t), "color", i._numbers, h));
l.registerProperty("groundColor", t => v(t, "groundColor", h), (t, r, i) => T(t, "groundColor", i._numbers, h), t => !!t.groundColor);
l.registerProperty("background", t => {
    let r = t.background;
    return r && r.isColor ? A(r) : "#000000"
}, (t, r, i) => {
    let e = t,
        s = e.background;
    (!s || !s.isColor) && (s = new L, e.background = s);
    let o = i._numbers;
    s.setRGB(o[0] * f, o[1] * f, o[2] * f, p)
}, t => !!t.isScene);
var z = (t, r, i, e) => {
    l.registerProperty(t, s => s[r](), (s, o) => {
        s[i](o)
    }, s => !!s[e])
};
z("volume", "getVolume", "setVolume", "setVolume");
z("refDistance", "getRefDistance", "setRefDistance", "setRefDistance");
z("rolloffFactor", "getRolloffFactor", "setRolloffFactor", "setRefDistance");
z("maxDistance", "getMaxDistance", "setMaxDistance", "setRefDistance");
z("focalLength", "getFocalLength", "setFocalLength", "setFocalLength");
var d = (t, r) => {
        l.registerProperty(t, i => i[t], (i, e) => {
            i[t] = e, i.updateProjectionMatrix()
        }, r)
    },
    yt = t => !!t.isPerspectiveCamera,
    N = t => !!t.isOrthographicCamera;
d("fov", yt);
d("aspect", yt);
d("left", N);
d("right", N);
d("top", N);
d("bottom", N);
var b = (t, r) => {
    l.registerProperty(t, i => {
        let e = i[V];
        return e ? e[r] : 0
    }, (i, e) => {
        pt(i)[r] = e
    })
};
b("skewX", "skewX");
b("skewY", "skewY");
b("skewZ", "skewZ");
b("transformOriginX", "originX");
b("transformOriginY", "originY");
b("transformOriginZ", "originZ");
l.registerProperty("transformOrigin", t => {
    let r = t[V];
    return r ? `${r.originX} ${r.originY} ${r.originZ}` : "0 0 0"
}, (t, r, i) => {
    let e = pt(t),
        s = i._numbers;
    e.originX = s[0], e.originY = s[1], e.originZ = s[2]
});
var W = t => !!t.isPerspectiveCamera || !!t.isOrthographicCamera;
d("near", W);
d("far", W);
d("zoom", W);
var O = t => !!(t._skewX || t._skewY || t._skewZ || t._originX || t._originY || t._originZ),
    B = 1,
    G = 2,
    F = 4,
    S = 8,
    Q = new WeakMap,
    J = class {
        constructor(r) {
            this.mesh = r, this.hasInstanceMatrix = "instanceMatrix" in r, this.instances = [], this.dirtyList = [], this.userOnBeforeRender = r.onBeforeRender || null, this.chainedHandler = bt(this), Object.defineProperty(r, "onBeforeRender", {
                configurable: !0,
                get: () => this.chainedHandler,
                set: i => {
                    this.userOnBeforeRender = i
                }
            })
        }
        flush() {
            let r = this.dirtyList;
            if (r.length !== 0) {
                for (let i = 0, e = r.length; i < e; i++) r[i]._flush();
                this.hasInstanceMatrix && (this.mesh.instanceMatrix.needsUpdate = !0), r.length = 0
            }
        }
    };

function bt(t) {
    return function(r, i, e, s, o, n) {
        t.flush();
        let c = t.userOnBeforeRender;
        c && c.call(t.mesh, r, i, e, s, o, n)
    }
}
var D = class {
    constructor(r, i) {
        this.isAnimejsInstanceProxy = !0, this.parent = r.mesh, this.id = i, this._position = new j, this._rotation = new st(0, 0, 0, "XYZ"), this._scale = new j(1, 1, 1), this._matrix = new et, this._quat = new it, this._color = new L, this._dirty = 0, this._skewX = 0, this._skewY = 0, this._skewZ = 0, this._originX = 0, this._originY = 0, this._originZ = 0, this._hasSkewOrigin = !1, this._dirtyList = r.dirtyList;
        let e = r.mesh;
        this._hasSetColor = "setColorAt" in e, this._hasSetVisible = "setVisibleAt" in e, this._hasGetVisible = "getVisibleAt" in e, e.getMatrixAt(i, this._matrix), this._matrix.elements[15] === 0 && this._matrix.identity(), this._matrix.decompose(this._position, this._quat, this._scale), this._rotation.setFromQuaternion(this._quat, "XYZ"), "getColorAt" in e && "instanceColor" in e && e.instanceColor && e.getColorAt(i, this._color)
    }
    _markDirty(r) {
        this._dirty === 0 && this._dirtyList.push(this), this._dirty |= r
    }
    _flush() {
        let r = this._dirty;
        if (!r) return;
        let i = this._matrix,
            e = this._position;
        if (r === B && !this._hasSkewOrigin) {
            let s = i.elements;
            s[12] = e.x, s[13] = e.y, s[14] = e.z
        } else {
            let s = this._quat;
            r & G && s.setFromEuler(this._rotation), i.compose(e, s, this._scale), this._hasSkewOrigin && E(i.elements, this._skewX, this._skewY, this._skewZ, this._originX, this._originY, this._originZ)
        }
        this.parent.setMatrixAt(this.id, i), this._dirty = 0
    }
    get x() {
        return this._position.x
    }
    set x(r) {
        this._position.x = r, this._markDirty(B)
    }
    get y() {
        return this._position.y
    }
    set y(r) {
        this._position.y = r, this._markDirty(B)
    }
    get z() {
        return this._position.z
    }
    set z(r) {
        this._position.z = r, this._markDirty(B)
    }
    get rotateX() {
        return _(this._rotation.x)
    }
    set rotateX(r) {
        this._rotation.x = u(r), this._markDirty(G)
    }
    get rotateY() {
        return _(this._rotation.y)
    }
    set rotateY(r) {
        this._rotation.y = u(r), this._markDirty(G)
    }
    get rotateZ() {
        return _(this._rotation.z)
    }
    set rotateZ(r) {
        this._rotation.z = u(r), this._markDirty(G)
    }
    get scaleX() {
        return this._scale.x
    }
    set scaleX(r) {
        this._scale.x = r, this._markDirty(F)
    }
    get scaleY() {
        return this._scale.y
    }
    set scaleY(r) {
        this._scale.y = r, this._markDirty(F)
    }
    get scaleZ() {
        return this._scale.z
    }
    set scaleZ(r) {
        this._scale.z = r, this._markDirty(F)
    }
    get scale() {
        return this._scale.x
    }
    set scale(r) {
        let i = this._scale;
        i.x = r, i.y = r, i.z = r, this._markDirty(F)
    }
    get skewX() {
        return this._skewX
    }
    set skewX(r) {
        this._skewX = r, this._hasSkewOrigin = O(this), this._markDirty(S)
    }
    get skewY() {
        return this._skewY
    }
    set skewY(r) {
        this._skewY = r, this._hasSkewOrigin = O(this), this._markDirty(S)
    }
    get skewZ() {
        return this._skewZ
    }
    set skewZ(r) {
        this._skewZ = r, this._hasSkewOrigin = O(this), this._markDirty(S)
    }
    get transformOriginX() {
        return this._originX
    }
    set transformOriginX(r) {
        this._originX = r, this._hasSkewOrigin = O(this), this._markDirty(S)
    }
    get transformOriginY() {
        return this._originY
    }
    set transformOriginY(r) {
        this._originY = r, this._hasSkewOrigin = O(this), this._markDirty(S)
    }
    get transformOriginZ() {
        return this._originZ
    }
    set transformOriginZ(r) {
        this._originZ = r, this._hasSkewOrigin = O(this), this._markDirty(S)
    }
    get opacity() {
        return x(this.parent.material, "opacity", h, 1)
    }
    set opacity(r) {
        P(this.parent.material, "opacity", r, h)
    }
    get visible() {
        return this._hasGetVisible ? this.parent.getVisibleAt(this.id) : !0
    }
    set visible(r) {
        this._hasSetVisible && this.parent.setVisibleAt(this.id, r)
    }
};

function Dt(t) {
    let r = Q.get(t);
    r && r.flush()
}

function Yt(t) {
    let r = Q.get(t);
    return r || (r = new J(t), Q.set(t, r)), t instanceof nt ? Zt(r) : Xt(r)
}

function Xt(t) {
    let i = t.mesh.count,
        e = t.instances;
    if (e.length === 0 && i > 0) {
        e.length = i;
        for (let s = 0; s < i; s++) e[s] = new D(t, s);
        return e
    }
    if (e.length < i)
        for (let s = e.length; s < i; s++) e.push(new D(t, s));
    else e.length > i && (e.length = i);
    return e
}

function Zt(t) {
    let r = t.mesh,
        i = t.instances,
        e = r._instanceInfo ? ? [],
        s = e.length;
    i.length < s && (i.length = s);
    for (let o = 0; o < s; o++) {
        let n = e[o];
        n && n.active === !1 ? i[o] = null : i[o] || (i[o] = new D(t, o))
    }
    return i.length > s && (i.length = s), i
}
var mt = g.registerTargetAdapter(t => t instanceof D);
mt.registerProperty("color", t => A(t._color), (t, r, i) => {
    if (!t._hasSetColor) return;
    let e = i._numbers;
    t._color.setRGB(e[0] * f, e[1] * f, e[2] * f, p);
    let s = t.parent;
    s.setColorAt(t.id, t._color), s.instanceColor && (s.instanceColor.needsUpdate = !0)
});
mt.registerProperty("transformOrigin", t => `${t._originX} ${t._originY} ${t._originZ}`, (t, r, i) => {
    let e = i._numbers;
    t._originX = e[0], t._originY = e[1], t._originZ = e[2], t._hasSkewOrigin = O(t), t._markDirty(S)
});
export {
    g as a, Dt as b, Yt as c
};
/*! Bundled license information:

animejs/dist/modules/adapters/three/adapter.js:
animejs/dist/modules/adapters/three/helpers.js:
animejs/dist/modules/adapters/three/resolvers.js:
animejs/dist/modules/adapters/three/uniform.js:
animejs/dist/modules/adapters/three/object3d.js:
animejs/dist/modules/adapters/three/instance.js:
animejs/dist/modules/adapters/three/index.js:
  (**
   * Anime.js - adapters - ESM
   * @version v4.5.0
   * @license MIT
   * @copyright 2026 - Julian Garnier
   *)
*/